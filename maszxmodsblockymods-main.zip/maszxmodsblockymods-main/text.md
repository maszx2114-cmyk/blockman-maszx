own by details2009
 To use it all you need Termux
 all try chrome name Vercel Hosting GitHub
 project you name web
# cd /storage/emulated/0/Download
# cp -r maszxmodsblockymods-main /data/data/com.termux/files/home
# git clone https://github.com/Mykolnikovdev41/maszxmodsblockymods.git
# cd maszxmodsblockymods-main
# node index.js
# nodejs
# npm i -g vercel
# vercel dev & vercel
 old bg is version of web working
 use classes, to http://mods.sandboxol.com is no work new https://name