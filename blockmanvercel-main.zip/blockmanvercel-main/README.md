# BlockmanVercel: Create your block world today.
BlockmanVercel is a compiled version of the BlockmanGO server infastructure (API, ect.) that allows you to make your own private BG server using Vercel.

# How to get it running
 For now, the documentation is only avalible inside the source code. It is recommended to import the files into a hosting service like NETLIFY or VERCEL. 
 
# Support
You can address any issues on Discord at the user deniusthepillowhead or mykolnikov_01. The support server is https://discord.com/invite/wjFAuU5TQz. Ping me in the NO18+ chat and ill respond (maybe ?)

# Some things to note:

 1 - This project is a fork of the copyrighted game "Blockman GO" and this is not 100% original material.
 
 2 - You are responsible for any copyright claims from the company (companies, Zhuhai Sandbox & GVERSE International) behind the managment and development of Blockman GO. We are not responsible for any legal issues that you may get from this software in any kind whatsoever.

3 - Software is PROVIDED AS IS. No warranty of any sorts affects this software.

4 - We are not responsible for any damage caused whatsoever by a fork of BlockmanVercel.

# 5 - IMPORTANT:
 BlockmanVercel doesnt provide the engine for the minigames, nor the client to launch them. This project is designed to only display, store, delete, and create information. I'll maybe make repositories for the client and the engine and link it here, but for now, look for other sources. I highly recommend using the "Xreped Core Engine", or follow the IIKJ tutorial. Both can be found in the Discord server of IIKJ (https://discord.com/invite/wjFAuU5TQz)

# Worth checking out:

 You should check out the "CompileSetup.md" file aswell, based on Lapyhs/IIKJ's tutorial.

------------


Made by Kolnikov and DeniusG/Aniku


UPDT: 
1) Kolnikov is no longer on Discord and is no longer in contact

2) This project now has minimal support. Do not expect future updates for this project frequently. 



