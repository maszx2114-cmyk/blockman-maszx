// redisClient.js
const redis = require('redis');

const client = redis.createClient({
    url: 'redis://localhost:6379' // default Redis address
});

client.on('error', (err) => console.error('Redis Client Error', err));

async function connectRedis() {
    if (!client.isOpen) {
        await client.connect();
    }
}

module.exports = { client, connectRedis };