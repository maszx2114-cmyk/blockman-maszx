const fs = require("fs");
const path = require("path");
const hostConfig = require("./config/host");
const cdnConfig = require("./config/cdn");
const { joinCdn } = require("./lib/cdnUrl");

const CDN_ROOT = path.join(__dirname, "../../bmf-cdn");

module.exports = class AssetUtil {
    static getVipIcon(vipLevel) {
        return joinCdn(cdnConfig.vipIconPath, `${vipLevel}.png`);
    }
    
    static getCurrencyIcon(currency) {
        return joinCdn(cdnConfig.currenyPath, `${currency}.png`);
    }

    static getGameCover(gameId) {
        const base = joinCdn(cdnConfig.gameIconPath, `${gameId}.png`);
        const iconPath = path.join(CDN_ROOT, cdnConfig.gameIconPath, `${gameId}.png`);
        try {
            const mtime = Math.floor(fs.statSync(iconPath).mtimeMs);
            if (mtime > 0) return `${base}?v=${mtime}`;
        } catch (_) {}
        return base;
    }

    static getGameResUrl(gameId) {
        const base = joinCdn(cdnConfig.gameResPath, `${gameId}.zip`);
        const zipPath = path.join(CDN_ROOT, cdnConfig.gameResPath, `${gameId}.zip`);
        try {
            const mtime = Math.floor(fs.statSync(zipPath).mtimeMs);
            if (mtime > 0) return `${base}?v=${mtime}`;
        } catch (_) {}
        return base;
    }

    static getGameMapUrl(mapName) {
        return joinCdn(cdnConfig.mapPath, `${mapName}.zip`);
    }
    
    static getCover(coverName) {
        return joinCdn(cdnConfig.coverPath, `${coverName}.png`);
    }
}