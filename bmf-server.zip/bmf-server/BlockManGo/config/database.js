module.exports = {
  databaseType: process.env.MONGODB_URI || 'mongodb+srv://MGO2022:MGO2022@maszxgoblockman.owowvvu.mongodb.net/blockman?retryWrites=true&w=majority&appName=MaszxGoBlockman',
};
