// === Main === \\
const ActivityManager = require("./activities/manager");
const { log, startupSequence } = require('./logger');
const requestLogger = require('./middleware/verboseRequestLogger');
const intercept = require('./interceptor');
const printStartupBanner = require('./printStartupBanner'); // Path to the banner file
const logger = require("./logger");
const express = require("express"); // ExpressJs
const mongoose = require("mongoose"); // MongoDB
const { connectRedis } = require('./redis');
const app = express(); // App Initialization 
const port = process.env.PORT || 3001;

// === Extra === \\
const path = require("path"); // Path
const fs = require("fs"); // File system
// === Main Routers === \\
const configRouter = require("./route/config"); // Config router
const gameRouter = require("./route/game"); // Games router
const userRouter = require("./route/user"); // User router
const decorationRouter = require("./route/decor"); // Decor router
const actRouter = require("./route/activity"); // Activity router
const payRouter = require("./route/pay"); // Pay router
const mailRouter = require("./route/mail"); // Mail router
const friendRouter = require("./route/friend"); // Friend router
const msgRouter = require("./route/msg"); // Mail router
const clanRouter = require("./route/clan"); // Clan Router
const rootRouter = require("./route/root"); // Mail router
const stubsRouter = require("./route/stubs");
const charmingtownRouter = require("./route/charmingtown");
const { mountAdminRoutes } = require("../aio-game-api/adminRoutes");
const { mountAioGameRoutes, initAioGame } = require("../aio-game-api/gameRoutes");
const { normalizeImageFields } = require("./lib/cdnUrl");
const banRouter = require("./route/ban");
const { banMiddleware } = require("./lib/banMiddleware");
ActivityManager.init();
initAioGame();

// === Config === \\
const databaseConfig = require("./config/database"); // Database Configuration


// === Static Image Initialization === \\

const whitelist = [
  '127.0.0.1',           // localhost IPv4
  '::1',                 // localhost IPv6
  '192.168.1.4',        // single IP
  '192.168.1.0/24'       // full range 192.168.1.xxx
];

const ipRangeCheck = require('ip-range-check');

const ipWhitelistMiddleware = (req, res, next) => {
  let clientIp = req.ip || req.connection.remoteAddress;

  // Normalize IPv6 addresses like "::ffff:127.0.0.1"
  if (clientIp.startsWith('::ffff:')) {
    clientIp = clientIp.replace('::ffff:', '');
  }

  if (ipRangeCheck(clientIp, whitelist)) {
    next(); // IP allowed
  } else {
    console.warn(`Blocked IP attempt: ${clientIp}`); // optional logging
    res.status(403).send('ysyha will not allow you to enter my supreme kingdom of my api!!!! ):<');
  }
};


// === Mongoose (MongoDB) === \\
mongoose.set('bufferCommands', true);
mongoose.set('bufferTimeoutMS', 15000);
mongoose.connect(databaseConfig.databaseType, { serverSelectionTimeoutMS: 10000 })
  .then(() => {
    logger.success(`MongoDB connected: ${databaseConfig.databaseType}`);
  })
  .catch((error) => {
    logger.error(`MongoDB connection failed: ${error.message}`);
  });

process.on('unhandledRejection', (err) => {
  logger.error(`Unhandled rejection: ${err && err.message ? err.message : err}`);
});

connectRedis().then(() => {
    logger.success(`The connection to redis is working`);
}).catch(logger.error);


// === App Middlewares === \\
app.use(express.json({
  type: ['application/json', 'application/*+json', 'text/plain'],
}));
app.use(banMiddleware);
app.use((req, res, next) => {
  const sendJson = res.json.bind(res);
  res.json = (body) => sendJson(normalizeImageFields(body));
  next();
});
app.use((req, res, next) => {
  // Prevent client-side stale API payloads after hotfixes/restarts.
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
});
app.use(requestLogger);
app.use(intercept);
mountAioGameRoutes(app);
app.use(stubsRouter);
app.use(charmingtownRouter);
app.use("/config", configRouter);
app.use("/", banRouter);
app.use("/game", gameRouter);
app.use("/user", userRouter);
app.use("/decoration", decorationRouter);
app.use("/decorations", decorationRouter);
// Compatibility mounts for game runtimes that call raw /api and /i paths.
app.use("/", decorationRouter);
app.use("/activity", actRouter);
app.use("/pay", payRouter);
// Compatibility mount: some game scripts call wealth/payment endpoints without /pay prefix.
app.use("/", payRouter);
app.use("/mailbox", mailRouter);
app.use("/friend", friendRouter);
app.use("/msg", msgRouter);
app.use("/clan", clanRouter);
app.use("/", rootRouter);
mountAdminRoutes(app, null);


// === Load Data from JSON Files === \\

// === Serve static files === \\
app.use('/static', express.static(path.join(__dirname, 'static', 'files')));
app.use('/static', (req, res) => {
  return res.status(404).json({
    error: 'Static file not found',
    path: req.path
  });
});

app.get("/", function(req, res) {
  res.sendFile(path.join(__dirname, "static", "website", "index.html"));
});

const listenHost = process.env.HOST || '0.0.0.0';
try {
    app.listen(port, listenHost, () => {
        logger.success(`Server started at http://${listenHost}:${port}`);
        printStartupBanner(port);
    });
} catch (err) {
    logger.error(`Something went wrong while starting the localhost server with port: ${port}`);
}