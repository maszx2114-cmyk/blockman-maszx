
class Activity {
  constructor() {
    this.name = "";
    this.type = "";
    this.startTime = 0;
    this.endTime = 0;
    this.handler = null;
  }

  setName(v){ this.name=v; }
  getName(){ return this.name; }

  setType(v){ this.type=v; }
  getType(){ return this.type; }

  setStartTime(v){ this.startTime=v; }
  getStartTime(){ return this.startTime; }

  setEndTime(v){ this.endTime=v; }
  getEndTime(){ return this.endTime; }

  setHandler(v){ this.handler=v; }
  getHandler(){ return this.handler; }
}

module.exports = Activity;
