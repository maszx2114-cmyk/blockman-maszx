// interceptor.js
function responseMiddleware(req, res, next) {
    // Store the original send function
    const originalSend = res.send;
    
    // Override the send function to intercept the response
    res.send = function (body) {
        if (body && body.status && body.content) {
            // If the response body is an object with status and content properties, send it
            return res.status(body.status).json(body.content);
        }
        
        // Otherwise, proceed with the original send function
        return originalSend.call(res, body);
    };

    next(); // Proceed to the next middleware or route handler
}

module.exports = responseMiddleware;