module.exports = function verboseRequestLogger(req, res, next) {
  next();
};
