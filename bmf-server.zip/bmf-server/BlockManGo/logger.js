const fs = require("fs");
const path = require("path");

// Compatible with Chalk v4 and v5
let chalk = require("chalk");
if (chalk.default) chalk = chalk.default;

// Make sure logs folder exists
const logsDir = path.join(__dirname, "logs");
if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
}

const logStream = fs.createWriteStream(
    path.join(logsDir, "server.log"),
    { flags: "a" }
);

const methodColors = {
    GET: chalk.green.bold,
    POST: chalk.blue.bold,
    PUT: chalk.yellow.bold,
    DELETE: chalk.red.bold,
    PATCH: chalk.magenta.bold,
    OPTIONS: chalk.cyan.bold,
    INFO: chalk.white.bold,
    WARN: chalk.yellow.bold,
    ERROR: chalk.red.bold,
    SUCCESS: chalk.greenBright.bold,
};

const methodEmojis = {
    GET: "🟢",
    POST: "🔵",
    PUT: "🟡",
    DELETE: "🔴",
    PATCH: "🟣",
    OPTIONS: "🔷",
    INFO: "ℹ️",
    WARN: "⚠️",
    ERROR: "❌",
    SUCCESS: "✅",
};

function log(method = "INFO", message = "") {
    const now = new Date().toLocaleString();
    const paddedMethod = method.padEnd(7, " ");

    const colorFn = methodColors[method] || chalk.white.bold;
    const emoji = methodEmojis[method] || "";

    console.log(
        `${chalk.gray(now)} [${colorFn(paddedMethod)}] ${emoji} ${message}`
    );

    logStream.write(`${now} [${method}] ${message}\n`);
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function startupSequence() {
    info("Starting server...");
    await sleep(500);

    info("Loading routes...");
    await sleep(500);

    info("Connecting to database...");
    await sleep(500);

    success("Server started successfully!");
}

function fatal(message) {
    log("ERROR", `[FATAL] ${message}`);
}

function error(message) {
    log("ERROR", `[ERROR] ${message}`);
}

function warn(message) {
    log("WARN", `[WARN] ${message}`);
}

function info(message) {
    log("INFO", `[INFO] ${message}`);
}

function success(message) {
    log("SUCCESS", `[SUCCESS] ${message}`);
}

module.exports = {
    log,
    fatal,
    error,
    warn,
    info,
    success,
    startupSequence,
};