module.exports = function printStartupBanner(port) {
  console.log(`[AIO API] listening on port ${port}`);
};
