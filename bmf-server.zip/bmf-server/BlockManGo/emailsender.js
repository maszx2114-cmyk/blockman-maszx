// utils/emailService.js
const nodemailer = require('nodemailer');
const ejs = require('ejs');
const path = require('path');

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'angelojudeserranothe2nd@gmail.com',
        pass: 'mamapapananaaj1224'
    }
});

async function sendEmail(to, subject, templateName, templateData) {
    const templatePath = path.join(__dirname, './config/emailTemplates', `email-bind.ejs`);
    const html = await ejs.renderFile(templatePath, templateData);

    return transporter.sendMail({
        from: 'Blockveil Email Binding',
        to,
        subject,
        html
    });
}

module.exports = { sendEmail };