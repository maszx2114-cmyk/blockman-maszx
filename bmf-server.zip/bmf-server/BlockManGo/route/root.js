const express = require('express');
const path = require('path');
const fs = require('fs');
const logger = require('../logger');
const router = express.Router();
const { issueGameAuth } = require('../lib/gameAuth');
const banService = require('../lib/banService');
const {
    getUserIdFromRequest,
} = require('../lib/userSession');
const gamesCatalog = require('../lib/gamesCatalog');
const GAME_STATS_FILE = path.join(process.cwd(), 'data/game-stats.json');

function toNumber(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
}

function loadGameStats() {
    try {
        if (!fs.existsSync(GAME_STATS_FILE)) return {};
        return JSON.parse(fs.readFileSync(GAME_STATS_FILE, 'utf8')) || {};
    } catch (_) {
        return {};
    }
}

function getActiveCount(state, now = Date.now()) {
    const ttl = 10 * 60 * 1000;
    const users = (state && state.onlineUsers && typeof state.onlineUsers === 'object') ? state.onlineUsers : {};
    for (const [uid, ts] of Object.entries(users)) {
        if (!Number.isFinite(Number(ts)) || now - Number(ts) > ttl) {
            delete users[uid];
        }
    }
    return Object.keys(users).length;
}

function enrichGamesWithStats(games) {
    const stats = loadGameStats();
    return (Array.isArray(games) ? games : []).map((g) => {
        const gameId = String(g?.gameId || '');
        const st = stats[gameId] || {};
        const likes = toNumber(st.likes, 0);
        const active = getActiveCount(st);
        return {
            ...g,
            visitorEnter: active,
            onlineNumber: active,
            praiseNumber: likes,
            likeCount: likes,
            totalLike: likes,
        };
    });
}

router.get('/health', (_req, res) => {
    res.json({ ok: true, service: 'blockmango-api' });
});

/** APK + GameServer: GET /config/files/:fileName */
router.get('/config/files/:fileName', (req, res) => {
    const fileName = req.params.fileName;
    const filePath = path.join(__dirname, '..', 'static', 'files', fileName);
    if (fileName === 'blockymods-tribe-introduction') {
        return res.status(200).json({
            code: 1,
            message: 'SUCCESS',
            data: [
                {
                    image: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_default.png',
                    image_zh: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_default.png',
                    title: 'Get exclusive avatars',
                    title_zh: '获取免费装扮',
                },
                {
                    image: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_one.png',
                    image_zh: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_one.png',
                    title: 'Find friends who share the same interest',
                    title_zh: '寻找志同道合的朋友',
                },
                {
                    image: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_two.png',
                    image_zh: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_two_zh.png',
                    title: 'Talk with your friends at any time',
                    title_zh: '随时与您的朋友交谈',
                },
                {
                    image: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_three.png',
                    image_zh: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_three.png',
                    title: 'Fight for the honor of the clan',
                    title_zh: '为部落而战',
                },
                {
                    image: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_four.png',
                    image_zh: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_four.png',
                    title: 'More games such as clan war will come soon',
                    title_zh: '部落战争游戏即将推出',
                },
            ],
        });
    }
    if (!fs.existsSync(filePath)) {
        return res.status(200).json({ code: 1, message: 'SUCCESS', data: {} });
    }
    try {
        const raw = fs.readFileSync(filePath, 'utf8');
        let data = {};
        if (raw.trim()) {
            try {
                data = JSON.parse(raw);
            } catch (_) {
                data = { content: raw };
            }
        }
        return res.status(200).json({ code: 1, message: 'SUCCESS', data });
    } catch (err) {
        logger.warn(`config file ${fileName}: ${err.message}`);
        return res.status(200).json({ code: 1, message: 'SUCCESS', data: {} });
    }
});

/** Клиент: GET /game/api/v2/games/recommendation (root mount без префикса /game) */
router.get('/game/api/v2/games/recommendation', (req, res) => {
    const pageNo = parseInt(req.query.pageNo, 10) || 0;
    const pageSize = parseInt(req.query.pageSize, 10) || 10;
    const games = enrichGamesWithStats(gamesCatalog.listGames());
    res.status(200).json(gamesCatalog.pagedResponse(games, pageNo, pageSize));
});

/** Вход в игру — токен для dispatch */
router.get('/game/api/v2/game/auth', async (req, res) => {
    const userId = getUserIdFromRequest(req);
    const typeId = req.query.typeId || 'g1014';
    const targetId = req.query.targetId;
    if (!userId) {
        return res.status(200).json({ code: 6, message: 'userId required', data: null });
    }
    try {
        const data = await issueGameAuth(userId, typeId, { targetId, devicePayload: req.body });
        return res.status(200).json({ code: 1, message: 'SUCCESS', data });
    } catch (error) {
        if (banService.isBanApiCode(error.code)) {
            return banService.sendBanResponse(res, error.message);
        }
        logger.error('v2 game auth: ' + error.message);
        return res.status(200).json({ code: 4, message: 'INNER ERROR', data: null });
    }
});

router.get('/api/v2/enter-game/:userId', async (req, res) => {
    const userId = parseInt(req.params.userId, 10);
    res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: { userId, gameId: req.query.gameId || 'g1014', ok: true },
    });
});

router.post('/geoinfo/api/v1/userGeoInfo', (_req, res) => {
    res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.post('/user/api/v1/user/daily/life/info', (_req, res) => {
    res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.put('/user/api/v1/user/device/id', (req, res) => {
    const { handleDeviceIdPut } = require('../lib/deviceRoute');
    return handleDeviceIdPut(req, res);
});

router.get('/user/api/v1/users/device/token', (_req, res) => {
    res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.put('/game/api/v1/games/engine', (_req, res) => {
    res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

module.exports = router;
