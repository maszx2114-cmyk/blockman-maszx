const express = require('express');
const router = express.Router(); 
const mongoose = require('mongoose');
const path = require('path');
const fs = require('fs');
const updateJson = require('../config/update.json');
const blockmodsPath = path.join(__dirname, '../config/blockmods-v1.json');
const banner = require('../config/blockymods-banner.json');
const AssetUtil = require('../AssetUtil');
const { joinCdn } = require('../lib/cdnUrl');

function loadBlockmodsConfig() {
    try {
        return JSON.parse(fs.readFileSync(blockmodsPath, 'utf8'));
    } catch (err) {
        return { code: 1, message: 'SUCCESS', data: {} };
    }
} 
router.get('/files/blockymods-check-version', async (req, res) => {
    res.json(updateJson);
});

router.get('/files/blockmods-config', (req, res) => {
    const payload = JSON.parse(JSON.stringify(loadBlockmodsConfig() || { code: 1, message: 'SUCCESS', data: {} }));
    payload.code = 1;
    payload.message = 'SUCCESS';
    payload.data = payload.data || {};
    // Compatibility flags for clients that hide graduate UI by default.
    payload.data.showGraduateList = true;
    payload.data.graduateListVisible = true;
    payload.data.showGraduateButton = true;
    res.json(payload);
});

router.get('/files/blockymods-banner', (req, res) => {
    const event1 = joinCdn('news', 'event-staff.png');
    const event2 = joinCdn('news', 'event-discord.png');
    res.json({
      "code": 1,
      "message": "SUCCESS",
      "data": [
        {
          "id": 17,
          "isFullScreen": true,
          "isInside": true,
          "isTest": false,
          "titles": {
              "en_US": "Welcome To Blockman Vestaex!"
            },
          "image": "https://i.ibb.co/m5cFDFwR/ic-banner-default.png",
          "url": "https://i.ibb.co/m5cFDFwR/ic-banner-default.png",
          "version": 1
        },
        {
          "id": 18,
          "isFullScreen": true,
          "isInside": true,
          "isTest": false,
          "titles": {
              "en_US": "Beta Testing - Staff"
            },
          "image": event1,
          "url": event1,
          "version": 1
        },
        {
          "id": 19,
          "isFullScreen": true,
          "isInside": true,
          "isTest": false,
          "titles": {
              "en_US": "Join our Discord!",
              "fr_FR": "Rejoignez notre Discord !",
              "ko_KR": "우리의 디스코드에 참여하세요!",
              "ja_JP": "私たちのDiscordに参加しよう！",
              "de_DE": "Tritt unserem Discord bei!",
              "it_IT": "Unisciti al nostro Discord!",
              "pl_PL": "Dołącz do naszego Discorda!",
              "pt_BR": "Junte-se ao nosso Discord!",
              "pt_PT": "Junta-te ao nosso Discord!",
              "th_TH": "เข้าร่วม Discord ของเรา!",
              "ru_RU": "Присоединяйтесь к нашему Discord!",
              "hi_IN": "हमारे Discord से जुड़ें!",
              "tr_TR": "Discord Sunucumuza Katılın!",
              "es_ES": "¡Únete a nuestro Discord!",
              "in_ID": "Bergabunglah dengan Discord kami!",
              "vi_VN": "Tham gia Discord của chúng tôi!",
              "zh_CN": "加入我们的Discord！",
              "zh_TW": "加入我們的Discord！"
            },
          "image": event2,
          "url": event2,
          "version": 1
        },
            {
          "id": 20,
          "isFullScreen": true,
          "isInside": true,
          "isTest": false,
          "titles": {
            "en_US": "Lucky Wheel"
          },
          "image": "https://cdn.vukz.lol/Banners/banner_lucky_wheel.png",
          "version": 1.0
        },
            {
          "id": 21,
          "isFullScreen": true,
          "isInside": true,
          "isTest": false,
          "titles": {
            "en_US": "Bcube Wheel"
          },
          "image": "https://cdn.vukz.lol/Banners/banner_wheel_2.png",
          "url": "jumpToCampaign:campaign",
          "version": 1.0
        }
      ]
    });
});

router.get('/files/blockymods-tribe-introduction', (_req, res) => {
    res.json({
        code: 1,
        message: 'SUCCESS',
        data: [
            {
                image: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_default.png',
                image_zh: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_default.png',
                title: 'Get exclusive avatars',
                title_zh: '获取免费装扮',
            },
            {
                image: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_one.png',
                image_zh: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_one.png',
                title: 'Find friends who share the same interest',
                title_zh: '寻找志同道合的朋友',
            },
            {
                image: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_two.png',
                image_zh: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_two_zh.png',
                title: 'Talk with your friends at any time',
                title_zh: '随时与您的朋友交谈',
            },
            {
                image: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_three.png',
                image_zh: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_three.png',
                title: 'Fight for the honor of the clan',
                title_zh: '为部落而战',
            },
            {
                image: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_four.png',
                image_zh: 'http://static.sandboxol.com/sandbox/activity/banner/bg_banner_tribe_four.png',
                title: 'More games such as clan war will come soon',
                title_zh: '部落战争游戏即将推出',
            },
        ],
    });
});

module.exports = router;