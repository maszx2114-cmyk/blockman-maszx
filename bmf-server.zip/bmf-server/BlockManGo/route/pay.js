const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const router = express.Router();

const WALLET_DIR =
  process.env.WALLET_DIR ||
  path.join(process.cwd(), 'data', 'user-wallets');

const WEALTH_RECORD_DIR =
  process.env.WEALTH_RECORD_DIR ||
  path.join(process.cwd(), 'data', 'wealth-records');

const DB_TIMEOUT_MS = Number(process.env.PAY_DB_TIMEOUT_MS || 250);

function getUserModel() {
    return mongoose.models.User || null;
}

function readWalletFile(userId) {
    try {
        const filePath = path.join(WALLET_DIR, `${userId}.json`);
        if (!fs.existsSync(filePath)) return null;
        return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    } catch (_) {
        return null;
    }
}

function writeWalletFile(userId, patch) {
    try {
        fs.mkdirSync(WALLET_DIR, { recursive: true });
        const filePath = path.join(WALLET_DIR, `${userId}.json`);
        const current = readWalletFile(userId) || {};
        const next = { ...current, ...patch, userId: Number(userId) };
        fs.writeFileSync(filePath, JSON.stringify(next, null, 2), 'utf8');
        return next;
    } catch (err) {
        console.error('[pay] writeWalletFile error:', err.message);
        return null;
    }
}

function wealthRecordPath(userId) {
    return path.join(WEALTH_RECORD_DIR, `${userId}.json`);
}

function readWealthRecords(userId) {
    try {
        const p = wealthRecordPath(userId);
        if (!fs.existsSync(p)) return [];
        const parsed = JSON.parse(fs.readFileSync(p, 'utf8'));
        return Array.isArray(parsed) ? parsed : [];
    } catch (_) {
        return [];
    }
}

function appendWealthRecord(userId, record) {
    try {
        fs.mkdirSync(WEALTH_RECORD_DIR, { recursive: true });
        const all = readWealthRecords(userId);
        all.unshift({
            id: crypto.randomBytes(8).toString('hex'),
            userId: Number(userId),
            createTime: Date.now(),
            ...record,
        });
        fs.writeFileSync(wealthRecordPath(userId), `${JSON.stringify(all.slice(0, 200), null, 2)}\n`, 'utf8');
    } catch (_) {}
}

function defaultWealth(userId) {
    return {
        userId: Number(userId),
        golds: 0,
        gold: 0,
        diamonds: 0,
        gDiamonds: 0,
        ngDiamonds: 0,
        clanGolds: 0,
    };
}

function wealthFromUser(userId, user, walletFile) {
    if (user) {
        const diamonds = Number(user.diamonds ?? 0);
        const gold = Number(user.gold ?? 0);
        const gcubes = Number(user.gDiamonds ?? diamonds);
        return {
            userId: Number(userId),
            golds: gold,
            gold,
            diamonds,
            gDiamonds: gcubes,
            ngDiamonds: diamonds,
            clanGolds: 0,
        };
    }
    if (walletFile) {
        const diamonds = Number(walletFile.diamonds ?? 0);
        const gold = Number(walletFile.gold ?? 0);
        const gcubes = Number(walletFile.gcubes ?? diamonds);
        return {
            userId: Number(userId),
            golds: gold,
            gold,
            diamonds,
            gDiamonds: gcubes,
            ngDiamonds: diamonds,
            clanGolds: 0,
        };
    }
    return defaultWealth(userId);
}

function sanitizeWealth(data) {
    const safe = { ...data };
    const d = Number(safe.diamonds ?? 0);
    const gd = Number(safe.gDiamonds ?? d);
    const ngd = Number(safe.ngDiamonds ?? d);
    // Known fallback artifact in game UI when backend stalls is 9999/99999 style placeholders.
    if (d >= 9999 && gd >= 9999 && ngd >= 9999) {
        safe.diamonds = 0;
        safe.gDiamonds = 0;
        safe.ngDiamonds = 0;
    }
    return safe;
}

async function findUserWithTimeout(User, userId, timeoutMs) {
    try {
        return await Promise.race([
            User.findOne({ userId: String(userId) }).lean(),
            new Promise((resolve) => setTimeout(() => resolve(null), timeoutMs)),
        ]);
    } catch (err) {
        console.error('[pay] findUserWithTimeout mongo error:', err.message);
        return null;
    }
}

async function loadUserWealth(userId) {
    const uid = String(userId);
    const walletFile = readWalletFile(uid);
    if (walletFile) {
        return sanitizeWealth(wealthFromUser(userId, null, walletFile));
    }
    try {
        const User = getUserModel();
        if (!User) throw new Error('no model');
        const user = await findUserWithTimeout(User, uid, DB_TIMEOUT_MS);
        if (user) {
            return sanitizeWealth(wealthFromUser(userId, user, walletFile));
        }
    } catch (err) {
        console.error('[pay] loadUserWealth mongo error:', err.message);
    }
    return sanitizeWealth(defaultWealth(userId));
}

/** GameServer C++: GET {blockmanUrl}/pay/i/api/v1/wealth/users/:userId */
router.get('/i/api/v1/wealth/users/:userId', async (req, res) => {
    const userId = req.params.userId;
    const data = await loadUserWealth(userId);
    console.log(`[pay] wealth GET user=${userId} diamonds=${data.diamonds} golds=${data.golds}`);
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data,
    });
});

router.get('/api/v1/wealth/user', async (req, res) => {
    const userId = req.headers.userid || req.headers.userId;
    const data = await loadUserWealth(userId);
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: { ...data, userId: Number(userId) },
    });
});

router.get('/api/v1/pay/products', async (req, res) => {
    const type = String(req.query.type || '').trim().toLowerCase();
    const products = [
        { id: 1001, title: '60 Bcubes', type: 'cube', currency: 'usd', amount: 0.99, quantity: 60 },
        { id: 1002, title: '300 Bcubes', type: 'cube', currency: 'usd', amount: 4.99, quantity: 300 },
        { id: 1003, title: '680 Bcubes', type: 'cube', currency: 'usd', amount: 9.99, quantity: 680 },
        { id: 2001, title: '10k Gold', type: 'gold', currency: 'usd', amount: 0.99, quantity: 10000 },
    ];
    const out = type ? products.filter((p) => p.type === type) : products;
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: out });
});

router.get('/api/v1/wealth/record/users/:userId', async (req, res) => {
    const userId = req.params.userId;
    const pageNo = Math.max(0, Number(req.query.pageNo || 0));
    const pageSize = Math.max(1, Math.min(100, Number(req.query.pageSize || 20)));
    const all = readWealthRecords(userId);
    const start = pageNo * pageSize;
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: {
            pageNo,
            pageSize,
            totalPage: Math.ceil(all.length / pageSize),
            totalSize: all.length,
            data: all.slice(start, start + pageSize),
            other: null,
        },
    });
});

async function purchaseGameProps(req, res) {
    const body = req.body || {};
    const userId = Number(body.userId || req.query.userId);
    const propsId = Number(body.propsId || 0);
    const quantity = Math.max(0, Number(body.quantity || 0));
    let currency = Number(body.currency ?? 0);

    if (!userId || quantity <= 0) {
        return res.status(200).json({ code: 3, message: 'PARAM ERROR', data: null });
    }

    const orderId = crypto.randomBytes(8).toString('hex');
    let wealth = await loadUserWealth(userId);
    if (currency === 1) {
        currency = 0;
    }
    if (currency === 0) {
        if ((wealth.diamonds || 0) < quantity) {
            return res.status(200).json({
                code: 5006,
                message: 'Not enough diamonds',
                data: null,
            });
        }
        wealth.diamonds = Math.max(0, Number(wealth.diamonds || 0) - quantity);
        wealth.gDiamonds = Math.max(0, Number(wealth.gDiamonds ?? wealth.diamonds) - quantity);
        wealth.ngDiamonds = Math.max(0, Number(wealth.ngDiamonds ?? wealth.diamonds) - quantity);
    } else if (currency === 2) {
        if ((wealth.gold || 0) < quantity) {
            return res.status(200).json({
                code: 5006,
                message: 'Not enough gold',
                data: null,
            });
        }
        wealth.gold = Math.max(0, Number(wealth.gold || 0) - quantity);
        wealth.golds = wealth.gold;
    }
    writeWalletFile(userId, {
        diamonds: wealth.diamonds,
        gcubes: wealth.gDiamonds,
        gold: wealth.gold,
    });
    appendWealthRecord(userId, {
        type: 'purchase',
        currency,
        quantity,
        propsId,
        diamonds: wealth.diamonds,
        gold: wealth.gold,
    });

    try {
        const User = getUserModel();
        if (User) {
            const user = await User.findOne({ userId: String(userId) });
            if (user) {
                if (currency === 0) {
                    user.diamonds = wealth.diamonds;
                } else if (currency === 2) {
                    user.gold = wealth.gold;
                }
                await user.save();
                wealth = wealthFromUser(userId, user, readWalletFile(userId));
            }
        }
    } catch (err) {
        console.error('[pay] purchase error:', err.message);
    }

    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: {
            orderId,
            userId,
            propsId,
            quantity,
            diamonds: wealth.diamonds,
            gDiamonds: wealth.gDiamonds,
            ngDiamonds: wealth.ngDiamonds,
            golds: wealth.golds,
            gold: wealth.gold,
        },
    });
}

/** C++ HttpRequest::pay (binary uses v1) */
router.post('/api/v1/pay/users/purchase/game/props', purchaseGameProps);
/** Lua WebService:Pay / PayHelper */
router.post('/api/v2/inner/pay/users/purchase/game/props', purchaseGameProps);

module.exports = router;
