const express = require('express');
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const logger = require('../logger');
const router = express.Router();
const { getUserClanSummary } = require('../lib/clanSummary');
const { buildUserGameDataResponse } = require('../lib/userCareer');
const { getGameDisplayName } = require('../lib/gamesCatalog');

const USER_STORE_DIR =
    process.env.USER_STORE_DIR ||
    path.join(process.cwd(), 'data', 'user-profiles');

const PRESENCE_DIR =
    process.env.PRESENCE_DIR ||
    path.join(process.cwd(), 'data', 'presence');

const FRIEND_STATS_DIR =
    process.env.FRIEND_STATS_DIR ||
    path.join(process.cwd(), 'data', 'friend-stats');

function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function readUserFile(userId) {
  try {
    const p = path.join(USER_STORE_DIR, `${String(userId)}.json`);
    if (!fs.existsSync(p)) return null;
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch (_) {
    return null;
  }
}

function readPresence(userId) {
  try {
    const p = path.join(PRESENCE_DIR, `${String(userId)}.json`);
    if (!fs.existsSync(p)) return null;
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch (_) {
    return null;
  }
}

function loadFriendStats(userId) {
  try {
    const p = path.join(FRIEND_STATS_DIR, `${String(userId)}.json`);
    if (!fs.existsSync(p)) return {};
    return JSON.parse(fs.readFileSync(p, 'utf8')) || {};
  } catch (_) {
    return {};
  }
}

async function getUserAny(userId) {
  const uid = String(userId || '').trim();
  if (!uid) return null;
  try {
    const User = mongoose.models.User;
    if (User && mongoose.connection.readyState === 1) {
      const user = await User.findOne({ userId: toNumber(uid, uid) });
      if (user) return user;
    }
  } catch (_) {}
  return readUserFile(uid);
}

function buildFriendProfile(user, fallbackId, viewerUserId = '') {
  const userId = toNumber(user?.userId ?? fallbackId, 0);
  const presence = readPresence(userId);
  const isOnline = Boolean(presence?.online);
  const inGame = isOnline && String(presence?.gameId || '').trim() !== '';
  const clan = getUserClanSummary(userId);
  const viewerId = toNumber(viewerUserId, 0);
  let isFriend = false;
  if (viewerId > 0 && viewerId === userId) {
    isFriend = true;
  } else if (viewerId > 0) {
    const viewer = readUserFile(viewerId);
    const friends = Array.isArray(viewer?.friends) ? viewer.friends : [];
    isFriend = friends.some((f) => toNumber(f?.friendId ?? f?.userId ?? f, 0) === userId);
  }

  return {
    userId,
    nickName: String(user?.nickname || user?.nickName || '').trim() || `Player${userId}`,
    sex: toNumber(user?.sex, 1) === 2 ? 2 : 1,
    picUrl: String(user?.picUrl || '').trim(),
    alias: String(user?.alias || ''),
    details: String(user?.introduction || user?.details || ''),
    gameId: inGame ? String(presence?.gameId || '') : '',
    gameName: inGame ? getGameDisplayName(presence?.gameId || '') : '',
    status: inGame ? 20 : (isOnline ? 10 : 30),
    expireDate: String(user?.expireDate || user?.expireTime || ''),
    vip: toNumber(user?.vip, 0),
    friend: isFriend,
    clanId: Number(clan.clanId || 0),
    clanName: String(clan.clanName || ''),
    role: Number(clan.role || 0),
    isSearchById: false,
    age: toNumber(user?.age, 0),
    language: String(user?.language || ''),
    country: String(user?.country || ''),
    userGameDataResponse: buildUserGameDataResponse(userId),
  };
}

function buildFriendItem(user, fallbackId, viewerUserId = '') {
  const profile = buildFriendProfile(user, fallbackId, viewerUserId);
  const stats = loadFriendStats(profile.userId);
  return { ...profile, isOnline: profile.status !== 30, ...stats };
}

router.get('/api/v1/friends', async (req, res) => {
  const pageNo = parseInt(req.query.pageNo, 10) || 0;
  const pageSize = parseInt(req.query.pageSize, 10) || 10;
  const userId = String(req.headers.userid || req.headers.userId || req.query.userId || '').trim();
  const user = userId ? (readUserFile(userId) || await getUserAny(userId)) : null;
  const friends = Array.isArray(user?.friends) ? user.friends : [];
  const data = friends.map((f) => buildFriendItem(f, f?.friendId ?? f?.userId ?? f, userId));
  return res.status(200).json({
    code: 1,
    message: 'SUCCESS',
    data: {
      pageNo,
      pageSize,
      totalPage: pageSize > 0 ? Math.ceil(data.length / pageSize) : 0,
      totalSize: data.length,
      data: data.slice(pageNo * pageSize, (pageNo + 1) * pageSize),
      other: null,
    },
  });
});

router.get('/api/v2/friends/:friendId', async (req, res) => {
  const friendId = req.params.friendId;
  const viewerUserId = String(req.headers.userid || req.headers.userId || '').trim();
  try {
    const user = await getUserAny(friendId);
    return res.status(200).json({
      code: 1,
      message: 'SUCCESS',
      data: buildFriendProfile(user, friendId, viewerUserId),
    });
  } catch (err) {
    logger.warn(`friend v2 fallback: ${err.message}`);
    return res.status(200).json({
      code: 1,
      message: 'SUCCESS',
      data: buildFriendProfile(null, friendId, viewerUserId),
    });
  }
});

router.get('/api/v1/friends/info/id/:id', async (req, res) => {
  const friendId = req.params.id;
  const viewerUserId = String(req.headers.userid || req.headers.userId || '').trim();
  try {
    const user = await getUserAny(friendId);
    return res.status(200).json({
      code: 1,
      message: 'SUCCESS',
      data: buildFriendProfile(user || null, friendId, viewerUserId),
    });
  } catch (err) {
    return res.status(200).json({
      code: 1,
      message: 'SUCCESS',
      data: buildFriendProfile(null, friendId, viewerUserId),
    });
  }
});

module.exports = router;
