const express = require('express');
const mongoose = require('mongoose');
const banService = require('../lib/banService');

const router = express.Router();

async function findUsersByNickPattern(pattern) {
    const col = mongoose.connection?.db?.collection('users');
    if (!col) return [];
    return col.find({ nickname: { $regex: pattern, $options: 'i' } }).toArray();
}

router.get('/api/v1/inner/ban/check', (req, res) => {
    const userId = req.query.userId || req.headers.userid || req.headers.userId;
    const nickname = req.query.nickname || req.query.nickName || '';
    const clientIp = banService.extractClientIp(req);
    const result = banService.isBanned({ userId, nickname, clientIp });
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: {
            banned: Boolean(result.banned),
            reason: result.reason ? banService.formatBanError(result.reason) : '',
        },
    });
});

router.post('/api/v1/inner/ban/user', (req, res) => {
    const { userId, reason, banDevices = true } = req.body || {};
    if (!userId) {
        return res.status(200).json({ code: 6, message: 'userId required', data: null });
    }
    const text = reason || 'Banned by admin';
    banService.banUser(userId, text, 'admin');
    let devices = [];
    if (banDevices) {
        devices = banService.banAllDevicesForUser(userId, text, 'admin');
    }
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: { userId: String(userId), devices },
    });
});

router.post('/api/v1/inner/ban/device', (req, res) => {
    const { fingerprint, reason } = req.body || {};
    if (!fingerprint) {
        return res.status(200).json({ code: 6, message: 'fingerprint required', data: null });
    }
    banService.banDevice(fingerprint, reason || 'Device banned by admin', 'admin');
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: { fingerprint } });
});

router.post('/api/v1/inner/ban/unban-user', (req, res) => {
    const { userId } = req.body || {};
    if (!userId) {
        return res.status(200).json({ code: 6, message: 'userId required', data: null });
    }
    const ok = banService.unbanUser(userId);
    return res.status(200).json({
        code: 1,
        message: ok ? 'SUCCESS' : 'not banned',
        data: { userId: String(userId), removed: ok },
    });
});

router.post('/api/v1/inner/ban/unban-device', (req, res) => {
    const { fingerprint, userId } = req.body || {};
    if (userId) {
        const removed = banService.unbanAllDevicesForUser(userId);
        return res.status(200).json({
            code: 1,
            message: 'SUCCESS',
            data: { userId: String(userId), fingerprints: removed },
        });
    }
    if (!fingerprint) {
        return res.status(200).json({ code: 6, message: 'fingerprint or userId required', data: null });
    }
    const ok = banService.unbanDevice(fingerprint);
    return res.status(200).json({
        code: 1,
        message: ok ? 'SUCCESS' : 'not banned',
        data: { fingerprint, removed: ok },
    });
});

router.post('/api/v1/inner/ban/nickname-pattern', (req, res) => {
    const { pattern, reason } = req.body || {};
    if (!pattern) {
        return res.status(200).json({ code: 6, message: 'pattern required', data: null });
    }
    banService.addNickPattern(pattern, reason || `Banned nickname pattern: ${pattern}`, 'admin');
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: { pattern } });
});

router.post('/api/v1/inner/ban/ip', (req, res) => {
    const { ip, reason } = req.body || {};
    if (!ip) {
        return res.status(200).json({ code: 6, message: 'ip required', data: null });
    }
    banService.banIp(ip, reason || 'IP banned by admin', 'admin');
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: { ip: banService.normalizeClientIp(ip) } });
});

router.post('/api/v1/inner/ban/enforce-likj', async (_req, res) => {
    banService.addNickPattern('likj', 'BANNED: nickname contains "likj"', 'admin');
    const users = await findUsersByNickPattern('likj');
    const applied = [];
    for (const user of users) {
        const row = banService.banUserAndDevices(
            user.userId,
            user.nickname,
            'BANNED: nickname contains "likj" (device ban)',
            'admin'
        );
        applied.push(row);
    }
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: { matchedUsers: applied.length, users: applied },
    });
});

router.post('/api/v1/inner/ban/enforce-iikj', async (_req, res) => {
    const reason = 'BANNED: bot spam (Iikj / FF000000)';
    const patterns = ['Iikj', 'FF000000', 'i8k2j'];
    const row = banService.banUserFull('1328', 'royale', reason, 'admin', patterns);
    banService.banIp('87.249.61.176', reason, 'admin');
    const users = await findUsersByNickPattern('Iikj');
    const applied = [row];
    for (const user of users) {
        if (String(user.userId) === '1328') continue;
        applied.push(banService.banUserAndDevices(user.userId, user.nickname, reason, 'admin'));
    }
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: { matchedUsers: applied.length, users: applied },
    });
});

module.exports = router;
