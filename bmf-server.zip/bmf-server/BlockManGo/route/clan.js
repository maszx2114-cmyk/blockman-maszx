const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();

// MongoDB Connection

// MongoDB Schemas
const ClanSchema = new mongoose.Schema({
  clanId: { type: Number, unique: true },
  name: String,
  profilePic: String,
  details: String,
  tags: [String],
  level: { type: Number, default: 1 },
  experience: { type: Number, default: 0 },
  creationTime: { type: Date, default: Date.now },
  isFreeVerify: { type: Boolean, default: false }
});

const ClanMemberSchema = new mongoose.Schema({
  userId: Number,
  clanId: Number,
  role: { type: Number, default: 1 }, // 1=Member, 2=Elder, 3=Chief
  experience: { type: Number, default: 0 },
  joinTime: { type: Date, default: Date.now }
});

const ClanMessageSchema = new mongoose.Schema({
  messageId: { type: Number, unique: true },
  userId: Number,
  clanId: Number,
  type: Number,
  status: { type: Number, default: 0 }, // 0=Pending, 1=Accepted, 2=Refused
  content: String,
  profilePic: String,
  nickname: String,
  creationTime: { type: Date, default: Date.now }
});

const ClanNoticeSchema = new mongoose.Schema({
  clanId: { type: Number, unique: true },
  content: String,
  updateTime: { type: Date, default: Date.now }
});

const ClanDonationSchema = new mongoose.Schema({
  donationId: { type: Number, unique: true },
  userId: Number,
  clanId: Number,
  type: Number, // 1=Diamond, 2=Gold
  amount: Number,
  expReward: Number,
  clanGoldReward: Number,
  nickname: String,
  creationTime: { type: Date, default: Date.now }
});

// Models
const Clan = mongoose.model('Clan', ClanSchema);
const ClanMember = mongoose.model('ClanMember', ClanMemberSchema);
const ClanMessage = mongoose.model('ClanMessage', ClanMessageSchema);
const ClanNotice = mongoose.model('ClanNotice', ClanNoticeSchema);
const ClanDonation = mongoose.model('ClanDonation', ClanDonationSchema);

// Constants
const ClanRoles = { MEMBER: 1, ELDER: 2, CHIEF: 3 };
const ClanMessageTypes = {
  JOIN_REQUEST: 1, JOIN_INVITE: 2, ELDER_PROMOTION: 3,
  CHIEF_PROMOTION: 4, MEMBER_REMOVED: 5, MEMBER_LEFT: 6,
  RETROGRADED: 7, CLAN_DISSOLVED: 8
};
const RequestStatuses = { PENDING: 0, ACCEPTED: 1, REFUSED: 2 };
const Currencies = { DIAMOND: 1, GOLD: 2, CLAN_GOLD: 3 };

// Clan Configuration
const clanConfig = {
  levels: {
    1: { maxElders: 2, diamondExperienceRate: 10, goldExperienceRate: 1, diamondCurrencyRate: 100, goldCurrencyRate: 1 },
    2: { maxElders: 3, diamondExperienceRate: 12, goldExperienceRate: 1.2, diamondCurrencyRate: 110, goldCurrencyRate: 1.1 }
  },
  vipBoosts: {
    0: { diamondExperienceRate: 1, goldExperienceRate: 1, diamondCurrencyRate: 1, goldCurrencyRate: 1 },
    1: { diamondExperienceRate: 1.1, goldExperienceRate: 1.1, diamondCurrencyRate: 1.1, goldCurrencyRate: 1.1 }
  }
};

// Response Helpers
const responses = {
  success: (data = null) => ({ status: 200, content: { code: 1, message: "SUCCESS", data } }),
  clanNotExists: () => ({ status: 200, content: { code: 7101, message: "Clan doesn't exist", data: null } }),
  notInClan: () => ({ status: 200, content: { code: 7006, message: "Not in clan", data: null } }),
  notEnoughPermissions: () => ({ status: 200, content: { code: 7004, message: "Not enough permissions", data: null } }),
  alreadyInClan: () => ({ status: 200, content: { code: 7001, message: "Already in clan", data: null } }),
  cannotChangeOwnRole: () => ({ status: 200, content: { code: 3, message: "Can't change own role", data: null } }),
  alreadyElder: () => ({ status: 200, content: { code: 3, message: "Already elder", data: null } }),
  elderLimitReached: () => ({ status: 200, content: { code: 7010, message: "Elder limit reached", data: null } }),
  clanMessageNotFound: () => ({ status: 200, content: { code: 11, message: "Clan message not found", data: null } }),
  invalidCurrency: () => ({ status: 200, content: { code: 3, message: "Invalid currency", data: null } }),
  invalidDonateQuantity: () => ({ status: 200, content: { code: 3, message: "Invalid donation quantity", data: null } }),
  donationExceedsMax: () => ({ status: 200, content: { code: 7011, message: "Donation exceeds max", data: null } }),
  notEnoughWealth: () => ({ status: 200, content: { code: 5006, message: "Not enough wealth", data: null } }),
  innerError: () => ({ status: 500, content: { code: 4, message: "Internal error", data: null } })
};

// Middleware
router.use((req, res, next) => {
  req.userId = parseInt(req.headers['user-id']) || 0;
  next();
});

// Helper Functions
async function getNextId(model) {
  const lastDoc = await model.findOne().sort('-clanId');
  return lastDoc ? lastDoc.clanId + 1 : 1;
}

// ========== ROUTE IMPLEMENTATIONS ========== //

// Clan Recommendation
router.get('/api/v1/clan/tribe/recommendation', async (req, res) => {
  const recommendedClans = await Clan.find({}, 'clanId name headPic level chiefId chiefNickName details members')
    .limit(10)
    .lean();

  if (!recommendedClans.length) {
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: [] });
  }

  const formattedClans = recommendedClans.map(clan => ({
    clanId: clan.clanId,
    name: clan.name,
    headPic: clan.headPic,
    level: clan.level,
    chiefId: clan.chiefId,
    chiefNickName: clan.chiefNickName,
    detail: clan.details,
    currentCount: clan.members.length,
    maxCount: 40
  }));

  return res.status(200).json({ code: 1, message: 'SUCCESS', data: formattedClans });
});

router.get('/api/v1/clan/tribe/recommendation', (req, res) => {
    const formattedClans = recommendedClans.map(clan => ({
        clanId: clan.clanId,
        name: clan.name,
    }));
    
    return res.status(200).json({ 
        code: 1, 
        message: 'SUCCESS', 
        data: formattedClans
    });
});


// Clan CRUD Operations
router.get('/api/v1/clan/tribe', async (req, res) => {
  try {
    const clanId = parseInt(req.query.clanId);
    const clan = await Clan.findOne({ clanId });
    if (!clan) return res.json(responses.clanNotExists());
    
    const members = await ClanMember.find({ clanId });
    res.json(responses.success({ ...clan.toObject(), members }));
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

router.post('/api/v1/clan/tribe', async (req, res) => {
  try {
    const { name, headPic, details, tags } = req.body;
    
    const existingMember = await ClanMember.findOne({ userId: req.userId });
    if (existingMember) return res.json(responses.alreadyInClan());
    
    const clanId = await getNextId(Clan);
    const clan = new Clan({ clanId, name, profilePic: headPic, details, tags });
    await clan.save();
    
    const member = new ClanMember({
      userId: req.userId,
      clanId,
      role: ClanRoles.CHIEF
    });
    await member.save();
    
    res.json(responses.success());
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

router.put('/api/v1/clan/tribe', async (req, res) => {
  try {
    const { name, headPic, details, tags } = req.body;
    const member = await ClanMember.findOne({ userId: req.userId });
    
    if (!member || member.role < ClanRoles.ELDER) {
      return res.json(responses.notEnoughPermissions());
    }
    
    const clan = await Clan.findOne({ clanId: member.clanId });
    if (!clan) return res.json(responses.clanNotExists());
    
    clan.name = name || clan.name;
    clan.profilePic = headPic || clan.profilePic;
    clan.details = details || clan.details;
    clan.tags = tags || clan.tags;
    await clan.save();
    
    res.json(responses.success(clan));
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

router.delete('/api/v1/clan/tribe', async (req, res) => {
  try {
    const member = await ClanMember.findOne({ userId: req.userId });
    if (!member || member.role !== ClanRoles.CHIEF) {
      return res.json(responses.notEnoughPermissions());
    }
    
    await Clan.deleteOne({ clanId: member.clanId });
    await ClanMember.deleteMany({ clanId: member.clanId });
    
    res.json(responses.success());
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Member Operations
router.get('/api/v1/clan/tribe/member', async (req, res) => {
  try {
    const member = await ClanMember.findOne({ userId: req.userId });
    if (!member) return res.json(responses.notInClan());
    
    const members = await ClanMember.find({ clanId: member.clanId });
    res.json(responses.success(members));
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

router.post('/api/v1/clan/tribe/member', async (req, res) => {
  try {
    const { clanId, msg } = req.body;
    if (await ClanMember.findOne({ userId: req.userId })) {
      return res.json(responses.alreadyInClan());
    }
    
    const messageId = await getNextId(ClanMessage);
    const message = new ClanMessage({
      messageId,
      userId: req.userId,
      clanId,
      type: ClanMessageTypes.JOIN_REQUEST,
      content: msg,
      status: RequestStatuses.PENDING
    });
    await message.save();
    
    res.json(responses.success());
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Set Member Role
router.put('/api/v1/clan/tribe/member', async (req, res) => {
  try {
    const { otherId, type } = req.query;
    const chief = await ClanMember.findOne({ userId: req.userId });
    
    if (!chief || chief.role !== ClanRoles.CHIEF) {
      return res.json(responses.notEnoughPermissions());
    }
    
    if (req.userId === parseInt(otherId)) {
      return res.json(responses.cannotChangeOwnRole());
    }
    
    const target = await ClanMember.findOne({ 
      userId: parseInt(otherId), 
      clanId: chief.clanId 
    });
    
    if (!target) return res.json(responses.notInClan());
    
    // Handle different role changes
    switch(parseInt(type)) {
      case 1: // Promote to Elder
        if (target.role === ClanRoles.ELDER) {
          return res.json(responses.alreadyElder());
        }
        target.role = ClanRoles.ELDER;
        break;
      case 2: // Demote to Member
        target.role = ClanRoles.MEMBER;
        break;
      case 3: // Transfer Chief
        chief.role = ClanRoles.MEMBER;
        target.role = ClanRoles.CHIEF;
        await chief.save();
        break;
      default:
        return res.json(responses.invalidType());
    }
    
    await target.save();
    res.json(responses.success());
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Leave Clan
router.delete('/api/v1/clan/tribe/member', async (req, res) => {
  try {
    const member = await ClanMember.findOne({ userId: req.userId });
    if (!member) return res.json(responses.notInClan());
    
    if (member.role === ClanRoles.CHIEF) {
      return res.json(responses.cannotLeaveClan());
    }
    
    await ClanMember.deleteOne({ userId: req.userId });
    res.json(responses.success());
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Get Base Clan Info
router.get('/api/v1/clan/tribe/base', async (req, res) => {
  try {
    const member = await ClanMember.findOne({ userId: req.userId });
    if (!member) return res.json(responses.notInClan());
    
    const clan = await Clan.findOne({ clanId: member.clanId });
    if (!clan) return res.json(responses.clanNotExists());
    
    res.json(responses.success(clan));
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Remove Member
router.delete('/api/v1/clan/tribe/member/remove', async (req, res) => {
  try {
    const { otherId } = req.query;
    const remover = await ClanMember.findOne({ userId: req.userId });
    
    if (!remover || remover.role < ClanRoles.ELDER) {
      return res.json(responses.notEnoughPermissions());
    }
    
    const target = await ClanMember.findOne({ 
      userId: parseInt(otherId), 
      clanId: remover.clanId 
    });
    
    if (!target) return res.json(responses.notValidUser());
    
    await ClanMember.deleteOne({ userId: target.userId });
    res.json(responses.success());
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Get Clan Messages
router.get('/api/v1/clan/tribe/member/message', async (req, res) => {
  try {
    const { pageNo = 1, pageSize = 10 } = req.query;
    const member = await ClanMember.findOne({ userId: req.userId });
    
    let filter = {};
    if (member) {
      filter.clanId = member.clanId;
      if (member.role === ClanRoles.MEMBER) {
        filter.type = { 
          $in: [
            ClanMessageTypes.ELDER_PROMOTION,
            ClanMessageTypes.CHIEF_PROMOTION,
            ClanMessageTypes.MEMBER_REMOVED,
            ClanMessageTypes.MEMBER_LEFT
          ] 
        };
      }
    } else {
      filter.userId = req.userId;
      filter.type = {
        $in: [
          ClanMessageTypes.MEMBER_REMOVED,
          ClanMessageTypes.JOIN_INVITE,
          ClanMessageTypes.CLAN_DISSOLVED
        ]
      };
    }
    
    const messages = await ClanMessage.find(filter)
      .skip((pageNo - 1) * pageSize)
      .limit(pageSize);
    
    res.json(responses.success(messages));
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Invite Friends
router.post('/api/v1/clan/tribe/member/invite', async (req, res) => {
  try {
    const { friendIds, msg } = req.query;
    const inviter = await ClanMember.findOne({ userId: req.userId });
    
    if (!inviter || inviter.role < ClanRoles.ELDER) {
      return res.json(responses.notEnoughPermissions());
    }
    
    const friends = friendIds.split(',').map(id => parseInt(id));
    for (const friendId of friends) {
      const messageId = await getNextId(ClanMessage);
      const invite = new ClanMessage({
        messageId,
        userId: friendId,
        clanId: inviter.clanId,
        type: ClanMessageTypes.JOIN_INVITE,
        content: msg,
        status: RequestStatuses.PENDING
      });
      await invite.save();
    }
    
    res.json(responses.success());
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Accept/Reject Requests
router.put('/api/v1/clan/tribe/member/agreement', async (req, res) => {
  try {
    const { otherId } = req.query;
    const approver = await ClanMember.findOne({ userId: req.userId });
    
    if (!approver || approver.role < ClanRoles.ELDER) {
      return res.json(responses.notEnoughPermissions());
    }
    
    const request = await ClanMessage.findOne({
      userId: parseInt(otherId),
      type: ClanMessageTypes.JOIN_REQUEST,
      status: RequestStatuses.PENDING
    });
    
    if (!request) return res.json(responses.clanMessageNotFound());
    
    request.status = RequestStatuses.ACCEPTED;
    await request.save();
    
    // Add to clan
    const newMember = new ClanMember({
      userId: request.userId,
      clanId: approver.clanId,
      role: ClanRoles.MEMBER
    });
    await newMember.save();
    
    res.json(responses.success());
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Clan Notice Endpoints
router.get('/api/v1/clan/tribe/bulletin', async (req, res) => {
  try {
    const member = await ClanMember.findOne({ userId: req.userId });
    if (!member) return res.json(responses.notInClan());

    const notice = await ClanNotice.findOne({ clanId: member.clanId });
    res.json(responses.success(notice || { content: '' }));
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

router.post('/api/v1/clan/tribe/bulletin', async (req, res) => {
  try {
    const { content } = req.body;
    const member = await ClanMember.findOne({ userId: req.userId });
    
    if (!member || member.role < ClanRoles.ELDER) {
      return res.json(responses.notEnoughPermissions());
    }

    await ClanNotice.findOneAndUpdate(
      { clanId: member.clanId },
      { content, updateTime: Date.now() },
      { upsert: true }
    );
    
    res.json(responses.success());
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Clan Donation Endpoints
router.get('/api/v1/clan/tribe/donation', async (req, res) => {
  try {
    const member = await ClanMember.findOne({ userId: req.userId });
    if (!member) return res.json(responses.notInClan());

    const clan = await Clan.findOne({ clanId: member.clanId });
    const levelConfig = clanConfig.levels[clan.level];
    
    const donationInfo = {
      currentGold: 0,
      maxGold: levelConfig.maxGoldDonation,
      currentDiamond: 0,
      maxDiamond: levelConfig.maxDiamondDonation
    };

    res.json(responses.success(donationInfo));
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

router.post('/api/v1/clan/tribe/donation', async (req, res) => {
  try {
    const { currency, quantity } = req.query;
    const member = await ClanMember.findOne({ userId: req.userId });
    if (!member) return res.json(responses.notInClan());

    const numericCurrency = parseInt(currency);
    const numericQuantity = parseInt(quantity);

    if (numericCurrency !== Currencies.DIAMOND && numericCurrency !== Currencies.GOLD) {
      return res.json(responses.invalidCurrency());
    }

    if (numericQuantity <= 0) {
      return res.json(responses.invalidDonateQuantity());
    }

    // In a real implementation, you would:
    // 1. Check wealth balance
    // 2. Calculate rewards based on clan level
    // 3. Update user wealth
    // 4. Update clan experience
    // 5. Record donation
    
    res.json(responses.success({
      experienceGot: 100,
      tribeCurrencyGot: 50
    }));
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Clan ID Endpoint
router.get('/api/v1/clan/tribe/id', async (req, res) => {
  try {
    const member = await ClanMember.findOne({ userId: req.userId });
    res.json(responses.success(member ? member.clanId : 0));
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Clan Verification Endpoint
router.put('/api/v1/clan/free/verification', async (req, res) => {
  try {
    const { freeVerify } = req.query;
    const member = await ClanMember.findOne({ userId: req.userId });
    
    if (!member || member.role < ClanRoles.ELDER) {
      return res.json(responses.notEnoughPermissions());
    }

    await Clan.findOneAndUpdate(
      { clanId: member.clanId },
      { isFreeVerify: freeVerify === '1' }
    );
    
    res.json(responses.success({ freeVerify: freeVerify === '1' }));
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Clan Search Endpoint
router.get('/api/v1/clan/tribe/blurry/info', async (req, res) => {
  try {
    const { clanName, pageNo = 1, pageSize = 10 } = req.query;
    
    // Check if searching by clan ID
    if (!isNaN(clanName)) {
      const clan = await Clan.findOne({ clanId: parseInt(clanName) });
      return res.json(responses.success({
        pageNo: 1,
        pageSize: 1,
        total: clan ? 1 : 0,
        data: clan ? [clan] : []
      }));
    }

    // Text search
    const clans = await Clan.find({
      name: { $regex: clanName, $options: 'i' }
    })
    .skip((pageNo - 1) * pageSize)
    .limit(pageSize);

    res.json(responses.success({
      pageNo,
      pageSize,
      total: clans.length,
      data: clans
    }));
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Clan Wealth Endpoint
router.get('/api/v1/clan/tribe/currency', async (req, res) => {
  try {
    // In a real implementation, this would check the user's clan gold balance
    res.json(responses.success(1000)); // Mock value
  } catch (err) {
    res.status(500).json(responses.innerError());
  }
});

// Task Endpoints (stubs)
router.get('/api/v1/clan/personal/tasks', async (req, res) => {
  res.json(responses.success([])); // Stub implementation
});

router.get('/api/v1/clan/tasks', async (req, res) => {
  res.json(responses.success([])); // Stub implementation
});

router.put('/api/v1/clan/tasks', async (req, res) => {
  res.json(responses.success()); // Stub implementation
});

router.put('/api/v1/clan/tasks/accept', async (req, res) => {
  res.json(responses.success()); // Stub implementation
});

// Start Server
module.exports = router;