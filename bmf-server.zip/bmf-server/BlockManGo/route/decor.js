const express = require('express');
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
const hostConfig = require('../config/host');
const router = express.Router();
const {
    TYPE_TO_FILE,
    DECORATIONS_DIR,
    FALLBACK_ICON_URL,
    resolveUserSex,
    resolveProfileSex,
    decorationMatchesSex,
    getDecorationTypeById,
    readDecorationType,
    findDecorationById,
    normalizeDecorationItem,
    isOwnedDefault,
    filterDecorationIdsBySex,
    sanitizeUserDressing,
    applyDefaultDressingForNewUser,
} = require('../lib/decorHelpers');

const USER_STORE_DIR =
    process.env.USER_STORE_DIR ||
    path.join(process.cwd(), 'data', 'user-profiles');

const DISPATCH_DRESSING_DIR =
    process.env.DISPATCH_DRESSING_DIR ||
    path.join(process.cwd(), 'data', 'dispatch-dressing');

function getUserModel() {
    return mongoose.models.User;
}

function userFilePath(userId) {
    return path.join(USER_STORE_DIR, `${String(userId)}.json`);
}

function readUserFile(userId) {
    try {
        const p = userFilePath(userId);
        if (!fs.existsSync(p)) return null;
        return JSON.parse(fs.readFileSync(p, 'utf8'));
    } catch (_) {
        return null;
    }
}

function writeUserFile(user) {
    try {
        const uid = String(user?.userId || '').trim();
        if (!uid) return;
        fs.mkdirSync(USER_STORE_DIR, { recursive: true });
        const existing = readUserFile(uid) || {};
        const incoming = { ...(user || {}) };
        const incomingNick = String(incoming.nickname || '').trim();
        const existingNick = String(existing.nickname || '').trim();
        if (
            existingNick
            && existingNick !== `Player${uid}`
            && (incomingNick === '' || incomingNick === `Player${uid}`)
        ) {
            incoming.nickname = existingNick;
        }
        fs.writeFileSync(userFilePath(uid), `${JSON.stringify(incoming, null, 2)}\n`, 'utf8');
    } catch (_) {}
}

function toIdList(entries) {
    return (Array.isArray(entries) ? entries : [])
        .map((x) => Number(x?.id || x || 0))
        .filter((id) => id > 0);
}

function writeDispatchDress(kind, userId, list) {
    try {
        const uid = String(userId || '').trim();
        if (!uid) return;
        const dir = path.join(DISPATCH_DRESSING_DIR, kind);
        fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(path.join(dir, `${uid}.json`), JSON.stringify(toIdList(list)), 'utf8');
    } catch (_) {}
}

function syncDispatchDressFiles(user) {
    if (!user || !user.userId) return;
    const sex = resolveProfileSex(user);
    const usingIds = filterDecorationIdsBySex(user.dressingUsing || [], sex);
    writeDispatchDress('owned', user.userId, user.dressingOwned || []);
    writeDispatchDress('equipped', user.userId, usingIds);
}

async function getUserAny(userId) {
    const uid = String(userId || '').trim();
    if (!uid) return null;
    const fileUser = readUserFile(uid);
    let changed = false;
    try {
        const User = getUserModel();
        if (User) {
            const user = await User.findOne({ userId: uid });
            if (user) {
                if (fileUser) {
                    const fileSex = Number(fileUser.sex);
                    const userSex = Number(user.sex);
                    if ((userSex !== 1 && userSex !== 2) && (fileSex === 1 || fileSex === 2)) {
                        user.sex = fileSex;
                    }
                    if (fileUser.dressingInitialized) {
                        user.dressingInitialized = true;
                    }
                    if (Array.isArray(fileUser.dressingOwned)) {
                        user.dressingOwned = fileUser.dressingOwned;
                    }
                    if (Array.isArray(fileUser.dressingUsing)) {
                        user.dressingUsing = fileUser.dressingUsing;
                    }
                }
                if (applyDefaultDressingForNewUser(user)) changed = true;
                const before = JSON.stringify({
                    owned: user.dressingOwned || [],
                    using: user.dressingUsing || [],
                });
                sanitizeUserDressing(user);
                if (JSON.stringify({
                    owned: user.dressingOwned || [],
                    using: user.dressingUsing || [],
                }) !== before) {
                    changed = true;
                }
                if (changed) {
                    const plain = user.toObject ? user.toObject() : { ...user };
                    writeUserFile(plain);
                    syncDispatchDressFiles(plain);
                }
                return user;
            }
        }
    } catch (_) {}
    if (fileUser) {
        if (applyDefaultDressingForNewUser(fileUser)) changed = true;
        const before = JSON.stringify({
            owned: fileUser.dressingOwned || [],
            using: fileUser.dressingUsing || [],
        });
        sanitizeUserDressing(fileUser);
        if (JSON.stringify({
            owned: fileUser.dressingOwned || [],
            using: fileUser.dressingUsing || [],
        }) !== before || changed) {
            writeUserFile(fileUser);
            syncDispatchDressFiles(fileUser);
        }
    }
    return fileUser;
}

async function saveUserAny(user) {
    if (!user) return;
    sanitizeUserDressing(user);
    if (typeof user.save === 'function') {
        try { await user.save(); } catch (_) {}
        const plain = user.toObject ? user.toObject() : { ...user };
        if (Array.isArray(user.dressingOwned)) {
            plain.dressingOwned = user.dressingOwned;
        }
        if (Array.isArray(user.dressingUsing)) {
            plain.dressingUsing = user.dressingUsing;
        }
        writeUserFile(plain);
        syncDispatchDressFiles(plain);
        return;
    }
    writeUserFile(user);
    syncDispatchDressFiles(user);
}

function normalizeUsingEntries(entries = [], ownedSet = new Set(), sex = 1) {
    const out = [];
    for (const row of entries) {
        const id = Number(row?.id || row || 0);
        if (!id) continue;
        const item = findDecorationById(id);
        if (item && !decorationMatchesSex(item, sex)) continue;
        if (item) {
            out.push(normalizeDecorationItem(item, ownedSet.has(id), true));
        } else {
            out.push({ id, iconUrl: FALLBACK_ICON_URL, hasPurchase: ownedSet.has(id) ? 1 : 0, status: 1, limited: 0, limitCount: 0, quantity: 1 });
        }
    }
    return out;
}

function toOwnedSet(user) {
    return new Set((user?.dressingOwned || []).map((x) => Number(x.id || x)));
}

function toUsingSet(user) {
    return new Set((user?.dressingUsing || []).map((x) => Number(x.id || x)));
}

function emptyList() {
    return { code: 1, message: 'SUCCESS', data: [] };
}

/** Каталог скинов по типу: /decoration/api/v1/decorations/1 … /v2/… */
router.get('/api/:version/decorations/:typeId', async (req, res) => {
    const typeId = Number(req.params.typeId || 0);
    const userId = String(req.headers.userid || req.query.userId || '').trim();
    const user = userId ? await getUserAny(userId) : null;
    const sex = resolveUserSex(user, req.query.sex);
    const vip = Number(user?.vip || 0);
    const owned = toOwnedSet(user);
    const equipped = toUsingSet(user);
    const raw = readDecorationType(typeId);
    const data = raw
        .filter((item) => decorationMatchesSex(item, sex))
        .filter((item) => {
            const id = Number(item.id || 0);
            return owned.has(id) || isOwnedDefault(item, sex, vip);
        })
        .map((item) => {
            const id = Number(item.id || 0);
            const hasPurchase = owned.has(id) || isOwnedDefault(item, sex, vip) ? 1 : 0;
            const status = equipped.has(id) ? 1 : 0;
            return normalizeDecorationItem(item, hasPurchase, status);
        });
    res.status(200).json({ code: 1, message: 'SUCCESS', data });
});

/** Надетые предметы другого игрока */
router.get('/api/v1/decorations/:otherId/using', async (req, res) => {
    const userId = req.params.otherId;
    const user = await getUserAny(userId);
    const owned = toOwnedSet(user);
    const sex = resolveProfileSex(user);
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: normalizeUsingEntries(user?.dressingUsing || [], owned, sex) });
});

/** Свои надетые: ?otherId=0 */
router.get('/api/v1/decorations/using', async (req, res) => {
    const otherId = String(req.query.otherId || '').trim();
    const userId = (otherId && otherId !== '0')
        ? otherId
        : String(req.headers.userid || req.headers.userId || req.query.userId || '').trim();
    if (!userId) return res.status(200).json({ code: 1, message: 'SUCCESS', data: [] });
    const user = await getUserAny(userId);
    const owned = toOwnedSet(user);
    const sex = resolveProfileSex(user);
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: normalizeUsingEntries(user?.dressingUsing || [], owned, sex) });
});

async function equipDecoration(req, res) {
    const userId = String(
        req.headers.userid
        || req.headers.userId
        || req.headers['x-shahe-uid']
        || req.query.userId
        || req.query.otherId
        || req.body?.userId
        || ''
    ).trim();
    const decorationId = Number(req.params.decorationId || 0);
    if (!decorationId) {
        return res.status(200).json({ code: 3, message: 'Invalid parameter', data: null });
    }
    if (!userId) {
        // Some clients call this endpoint without headers; keep it non-fatal.
        return res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
    }
    const user = await getUserAny(userId) || { userId, dressingOwned: [], dressingUsing: [] };
    const sex = resolveProfileSex(user);
    const owned = toOwnedSet(user);
    const typeId = getDecorationTypeById(decorationId);
    const itemDef = findDecorationById(decorationId);
    if (!itemDef) {
        return res.status(200).json({ code: 3, message: 'Invalid parameter', data: null });
    }
    if (!decorationMatchesSex(itemDef, sex)) {
        return res.status(200).json({ code: 3, message: 'Invalid parameter', data: null });
    }
    if (!owned.has(decorationId)) {
        const vip = Number(user.vip || 0);
        if (!isOwnedDefault(itemDef, sex, vip)) {
            return res.status(200).json({ code: 3, message: 'Invalid parameter', data: null });
        }
        user.dressingOwned = Array.isArray(user.dressingOwned) ? user.dressingOwned : [];
        user.dressingOwned.push({ id: decorationId });
    }
    const using = (Array.isArray(user.dressingUsing) ? user.dressingUsing : [])
        .filter((x) => getDecorationTypeById(Number(x.id || x)) !== typeId);
    using.push({ id: decorationId });
    user.dressingUsing = using;
    user.dressingInitialized = true;
    await saveUserAny(user);
    const ownedAfter = toOwnedSet(user);
    const equippedItem = findDecorationById(decorationId);
    if (!equippedItem) {
        return res.status(200).json({ code: 3, message: 'Invalid parameter', data: null });
    }
    const responseItem = normalizeDecorationItem(equippedItem, ownedAfter.has(decorationId), true);
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: responseItem });
}

router.put('/api/v1/decorations/using/:decorationId', equipDecoration);
router.post('/api/v1/decorations/using/:decorationId', equipDecoration);
router.get('/api/v1/decorations/using/:decorationId', equipDecoration);

router.delete('/api/v1/decorations/using/:decorationId', async (req, res) => {
    const userId = String(req.headers.userid || req.query.userId || '').trim();
    const decorationId = Number(req.params.decorationId || 0);
    if (!userId || !decorationId) {
        return res.status(200).json({ code: 3, message: 'Invalid parameter', data: null });
    }
    const user = await getUserAny(userId) || { userId };
    const using = Array.isArray(user.dressingUsing) ? user.dressingUsing : [];
    user.dressingUsing = using.filter((x) => Number(x.id || x) !== decorationId);
    user.dressingInitialized = true;
    await saveUserAny(user);
    res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.get('/api/v1/new/decorations/users/:userId/type/:typeId', async (req, res) => {
    const user = await getUserAny(req.params.userId);
    const sex = resolveProfileSex(user);
    const vip = Number(user?.vip || 0);
    const owned = toOwnedSet(user);
    const equipped = toUsingSet(user);
    const raw = readDecorationType(req.params.typeId);
    const data = raw
        .filter((item) => decorationMatchesSex(item, sex))
        .filter((item) => {
            const id = Number(item.id || 0);
            return owned.has(id) || isOwnedDefault(item, sex, vip);
        })
        .map((item) => {
            const id = Number(item.id || 0);
            return normalizeDecorationItem(item, owned.has(id) || isOwnedDefault(item, sex, vip), equipped.has(id));
        });
    return res.status(200).json({ code: 1, message: 'SUCCESS', data });
});

router.get('/api/v1/decoration/versions', (_req, res) => {
    res.status(200).json({ code: 1, message: 'SUCCESS', data: { version: 1 } });
});

router.get('/api/v1/vip/decorations/users/:typeId', (_req, res) => {
    res.status(200).json(emptyList());
});

router.get('/api/v1/new/decorations/check/resource', (req, res) => {
    res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: { update: false, url: '', md5: '', resVersion: Number(req.query.resVersion) || 0 },
    });
});

router.get('/api/v1/new/decorations/users/:userId/expire', (_req, res) => {
    res.status(200).json(emptyList());
});

router.get('/api/v1/new/decorations/users/:userId/suit', (_req, res) => {
    res.status(200).json(emptyList());
});

module.exports = router;
