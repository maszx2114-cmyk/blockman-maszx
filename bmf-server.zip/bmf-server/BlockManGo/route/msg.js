const express = require('express');
const Responses = require("../Responses");
const path = require('path');
const mongoose = require('mongoose');
const { log, startupSequence } = require('../logger');
const logger = require('../logger');
const router = express.Router();
const MailStatuses = require("../constants/MailStatuses");
const fs = require('fs');
const GAME_STATS_FILE = path.join(process.cwd(), 'data/game-stats.json');

function toNumber(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
}

function loadGameStats() {
    try {
        if (!fs.existsSync(GAME_STATS_FILE)) return {};
        return JSON.parse(fs.readFileSync(GAME_STATS_FILE, 'utf8')) || {};
    } catch (_) {
        return {};
    }
}

function saveGameStats(data) {
    try {
        fs.mkdirSync(path.dirname(GAME_STATS_FILE), { recursive: true });
        fs.writeFileSync(GAME_STATS_FILE, `${JSON.stringify(data || {}, null, 2)}\n`, 'utf8');
    } catch (_) {}
}

function getActiveCount(state, now = Date.now()) {
    const ttl = 2 * 60 * 1000;
    const users = (state && state.onlineUsers && typeof state.onlineUsers === 'object') ? state.onlineUsers : {};
    for (const [uid, ts] of Object.entries(users)) {
        if (!Number.isFinite(Number(ts)) || now - Number(ts) > ttl) {
            delete users[uid];
        }
    }
    return Object.keys(users).length;
}

function markUserOfflineEverywhere(userId) {
    if (!userId) return;
    const stats = loadGameStats();
    for (const gameId of Object.keys(stats)) {
        const state = stats[gameId] && typeof stats[gameId] === 'object' ? stats[gameId] : {};
        const onlineUsers = (state.onlineUsers && typeof state.onlineUsers === 'object') ? state.onlineUsers : {};
        if (onlineUsers[String(userId)]) {
            delete onlineUsers[String(userId)];
        }
        state.onlineUsers = onlineUsers;
        state.likes = toNumber(state.likes, 0);
        state.active = getActiveCount(state);
        stats[gameId] = state;
    }
    saveGameStats(stats);
}

router.get('/api/v1/msg/group/chat/list', async (req, res) => {
    const pageNo = parseInt(req.query.pageNo) || 0;
    const pageSize = parseInt(req.query.pageSize) || 10;
    logger.warn("GetGroupChatList: Implementation needed");
        if (pageNo !== 0) {
            return res.status(200).json({
                code: 1,
                message: 'SUCCESS',
                data: {
                    pageNo,
                    pageSize,
                    totalPage: 0,
                    totalSize: 0,
                    data: []
                }
            });
        }

        res.status(200).json({
            code: 1,
            message: 'SUCCESS',
            data: {
                pageNo,
                pageSize,
                totalPage: 0,
                totalSize: 0,
                data: [],
                other: null
            }
        });
});

router.post('/api/v1/msg/group/chat', async (_req, res) => {
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.post('/api/v1/msg/group/chat/add', async (_req, res) => {
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.get('/api/v1/msg/group/chat/info', async (_req, res) => {
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: {
            id: 0,
            name: '',
            notice: '',
            memberCount: 0,
            maxMemberCount: 100,
        },
    });
});

router.post('/api/v1/msg/group/chat/kickOut', async (_req, res) => {
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.post('/api/v1/msg/group/chat/mail/add', async (_req, res) => {
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.post('/api/v1/msg/group/chat/modify', async (_req, res) => {
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.get('/api/v1/group/chat/price', async (req, res) => {
    const pageNo = parseInt(req.query.pageNo) || 0;
    const pageSize = parseInt(req.query.pageSize) || 10;
    res.status(200).json({ 
        code: 1, 
        message: 'SUCCESS', 
        data: {
            "maxRequestLength": 32,
            "maxAliasLength": 16,
            "currencyGroup": 1,
            "priceGroup": 60
        } 
    });
});

router.post('/api/v1/msg/group/chat/quit', async (req, res) => {
    const userId = String(
        req.headers.userid
        || req.headers.userId
        || req.headers['user-id']
        || req.query.userId
        || req.body?.userId
        || ''
    ).trim();
    if (userId) {
        markUserOfflineEverywhere(userId);
    }
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

module.exports = router;