const express = require('express');
const Responses = require("../Responses");
const path = require('path');
const mongoose = require('mongoose');
const { log, startupSequence } = require('../logger');
const logger = require('../logger');
const router = express.Router();
const MailStatuses = require("../constants/MailStatuses");
const fs = require('fs');

const MailAttachmentTypes = {
  CURRENCY: 0,
  DRESS: 1,
  VIP: 2
};

const User = mongoose.model('User');

router.get('/api/v1/mail', async (req, res) => {
    const userId = req.headers.userid;
    let user = await User.findOne({ userId });
    res.status(200).json({ code: 1, message: 'SUCCESS', data: user.mail });
});

router.put('/api/v1/mail', async (req, res) => {
        let mailIds = req.query.ids;
        const userId = req.headers.userid;
        let user = await User.findOne({ userId });
        if (!mailIds) {
            return res.status(200).json({
                code: 3,
                message: "Invalid parameter",
                data: null
        });
        }
    
        if (Array.isArray(mailIds)) {
            mailIds = mailIds.map(x => parseInt(x)).filter(x => !isNaN(x));
        } else {
            mailIds = parseInt(mailIds);
        }
    
        const status = parseInt(request.query.status);
        if (status < MailStatuses.READ || status > MailStatuses.DELETE) {
            return Responses.invalidParameter();
        }
    
        let targetStatus = status;
        
        const mailbox = (await base.getMailbox(userId)).filter(x => {
        if (Array.isArray(mailIds)) { 
            return mailIds.includes(x.getMailId())
        }

        return x.getMailId() == mailIds;
    });

    if (mailbox.length == 0) {
        return Responses.success();
    }

    const statuses = {};
    for (let i = 0; i < mailbox.length; i++) {
        // Can't delete if mail isn't read
        if (mailbox[i].status == MailStatuses.UNREAD && targetStatus == MailStatuses.DELETE) {
            continue;
        }

        // Can't set as read or higher status if attachments aren't claimed 
        if (mailbox[i].status == MailStatuses.UNREAD && mailbox[i].getAttachments().length > 0 && targetStatus > MailStatuses.UNREAD) {
            continue;
        }

        statuses[mailbox[i].getMailId()] = targetStatus;
    }

    const records = statuses;
    user.mail.push(foundAvatar);
    await user.save();
    res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});


router.put('/api/v1/mail/attachment', async (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.get('/api/v1/mail/new', async (req, res) => {
    const userId = parseInt(req.headers.userId);

    let user = await User.findOne({ userId });
    if (!user) {
        return Responses.userNotExists(); // Or whatever error you want
    }

    const mailRecords = user.mail || [];

    let hasNewMail = false;
    for (let i = 0; i < mailRecords.length; i++) {
        if (mailRecords[i].status === MailStatuses.UNREAD) { // <-- fix this too
            hasNewMail = true;
            break;
        }
    }

    res.status(200).json({ code: 1, message: 'SUCCESS', data: hasNewMail });
});

module.exports = router;