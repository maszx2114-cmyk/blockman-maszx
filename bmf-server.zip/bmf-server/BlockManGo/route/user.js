const express = require('express');
const path = require('path');
const Responses = require("../Responses");
const ActivityLoginStatuses = require("../constants/ActivityLoginStatuses");
const mongoose = require('mongoose');
const router = express.Router();
const fs = require('fs');
const { client } = require('../redis');
const bcrypt = require('bcryptjs');
const { sendEmail } = require("../emailsender");
const { getDeviceToken } = require('../lib/rongToken');
const { performAppLogin } = require('../lib/appLogin');
const {
    createSessionForUser,
    verifySession,
    getAccessTokenFromRequest,
} = require('../lib/userSession');
const { guardAccountCreation, guardExistingUser } = require('../lib/accountGuard');
const banService = require('../lib/banService');
const { applyDefaultDressingForNewUser } = require('../lib/decorHelpers');

const USER_STORE_DIR =
  process.env.USER_STORE_DIR ||
  path.join(process.cwd(), 'data', 'user-profiles');

const DISPATCH_DRESSING_DIR =
  process.env.DISPATCH_DRESSING_DIR ||
  path.join(process.cwd(), 'data', 'dispatch-dressing');

function writeUserDressingProfile(userLike) {
    const uid = String(userLike?.userId || '').trim();
    if (!uid) return;
    const plain = userLike.toObject ? userLike.toObject() : { ...userLike };
    plain.userId = uid;
    applyDefaultDressingForNewUser(plain);
    fs.mkdirSync(USER_STORE_DIR, { recursive: true });
    fs.writeFileSync(path.join(USER_STORE_DIR, `${uid}.json`), `${JSON.stringify(plain, null, 2)}\n`, 'utf8');
    const toIds = (rows) => (Array.isArray(rows) ? rows : [])
        .map((x) => Number(x?.id || x || 0))
        .filter((id) => id > 0);
    const owned = toIds(plain.dressingOwned);
    const equipped = toIds(plain.dressingUsing);
    for (const [kind, list] of [['owned', owned], ['equipped', equipped]]) {
        const dir = path.join(DISPATCH_DRESSING_DIR, kind);
        fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(path.join(dir, `${uid}.json`), JSON.stringify(list), 'utf8');
    }
}

const rewardsConfig = [
    {
        "signInId": 1,
        "rewards": [ { "rewardPic": "https://static.resquared.studio/events/gold.png", "rewardName": "500", "quantity": 500, "rewardType": "gold" } ]
    },
    {
        "signInId": 2,
        "isSpecial": 1,
        "rewards": [ { "rewardPic": "https://static.resquared.studio/events/bcubes.png", "rewardName": "25", "quantity": 25, "rewardType": "diamond" } ]
    },
    {
        "signInId": 3,
        "rewards": [ { "rewardPic": "https://static.resquared.studio/events/gold.png", "rewardName": "500", "quantity": 500, "rewardType": "gold" } ]
    },
    {
        "signInId": 4,
        "isSpecial": 1,
        "rewards": [ { "rewardPic": "https://static.resquared.studio/events/bcubes.png", "rewardName": "125", "quantity": 125, "rewardType": "diamond" } ]
    },
    {
        "signInId": 5,
        "rewards": [ { "rewardPic": "https://static.resquared.studio/events/gold.png", "rewardName": "1000", "quantity": 1000, "rewardType": "gold" } ]
    },
    {
        "signInId": 6,
        "rewards": [ { "rewardPic": "https://static.resquared.studio/events/vip.png", "rewardName": "5 days", "quantity": 5, "level": 1, "rewardType": "vip" } ]
    },
    {
        "signInId": 7,
        "rewards": [ { "rewardPic": "https://static.resquared.studio/events/gold.png", "rewardName": "2000", "quantity": 2000, "rewardType": "gold" } ]
    },
    {
        "signInId": 8,
        "isSpecial": 1,
        "rewardList_1": [
            { "rewardPic": "https://static.resquared.studio/icons/hair/200045.png", "rewardId": 200045, "rewardType": "decoration" },
            { "rewardPic": "https://static.resquared.studio/icons/face/400048.png", "rewardId": 400048, "rewardType": "decoration" },
            { "rewardPic": "https://static.resquared.studio/icons/top/800084.png", "rewardId": 800084, "rewardType": "decoration" },
            { "rewardPic": "https://static.resquared.studio/icons/pants/900082.png", "rewardId": 900082, "rewardType": "decoration" },
            { "rewardPic": "https://static.resquared.studio/icons/shoes/1000027.png", "rewardId": 1000027, "rewardType": "decoration" },
            { "rewardPic": "https://static.resquared.studio/icons/wings/1400019.png", "rewardId": 1400019, "rewardType": "decoration" }
        ],
        "rewardList_2": [
            { "rewardPic": "https://static.resquared.studio/icons/hair/200048.png", "rewardId": 200048, "rewardType": "decoration" },
            { "rewardPic": "https://static.resquared.studio/icons/face/400037.png", "rewardId": 400037, "rewardType": "decoration" },
            { "rewardPic": "https://static.resquared.studio/icons/top/800052.png", "rewardId": 800052, "rewardType": "decoration" },
            { "rewardPic": "https://static.resquared.studio/icons/wings/1400018.png", "rewardId": 1400018, "rewardType": "decoration" }
        ]
    }
]

const Schema = mongoose.Schema;

const FriendRequestSchema = new mongoose.Schema({
  requestId: Number,     // Auto-increment (you will handle this in code or with a plugin)
  userId: Number,
  friendId: Number,
  message: String,
  picUrl: String,
  nickName: String,
  sex: Number,
  country: String,
  language: String,
  status: Number,
  creationTime: Number
}, { _id: false });

const friendSchema = new mongoose.Schema({
  nickName: String,
  sex: Number,
  userId: Number,
  friendId: Number,
  alias: String
}, { _id: false }); // <-- _id: false because it's a subdocument

const attachmentSchema = new mongoose.Schema({
  status: Number,
  name: String,
  quantity: Number,
  icon: String,
  itemId: Number,
  type: Number,
  vipLevel: Number,
  vipDays: Number
}, { _id: false }); // <-- _id: false because it's a subdocument

const mailSchema = new mongoose.Schema({
  mailId: Number,
  mailType: Number,
  title: String,
  content: String,
  attachment: [attachmentSchema], // <--- Here we use it
  extraContent: String,
  creationTime: Number,
  status: Number
}, { _id: false });

const dressingOwnedSchema = new mongoose.Schema({
  id: Number,
  typeId: Number,
  camera: String,
  name: String,
  iconUrl: String,
  resourceId: String,
  details: String,
  forId: Number,
  price: Number,
  currency: Number,
  status: Number
}, { _id: false });

const userSchema = new mongoose.Schema({
    password: String,
    nickname: String,
    userId: String,
    birthday: String,
    introduction: String,
    diamonds: Number,
    gold: Number,
    sex: Number,
    picUrl: String,
    vip: Number,
    email: String,
    isFreeNickname: Boolean,
    dressingOwned: [dressingOwnedSchema],
    friends: [friendSchema],
    friendRequests: [FriendRequestSchema],
    mail: [mailSchema],
    expireTime: Number,
    startTime: Number,
    donatorTier: Number
});

const configSchema = new mongoose.Schema({
    _id: String,
    key: Number
});

const User = mongoose.model('User', userSchema);
const sysConfig = mongoose.model('sysConfig', configSchema);

async function getMaxUserId() {
    let maxUserId = await sysConfig.findOne({ "_id": "maxUserId" });
    if (!maxUserId) { return null }
    return maxUserId.key
}

router.post('/api/v1/app/set-password', async (req, res) => {
    const { password } = req.body;
    const userId = req.headers.userid;

    if (!userId) {
        return res.status(400).json({ code: 6, message: 'Bad request : Params error please fill them', data: null });
    }

    let user = await User.findOne({ userId });

    if (!user) {
        return res.status(404).json({ code: 108, message: 'User not found', data: null });
    }
    // When user sets a new password
    const saltRounds = await bcrypt.genSalt(8); // you can tweak this higher for better security
    const hashedPassword = await bcrypt.hash(password, saltRounds);
    
    // Save hashedPassword in your database
    user.password = hashedPassword;
    await user.save();

    return res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
    
});

router.post('/api/v1/app/renew', async (req, res) => {
    const devicePayload = banService.extractDeviceFromRequest(req);
    const deviceBan = banService.isDeviceBanned(devicePayload);
    if (deviceBan.banned) {
        return banService.sendBanResponse(res, deviceBan.reason);
    }

    let maxUserId = await sysConfig.findOne({ "_id": "maxUserId" });

    if (!maxUserId) {
        maxUserId = new sysConfig({ _id: "maxUserId", key: 0 });
    }

    const userId = (maxUserId.key + 16).toString();

    const postcheck = await guardAccountCreation(req, userId);
    if (!postcheck.allowed) {
        if (banService.isBanApiCode(postcheck.code)) {
            return banService.sendBanResponse(res, postcheck.message);
        }
        return res.status(200).json({ code: postcheck.code, message: postcheck.message, data: null });
    }

    maxUserId.key += 16;
    await maxUserId.save();

    const user = new User({ userId });
    await user.save();

    const accessToken = await createSessionForUser(userId);

    res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: {
            userId,
            accessToken
        }
    });
});

router.post('/api/v1/user/register', async (req, res) => {
    const { nickName, sex } = req.body;
    const userId = req.headers.userid;
    const accessToken = getAccessTokenFromRequest(req);

    if (!nickName) {
        return res.status(400).json({ code: 6, message: 'Bad request : Params error please fill them', data: null });
    }

    const session = await verifySession(userId, accessToken);
    if (!session.ok) {
        return res.status(200).json({ code: 103, message: session.message || 'Authentication failed', data: null });
    }

    const access = await guardExistingUser(req, userId, nickName);
    if (!access.allowed) {
        if (banService.isBanApiCode(access.code)) {
            return banService.sendBanResponse(res, access.message);
        }
        return res.status(200).json({ code: access.code, message: access.message, data: null });
    }

    const nickBan = banService.isBanned({ userId, nickname: nickName, devicePayload: access.devicePayload });
    if (nickBan.banned) {
        banService.enforceNicknamePolicy(userId, nickName, access.devicePayload);
        return banService.sendBanResponse(res, nickBan.reason);
    }

    let user = await User.findOne({ userId: userId });

    if (!user) {
        return res.status(404).json({ message: 'User not found.' });
    }

    const existingUser = await User.findOne({ nickname: nickName });
    if (existingUser) {
        return res.status(400).json({ code: 7, message: 'Nickname already exists, choose another nickname', data: null });
    }

    user.nickname = nickName;
    user.sex = sex;
    user.picUrl = '';
    user.birthday = '';
    user.diamonds = 0;
    user.introduction = 'Welcome to the blocky world!';
    user.gold = 0;
    user.vip = 0;
    user.friendRequests = [];
    user.friends = [];
    user.email = ''
    user.mail = [];
    user.startTime = 0;
    user.expireTime = 0;
    user.isFreeNickname = true;

    await user.save();

    writeUserDressingProfile(user);

    const responseData = {
        userId: userId,
        nickName: user.nickname,
        sex: user.sex, 
        picUrl: user.picUrl, 
        details: user.introduction,
        birthday: user.birthday,
        startTime: user.startTime,
        expireTime: user.expireTime,
        vip: user.vip,
        email: user.email,
        isFreeNickname: user.isFreeNickname,
        expire: 0
    };
    

    res.status(200).json({ 
        code: 1, 
        message: 'SUCCESS', 
        data: responseData 
    });
});

router.post('/api/v1/user/details/info', async (req, res) => {
    const userId = req.headers['userid'];

    if (!userId) {
        return res.status(400).json({ code: 6, message: 'Bad request : Params error please fill them', data: null });
    }

    let user = await User.findOne({ userId });

    const userInfo = {
        userId: user.userId,
        sex: user.sex || 2,
        nickName: user.nickname,
        birthday: user.birthday || '',
        details: user.introduction,
        diamonds: user.diamonds,
        golds: user.gold,
        picUrl: user.picUrl || '',
        email: user.email || '',
        hasPassword: true,
        stopToTime: null
    };

    res.status(200).json({ code: 1, message: 'SUCCESS', data: userInfo });
});


router.post('/api/v1/app/login', async (req, res) => {
    const { uid, password } = req.body;

    if (!uid || !password) {
        return res.status(400).json({ code: 6, message: 'Bad request: Params error, please fill them', data: null });
    }

    const user = await User.findOne({ userId: uid });

    if (!user) {
        return res.status(200).json({
            code: 102,
            message: 'User ID or username not found.',
            data: null
        });
    }

    const result = await performAppLogin(user, password, { devicePayload: banService.extractDeviceFromRequest(req) });
    if (banService.isBanApiCode(result.code)) {
        return banService.sendBanResponse(res, result.message);
    }
    return res.status(200).json(result);
});

router.post('api/v1/user/details/info', async (req, res) => {
    const userId = req.headers.userid;
    const { oldName, newName } = req.query;
    
    if (!userId || !oldName || !newName) {
        return res.status(400).json({ code: 6, message: 'Bad request : Params error please fill them', data: null });
    }
    
        let user = await User.findOne({ userId: uid });

    if (!user) {
        return res.status(200).json({
            code: 102,
            message: 'User ID or username not found.',
            data: null
        });
    }

    if (user.nickname !== oldName) {
        return res.status(200).json({
            code: 108,
            message: 'Incorrect nicknames.',
            data: null
        });
    }
    
    
});

router.post('/api/v1/user/password/modify', async (req, res) => {
    const { oldPassword, newPassword } = req.body;
    const userId = req.headers['userid']; 

    if (!newPassword || newPassword.trim() === '') {
        return res.status(400).json({ 
            code: 1, 
            message: 'New password cannot be empty', 
            data: null 
        });
    }
        const user = await User.findOne({ userId });

        if (!user) {
            return res.status(404).json({ 
                code: 1, 
                message: 'User not found', 
                data: null 
            });
        }
        const saltRounds = await bcrypt.genSalt(8); // you can tweak this higher for better security
        const hashedPassword = await bcrypt.hash(newPassword, saltRounds);
        const isMatch = await bcrypt.compare(oldPassword, user.password);
        if (!isMatch) {
            return res.status(200).json({
                code: 108, 
                message: 'Incorrect old password', 
                data: null
            });
        }
        user.password = hashedPassword;
        await user.save();

       
        return res.status(200).json({ 
            code: 1, 
            message: 'SUCCESS', 
            data: {
                userId: user.userId,
                nickName: user.nickname,
                diamonds: user.diamonds,
                gold: user.gold,
                picUrl: user.picUrl || '',
                vip: user.vip
            } 
        });
});

router.post('/api/v1/emails/password/reset', async (req ,res) => {
    const email = req.query.email;
    const emails = await User.findOne({ email });
    
    if (!emails) {
            return res.status(404).json({ 
                code: 1, 
                message: 'Email not found', 
                data: null 
            });
    }
    
    res.status(200).json({ 
            code: 1, 
            message: 'SUCCESS', 
            data: {
                userId: user.userId,
                nickName: user.nickname,
                diamonds: user.diamonds,
                gold: user.gold,
                picUrl: user.picUrl || '',
                vip: user.vip
            } 
        });
});

router.post('/api/v1/email/bind', async (req, res) => {
    const userId = req.headers.userid;
    const user = await User.findOne({ userId });
    const email = await client.get(`CACHE_EMAIL_BIND_${userId}`);
    if (req.query.verifyCode == 265178) {
        user.email = email;
        await user.save()
        await client.del(`CACHE_EMAIL_BIND_${userId}`);
        return res.status(200).json({ 
            code: 1, 
            message: 'SUCCESS', 
            data: null
        });
    } else {
        if (!user) {
            return res.status(404).json({ 
                code: 1, 
                message: 'User not found', 
                data: null 
            });
        }
        res.status(200).json({ 
            code: 108, 
            message: 'Incorrect code.', 
            data: null
        });
    }
});

router.delete('/api/v1/email/bind', async (req, res) => {
    const userId = req.headers.userid;
    
    if (req.query.verifyCode == 265178) {
        const user = await User.findOne({ userId });
        if (!user) {
            return res.status(404).json({ 
                code: 1, 
                message: 'User not found', 
                data: null 
            });
        }
            user.email = '';
            await user.save();
        res.status(200).json({ 
            code: 1, 
            message: 'SUCCESS', 
            data: null
        });
    } else {
        res.status(200).json({ 
            code: 108, 
            message: 'Incorrect code.', 
            data: null
        });
    }
});

router.post('/api/v1/email/send', async (req, res) => {
    if (req.query.bindType == 0) {
        const email = req.body.email;
        const userId = req.headers.userid;
        
        if (!email || typeof email !== 'string') {
            return res.status(400).json({ 
                code: 400, 
                message: 'Invalid email provided.', 
                data: null
            });
        }
        
        const user = await User.findOne({ userId });
        const emails = await User.findOne({ email });
        
        if (emails) {
            return res.status(200).json({ 
                code: 108, 
                message: 'Email is already bound to another account.', 
                data: null
            });
        }
        await client.set(`CACHE_EMAIL_BIND_${userId}`, email); // expires in 10 minutes
        return res.status(200).json({ 
                code: 1, 
                message: 'SUCCESS', 
                data: {
                    userId: user.userId,
                    nickName: user.nickname,
                    diamonds: user.diamonds,
                    gold: user.gold,
                    picUrl: user.picUrl || '',
                    vip: user.vip
                } 
        });
    } else {
        const userId = req.headers.userid;
        const user = await User.findOne({ userId });
        return res.status(200).json({ 
                code: 1, 
                message: 'SUCCESS', 
                data: {
                    userId: user.userId,
                    nickName: user.nickname,
                    diamonds: user.diamonds,
                    gold: user.gold,
                    picUrl: user.picUrl || '',
                    email: user.email,
                    vip: user.vip
                } 
        });
    }
});

router.put('/api/v1/user/info', async (req, res) => {
    const birthday = req.body.birthday;
    const details = req.body.details;
 if (!details) {
    const userId = req.headers.userid;
    
    const user = await User.findOne({ userId });
    
    if (!user) {
            return res.status(404).json({ 
                code: 1, 
                message: 'User not found', 
                data: null 
            });
    }
    
    user.birthday = birthday;
    await user.save();
    
    const userInfo = {
        userId: user.userId,
        sex: user.sex || 2,
        nickName: user.nickname,
        birthday: user.birthday || '',
        details: user.introduction,
        diamonds: user.diamonds,
        golds: user.gold,
        picUrl: user.picUrl || '',
        email: user.email || '',
        isFreeNickname: user.isFreeNickname || true,
        hasPassword: true,
        stopToTime: null
    };

    return res.status(200).json({ code: 1, message: 'SUCCESS', data: userInfo });
 }
 
    const userId = req.headers.userid;
    
    const user = await User.findOne({ userId });
    
    if (!user) {
            return res.status(404).json({ 
                code: 1, 
                message: 'User not found', 
                data: null 
            });
    }
    
    user.introduction = details;
    await user.save();
    
    const userInfo = {
        userId: user.userId,
        sex: user.sex || 2,
        nickName: user.nickname,
        birthday: user.birthday || '',
        details: user.introduction,
        diamonds: user.diamonds,
        golds: user.gold,
        picUrl: user.picUrl || '',
        email: user.email || '',
        isFreeNickname: user.isFreeNickname || true,
        hasPassword: true,
        stopToTime: null
    };

    res.status(200).json({ code: 1, message: 'SUCCESS', data: userInfo });
});

router.get('/api/v1/user/nickName/free', async (req, res) => {
    const userId = req.headers.userid;
    const user = await User.findOne({ userId });

    const response = {
        currencyType: 1,
        quantity: 50,
        free: user.isFreeNickname
    }
    
    res.status(200).json({ code: 1, message: 'SUCCESS', data: response });
});

router.get('/api/v1/app/auth-token', async (req, res) => {
    const userId = req.headers.userid;
    res.status(200).json({ code: 1, message: 'SUCCESS', data: userId });
});

router.put('/api/v1/user/nickName', async (req, res) => {
    const userId = req.headers.userid;
    const user = await User.findOne({ userId });
    const newNickname = req.query.newName;
    if (!newNickname) {
        return Responses.invalidParameter();
    }

    const isNicknameExists = await User.findOne({ nickname: newNickname });
    if (isNicknameExists) {
        return res.status(200).json({
                code: 1003,
                message: "Nickname is already in use",
                data: null
        });
    }
    
    if (user.nickname == newNickname) {
        return res.status(200).json({
                code: 3,
                message: "Invalid parameter",
                data: null
        });
    }

    let result = 0;
    if (user.isFreeNickname) {
        user.isFreeNickname = false;
        await user.save();
    } else {
        if (user.diamonds < 50) {
            result = 1;
        } else {
            user.diamonds = (user.diamonds - 50);
            await user.save();
        }
    }

    if (result == 1) {
        return res.status(200).json({ code: 5006, message: 'Not enough diamonds or gold', data: null });
    }

    user.nickname = newNickname;
    await user.save();

    const userInfo = {
        userId: user.userId,
        sex: user.sex || 2,
        nickName: user.nickname,
        birthday: user.birthday || '',
        details: user.introduction,
        diamonds: user.diamonds,
        golds: user.gold,
        picUrl: user.picUrl || '',
        email: user.email || '',
        hasPassword: true,
        stopToTime: null
    };

    res.status(200).json({ code: 1, message: 'SUCCESS', data: userInfo });
});

router.post('/api/v1/user/language', async (req, res) => {
    res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.get('/api/v1/users/:userId/daily/tasks/ads/config', async (req, res) => {
    res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.get('/api/v1/user/details/info', async (req, res) => {
    const userId = req.headers.userid;
    const user = await User.findOne({ userId });
    res.status(200).json({ code: 1, message: 'SUCCESS', data: user.vip });
});

/** APK IUserApi.getRongToken — RongCloud IM token (not FCM device push). */
router.get('/api/v1/users/device/token', async (req, res) => {
  const userId = req.headers.userid || req.headers.userId || req.query.userId;
  const body = await getDeviceToken(userId);
  res.status(200).json(body);
});

router.get('/api/v1/user/avatars', async (req, res) => {
    const pageNo = parseInt(req.query.pageNo) || 0;
    const pageSize = parseInt(req.query.pageSize) || 10;
    const userId = req.headers.userid;
    const user = await User.findOne({ userId });
    
    const avatars = [
        {
            
        }
    ]
    
    if (pageNo !== 0) {
            return res.status(200).json({
                code: 1,
                message: 'SUCCESS',
                data: {
                    pageNo,
                    pageSize,
                    totalPage: 0,
                    totalSize: 0,
                    data: []
                }
            });
        }

        res.status(200).json({
            code: 1,
            message: 'SUCCESS',
            data: {
                pageNo,
                pageSize,
                totalPage: 0,
                totalSize: 0,
                data: avatars,
                other: null
            }
        });
});

module.exports = router;