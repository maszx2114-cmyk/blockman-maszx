const express = require('express');
const fs = require('fs');
const path = require('path');
const gamesCatalog = require('../lib/gamesCatalog');
const hostConfig = require('../config/host');
const {
  readDecorationType,
  resolveUserSex,
  resolveProfileSex,
  decorationMatchesSex,
  normalizeDecorationItem,
  sanitizeUserDressing,
  applyDefaultDressingForNewUser,
} = require('../lib/decorHelpers');

const router = express.Router();

const SHOP_PROPS_PATH = path.join(__dirname, '../data/game-props-shop.json');
const GAME_DATA_DIR = path.join(process.cwd(), 'data/game-data');
const USER_STORE_DIR = process.env.USER_STORE_DIR || path.join(process.cwd(), 'data/user-profiles');
const DISPATCH_DRESSING_DIR = process.env.DISPATCH_DRESSING_DIR || path.join(process.cwd(), 'data/dispatch-dressing');
const USER_WALLET_DIR = process.env.WALLET_DIR || path.join(process.cwd(), 'data/user-wallets');

const DEFAULT_GAME_PROPS = [
  {
    propsId: 100001,
    gameId: 'g1014',
    type: 'all',
    name: 'Jail Break Starter Pack',
    iconUrl: `${hostConfig.cdnUrl}game-props/g1014/starter-pack.png`,
    desc: 'Starter bundle for Jail Break.',
    currency: 2,
    price: 120,
    quantity: 1,
    limitCount: 0,
    expireType: 0,
    expireTime: 0,
    status: 0,
  },
  {
    propsId: 100002,
    gameId: 'g1014',
    type: 'weapon',
    name: 'Shotgun Ammo Pack',
    iconUrl: `${hostConfig.cdnUrl}game-props/g1014/shotgun-ammo.png`,
    desc: 'Additional ammo for shotgun.',
    currency: 2,
    price: 80,
    quantity: 1,
    limitCount: 0,
    expireType: 0,
    expireTime: 0,
    status: 0,
  },
  {
    propsId: 100003,
    gameId: 'g1014',
    type: 'boost',
    name: 'Prisoner Escape Boost',
    iconUrl: `${hostConfig.cdnUrl}game-props/g1014/escape-boost.png`,
    desc: 'Temporary speed boost for escapes.',
    currency: 0,
    price: 20,
    quantity: 1,
    limitCount: 0,
    expireType: 1,
    expireTime: 3600,
    status: 0,
  },
  {
    propsId: 200001,
    gameId: 'g1008',
    type: 'all',
    name: 'Bed Wars Resource Pack',
    iconUrl: `${hostConfig.cdnUrl}game-props/g1008/resource-pack.png`,
    desc: 'Quick resources for early game.',
    currency: 2,
    price: 150,
    quantity: 1,
    limitCount: 0,
    expireType: 0,
    expireTime: 0,
    status: 0,
  },
];

function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function safeReadJson(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (_) {
    return fallback;
  }
}

function loadGamePropsCatalog() {
  const fromFile = safeReadJson(SHOP_PROPS_PATH, null);
  if (Array.isArray(fromFile) && fromFile.length > 0) {
    return fromFile;
  }
  return DEFAULT_GAME_PROPS;
}

function paginate(list, pageNo, pageSize) {
  const start = pageNo * pageSize;
  return list.slice(start, start + pageSize);
}

function readUserProfile(userId) {
  const uid = String(userId || '').trim();
  if (!uid) return null;
  const profile = safeReadJson(path.join(USER_STORE_DIR, `${uid}.json`), null);
  if (!profile) return null;
  applyDefaultDressingForNewUser(profile);
  sanitizeUserDressing(profile);
  return profile;
}

function formatColoredNickname(nickname, colorHex) {
  const baseName = String(nickname || '').trim();
  return baseName;
}

function walletPath(userId) {
  return path.join(USER_WALLET_DIR, `${userId}.json`);
}

function readWallet(userId) {
  return safeReadJson(walletPath(userId), { userId: Number(userId), gold: 0, diamonds: 0, gcubes: 0 });
}

function writeWallet(userId, wallet) {
  fs.mkdirSync(USER_WALLET_DIR, { recursive: true });
  fs.writeFileSync(walletPath(userId), `${JSON.stringify({ ...wallet, userId: Number(userId) }, null, 2)}\n`, 'utf8');
}

function writeUserProfile(userId, profile) {
  const uid = String(userId || '').trim();
  if (!uid) return;
  sanitizeUserDressing(profile);
  fs.mkdirSync(USER_STORE_DIR, { recursive: true });
  fs.writeFileSync(path.join(USER_STORE_DIR, `${uid}.json`), `${JSON.stringify(profile, null, 2)}\n`, 'utf8');
}

function syncOwnedToDispatch(userId, profile) {
  try {
    const uid = String(userId || '').trim();
    if (!uid) return;
    const ownedIds = (profile?.dressingOwned || [])
      .map((x) => toNumber(x?.id || x, 0))
      .filter((x) => x > 0);
    const dir = path.join(DISPATCH_DRESSING_DIR, 'owned');
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, `${uid}.json`), JSON.stringify(ownedIds), 'utf8');
  } catch (_) {}
}

function ownedDecorSet(user) {
  return new Set((user?.dressingOwned || []).map((x) => toNumber(x?.id || x, 0)).filter((x) => x > 0));
}

function loadDecorationShopCatalog(typeId) {
  const rows = readDecorationType(toNumber(typeId, 0));
  if (!Array.isArray(rows)) return [];
  return rows.map((item) => normalizeDecorationItem(item, false, false));
}

function extractUserIdsFromDir(dirPath, pattern) {
  try {
    const files = fs.readdirSync(dirPath);
    const ids = [];
    for (const file of files) {
      const match = file.match(pattern);
      if (match) {
        ids.push(toNumber(match[1], 0));
      }
    }
    return ids.filter((id) => id > 0);
  } catch (_) {
    return [];
  }
}

function loadGameDataScore(userId) {
  const candidates = [];
  try {
    const files = fs.readdirSync(GAME_DATA_DIR);
    for (const file of files) {
      if (file.startsWith(`${userId}_`) || file.endsWith(`_${userId}.json`)) {
        candidates.push(path.join(GAME_DATA_DIR, file));
      }
    }
  } catch (_) {
    return 0;
  }

  let bestScore = 0;
  for (const filePath of candidates) {
    const data = safeReadJson(filePath, null);
    if (!data || typeof data !== 'object') continue;
    const merit = toNumber(data.merit, 0);
    const money = Math.floor(toNumber(data.money, 0) / 1000);
    const wage = toNumber(data.todayWage, 0);
    const currentScore = merit * 100 + money + wage;
    if (currentScore > bestScore) {
      bestScore = currentScore;
    }
  }
  return bestScore;
}

function buildRankingUsers() {
  const ids = new Set();
  for (const uid of extractUserIdsFromDir(GAME_DATA_DIR, /^(\d+)_\d+\.json$/)) {
    ids.add(uid);
  }

  const users = Array.from(ids).map((userId) => {
    // Ranking must reflect in-game progress only, not account wealth/bcubes.
    const integral = loadGameDataScore(userId);
    return {
      userId,
      nickName: `Player${userId}`,
      headPic: '',
      vip: 0,
      integral,
    };
  });

  users.sort((a, b) => {
    if (b.integral !== a.integral) return b.integral - a.integral;
    return a.userId - b.userId;
  });

  return users.map((u, idx) => ({ ...u, rank: idx + 1 }));
}

router.post('/geoinfo/api/v1/userGeoInfo', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.put('/game/api/v1/games/engine', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.get('/game/api/v2/games/recommendation', (req, res) => {
  const games = gamesCatalog.listGames();
  res.status(200).json(gamesCatalog.pagedResponse(games, 0, 10));
});

router.post('/user/api/v1/user/daily/life/info', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: {} });
});

router.put('/user/api/v1/user/device/id', (req, res) => {
  const { handleDeviceIdPut } = require('../lib/deviceRoute');
  return handleDeviceIdPut(req, res);
});

router.get('/activity/api/v1/lucky/turntable/gold/status', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: { status: 0 } });
});

router.get('/activity/api/v1/lucky/turntable', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: { items: [], status: 0 } });
});

/** APK lobby: GET /friend/api/v1/friends?pageNo=0&pageSize=200 (must not hang on Mongo) */
router.get('/friend/api/v1/friends', (req, res) => {
  const pageNo = parseInt(req.query.pageNo, 10) || 0;
  const pageSize = parseInt(req.query.pageSize, 10) || 10;
  res.status(200).json({
    code: 1,
    message: 'SUCCESS',
    data: {
      pageNo,
      pageSize,
      totalPage: 0,
      totalSize: 0,
      data: [],
      other: null,
    },
  });
});

/** APK: GET /friend/api/v1/friends/:userId (numeric only, avoid shadowing /status,/recommendation) */
router.get('/friend/api/v1/friends/:userId(\\d+)', (req, res) => {
  res.status(200).json({
    code: 1,
    message: 'SUCCESS',
    data: {
      pageNo: 0,
      pageSize: 10,
      totalPage: 0,
      totalSize: 0,
      data: [],
      other: null,
    },
  });
});

function handleGamePropsList(req, res) {
  const gameId = String(req.query.gameId || req.query.targetId || 'g1014');
  const type = String(req.query.type || 'all');
  const pageNo = Math.max(0, parseInt(req.query.pageNo, 10) || 0);
  const pageSize = Math.max(1, Math.min(200, parseInt(req.query.pageSize, 10) || 100));

  const allProps = loadGamePropsCatalog().filter((item) => {
    if (item.gameId !== gameId) return false;
    if (!type || type === 'all') return true;
    return String(item.type || 'all') === type;
  }).map((item) => ({
    ...item,
    // For game props shop client, status=0 means not owned and purchasable.
    status: toNumber(item.status, 0),
    isOwned: toNumber(item.isOwned, 0),
  }));

  res.status(200).json({
    code: 1,
    message: 'SUCCESS',
    data: paginate(allProps, pageNo, pageSize),
  });
}

router.get('/shop/api/:version/shop/game/props', handleGamePropsList);
router.get('/shop/api/:version/shop/game/props/new', handleGamePropsList);

router.get('/shop/api/:version/shop/decorations/:typeId(\\d+)', (req, res) => {
  const typeId = toNumber(req.params.typeId, 0);
  const currency = req.query.currency !== undefined ? toNumber(req.query.currency, -1) : -1;
  const pageNo = Math.max(0, parseInt(req.query.pageNo, 10) || 0);
  const pageSize = Math.max(1, Math.min(200, parseInt(req.query.pageSize, 10) || 200));

  const userId = String(req.query.userId || req.headers.userid || req.headers.userId || '').trim();
  const profile = readUserProfile(userId);
  const owned = ownedDecorSet(profile);
  const sex = resolveUserSex(profile, req.query.sex);

  let items = loadDecorationShopCatalog(typeId)
    .filter((item) => item.inShop === true || Number(item.price || 0) > 0 || Number(item.isNew || 0) === 1)
    .filter((item) => decorationMatchesSex(item, sex))
    .map((item) => ({
      ...item,
      hasPurchase: owned.has(toNumber(item.id, 0)) ? 1 : 0,
      status: 0,
      limited: 0,
      isLimited: 0,
      isLimit: 0,
      limit: 0,
      limitType: 0,
      isTimeLimit: 0,
      remainCount: 0,
      limitCount: 0,
    }));
  // Client often passes currency=0 as "show all".
  if (currency > 0) {
    items = items.filter((item) => item.currency === currency);
  }

  const data = paginate(items, pageNo, pageSize);
  res.status(200).json({ code: 1, message: 'SUCCESS', data });
});

function handleDecorationPurchase(req, res) {
  const userId = String(req.body?.userId || req.headers.userid || req.headers.userId || '').trim();
  const decorationId = toNumber(req.body?.decorationId || req.body?.id, 0);
  if (!userId || !decorationId) {
    return res.status(200).json({ code: 3, message: 'PARAM ERROR', data: null });
  }

  const typeId = toNumber(String(decorationId).slice(0, -5), 0);
  const item = loadDecorationShopCatalog(typeId).find((x) => toNumber(x.id, 0) === decorationId);
  if (!item) {
    return res.status(200).json({ code: 3, message: 'Decoration not found', data: null });
  }

  const profile = readUserProfile(userId) || { userId: Number(userId), sex: 1, dressingOwned: [], dressingUsing: [] };
  const owned = ownedDecorSet(profile);
  if (!owned.has(decorationId)) {
    const wallet = readWallet(userId);
    const price = toNumber(item.price, 0);
    const currency = toNumber(item.currency, 0);
    if (price > 0) {
      if (currency === 1) {
        if (toNumber(wallet.diamonds, 0) < price) {
          return res.status(200).json({ code: 5006, message: 'Not enough diamonds', data: null });
        }
        wallet.diamonds = toNumber(wallet.diamonds, 0) - price;
      } else if (currency === 2) {
        if (toNumber(wallet.gold, 0) < price) {
          return res.status(200).json({ code: 5006, message: 'Not enough gold', data: null });
        }
        wallet.gold = toNumber(wallet.gold, 0) - price;
      }
      writeWallet(userId, wallet);
    }
    profile.dressingOwned = Array.isArray(profile.dressingOwned) ? profile.dressingOwned : [];
    profile.dressingOwned.push({ id: decorationId });
    writeUserProfile(userId, profile);
    syncOwnedToDispatch(userId, profile);
  }

  return res.status(200).json({ code: 1, message: 'SUCCESS', data: { id: decorationId } });
}

router.post('/shop/api/:version/shop/decorations/purchase', handleDecorationPurchase);

router.post('/shop/api/:version/shop/decorations/users/purchase', (req, res) => {
  req.body = { ...req.body, userId: req.body?.userId || req.query?.userId || req.headers.userid || req.headers.userId };
  return handleDecorationPurchase(req, res);
});

router.get('/shop/api/:version/shop/decorations/buy', (req, res) => {
  req.body = {
    userId: req.query.userId || req.headers.userid || req.headers.userId,
    decorationId: req.query.decorationId || req.query.id,
  };
  return handleDecorationPurchase(req, res);
});

function handleUsesRank(req, res) {
  const userId = toNumber(req.query.userId || req.headers.userid || req.headers.userId || 0, 0);
  const type = String(req.query.type || 'all');
  const users = buildRankingUsers();
  const self = users.find((u) => u.userId === userId) || {
    userId,
    nickName: `Player${userId || 0}`,
    headPic: '',
    vip: 0,
    rank: userId > 0 ? users.length + 1 : 0,
    integral: userId > 0 ? 0 : 0,
  };

  res.status(200).json({
    code: 1,
    message: 'SUCCESS',
    data: {
      gameId: req.params.gameId,
      type,
      userId: self.userId,
      rank: self.rank,
      integral: self.integral,
      headPic: self.headPic || '',
      nickName: self.nickName,
      vip: toNumber(self.vip, 0),
      // keep optional list for clients that need preview of top players
      topUsers: users.slice(0, 100).map((u, idx) => ({
        userId: u.userId,
        headPic: u.headPic || '',
        nickName: u.nickName,
        integral: u.integral,
        rank: idx + 1,
        vip: toNumber(u.vip, 0),
        isFirst: idx === 0,
      })),
    },
  });
}

function handleFullRank(req, res) {
  const pageNo = Math.max(0, parseInt(req.query.pageNo, 10) || 0);
  const pageSize = Math.max(1, Math.min(100, parseInt(req.query.pageSize, 10) || 20));
  const users = buildRankingUsers();
  res.status(200).json({
    code: 1,
    message: 'SUCCESS',
    data: {
      remainTime: 0,
      pageInfo: {
        pageNo,
        pageSize,
        totalPage: users.length > 0 ? Math.ceil(users.length / pageSize) : 0,
        totalSize: users.length,
        data: paginate(users, pageNo, pageSize),
      },
    },
  });
}

router.get('/game/api/v1/games/:gameId/uses/rank', handleUsesRank);
router.get('/game/api/v1/games/:gameId/rank', handleFullRank);
router.get('/game/api/v1/inner/games/:gameId/uses/rank', handleUsesRank);
router.get('/game/api/v1/inner/games/:gameId/rank', handleFullRank);

router.post('/game/api/v1/game/chat/room', (req, res) => {
  const roomName = req.query.roomName || 'party';
  res.status(200).json({
    code: 1,
    message: 'SUCCESS',
    data: { roomId: `local-${roomName}`, roomName },
  });
});

router.get('/user/api/v1/inner/user/details', (req, res) => {
  const userId = String(req.query.userId || req.headers.userid || '0');
  const profile = readUserProfile(userId);
  const rawNickName = String(profile?.nickname || '').trim() || `Player${userId}`;
  const nickName = formatColoredNickname(rawNickName, profile?.nickColor);
  res.status(200).json({
    code: 1,
    message: 'SUCCESS',
    data: {
      userId: Number(userId),
      nickName,
      clanName: '',
      role: 0,
      propsId: [],
    },
  });
});

router.get('/user/api/v1/inner/simple-info', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: [] });
});

router.get('/gameaide/api/v1/inner/user/game/props', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: [] });
});

router.get('/activity/api/v1/inner/activity/games/settlement/rule', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

router.get('/appconfigs/lang/games/en/recommendation.json', (req, res) => {
  res.redirect(`${hostConfig.cdnUrl}appconfigs/lang/games/en/g1008.json`);
});

/** GameServer RedisHttpRequest: GET /api/v1/game/rank?key=&member= */
router.get('/api/v1/game/rank', (req, res) => {
  res.status(200).json({
    code: 1,
    message: 'Success',
    data: { score: 0, rank: -1 },
  });
});

/** GameServer RedisHttpRequest: POST /api/v1/game/rank (ZIncrBy batch) */
router.post('/api/v1/game/rank', (req, res) => {
  res.status(200).json({ code: 1, message: 'Success', data: null });
});

router.get('/api/v1/game/rank/list', (req, res) => {
  res.status(200).json({ code: 1, message: 'Success', data: [] });
});

router.put('/api/v1/game/rank/expire', (req, res) => {
  res.status(200).json({ code: 1, message: 'Success', data: null });
});

const skyblockPartyOk = { code: 1, message: 'SUCCESS', data: [] };
const skyblockPartyInfo = { code: 1, message: 'SUCCESS', data: { partyName: '', partyDesc: '', memberList: [] } };

router.get('/gameaide/api/v1/inner/game/party/list/:gameId', (req, res) => {
  res.status(200).json(skyblockPartyOk);
});
router.get('/gameaide/api/v1/inner/friend/game/party/list/:gameId/:userId', (req, res) => {
  res.status(200).json(skyblockPartyOk);
});
router.get('/gameaide/api/v1/inner/game/party/info/:gameId/:userId', (req, res) => {
  res.status(200).json(skyblockPartyInfo);
});
router.get('/gameaide/api/v1/inner/game/party/like/:gameId/:userId', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: { likeNum: 0 } });
});
router.get('/gameaide/api/v1/inner/game/party/freeTime/:gameId/:userId', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: { freeTime: 0 } });
});
router.get('/gameaide/api/v1/inner/my/game/build', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: {} });
});
router.get('/gameaide/api/v1/inner/game/build/member', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: [] });
});
router.post('/gameaide/api/v1/inner/game/party/create', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});
router.post('/gameaide/api/v1/inner/game/party/update', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});
router.post('/gameaide/api/v1/inner/game/party/like', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});
router.post('/gameaide/api/v1/inner/game/party/add', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});
router.post('/gameaide/api/v1/inner/game/party/reduce', (req, res) => {
  res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

module.exports = router;
