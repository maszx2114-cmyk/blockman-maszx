const express = require('express');
const mongoose = require('mongoose');
const router = express.Router(); 
const Responses = require("../Responses");
const WheelTypes = require("../constants/WheelTypes");
const activityListConfig = require("../config/activities");
const ActivityLoginStatuses = require("../constants/ActivityLoginStatuses");
const ActivityTypes = require("../constants/ActivityTypes");
const luckywheel = require("../config/luckywheel");
const ActivityManager = require("../activities/manager");

const { log, startupSequence } = require('../logger');
const logger = require('../logger');
const User = mongoose.model('User');
const fs = require('fs');
const path = require('path');
const ACTIVITY_CLAIMS_DIR = path.join(process.cwd(), 'data/activity-claims');

function toNumber(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
}

function getWeekKey(ts = Date.now()) {
    const d = new Date(ts);
    const jan1 = new Date(d.getFullYear(), 0, 1);
    const day = Math.floor((d - jan1) / 86400000);
    const week = Math.ceil((day + jan1.getDay() + 1) / 7);
    return `${d.getFullYear()}-W${week}`;
}

function claimFile(userId) {
    return path.join(ACTIVITY_CLAIMS_DIR, `${String(userId || '0')}.json`);
}

function readClaims(userId) {
    try {
        const p = claimFile(userId);
        if (!fs.existsSync(p)) return {};
        return JSON.parse(fs.readFileSync(p, 'utf8')) || {};
    } catch (_) {
        return {};
    }
}

function writeClaims(userId, data) {
    try {
        fs.mkdirSync(ACTIVITY_CLAIMS_DIR, { recursive: true });
        fs.writeFileSync(claimFile(userId), `${JSON.stringify(data || {}, null, 2)}\n`, 'utf8');
    } catch (_) {}
}

const rewards = {
    "gold": {
        "rewardConfig": [
            { "rewardId": 0, "weight": 1 },
            { "rewardId": 1, "weight": 20, "rewardDressId_1": 800025, "rewardDressId_2": 800028, "luckValue": 5 },
            { "rewardId": 2, "weight": 20, "rewardDressId_1": 900025, "rewardDressId_2": 900026, "luckValue": 5 },
            { "rewardId": 3, "weight": 20, "rewardDressId_1": 1000011, "rewardDressId_2": 400035, "luckValue": 5 },
            { "rewardId": 4, "weight": 25, "rewardQty": 1 },
            { "rewardId": 5, "weight": 15, "rewardDressId_1": 700005, "rewardDressId_2": 700005, "luckValue": 5 },
            { "rewardId": 6, "weight": 20, "rewardDressId_1": 200030, "rewardDressId_2": 200030, "luckValue": 5 },
            { "rewardId": 7, "weight": 10, "rewardVipLevel": 1, "rewardVipDays": 7 },
            { "rewardId": 8, "weight": 1, "rewardVipLevel": 3, "rewardVipDays": 7 },
            { "rewardId": 9, "weight": 15, "rewardDressId_1": 1000031, "rewardDressId_2": 1000030, "luckValue": 5 },
            { "rewardId": 10, "weight": 15, "rewardDressId_1": 900085, "rewardDressId_2": 900086, "luckValue": 5 },
            { "rewardId": 11, "weight": 15 , "rewardDressId_1": 800087, "rewardDressId_2": 800088, "luckValue": 5 },
            { "rewardId": 12, "weight": 20, "rewardQty": 3 },
            { "rewardId": 13, "weight": 0.1, "rewardDressId_1": 1400001, "rewardDressId_2": 1400001, "luckValue": 5 },
            { "rewardId": 14, "weight": 20, "rewardDressId_1": 400041, "rewardDressId_2": 400041, "luckValue": 5 },
            { "rewardId": 15, "weight": 3, "rewardQty": 50 }
        ],
        "rewardInfoList_1": [
            { "pic": "http://localhost:3000/events/gold_block.png", "rewardId": 0, "rewardName": "Gold Block", "rewardType": "block" },
            { "pic": "http://localhost:3000/icons/top/800025.png", "rewardId": 1, "rewardName": "Captain's Shirt", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/pants/900025.png", "rewardId": 2, "rewardName": "Captain's Pants", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/shoes/1000011.png", "rewardId": 3, "rewardName": "Captain's Shoes", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/bcubes.png", "rewardId": 4, "rewardName": "1 Bcube", "rewardType": "diamond" },
            { "pic": "http://localhost:3000/icons/background/700005.png", "rewardId": 5, "rewardName": "Summer Background", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/hair/200030.png", "rewardId": 6, "rewardName": "Hair", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/vip.png", "rewardId": 7, "rewardName": "VIP 7 days", "rewardType": "vip" },
            { "pic": "http://localhost:3000/events/mvp.png", "rewardId": 8, "rewardName": "MVP 7 days", "rewardType": "vip" },
            { "pic": "http://localhost:3000/icons/shoes/1000031.png", "rewardId": 9, "rewardName": "Hawaii Shoes", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/pants/900085.png", "rewardId": 10, "rewardName": "Hawaii Pants", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/top/800087.png", "rewardId": 11, "rewardName": "Hawaii Shirt", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/bcubes.png", "rewardId": 12, "rewardName": "3 Bcubes", "rewardType": "diamond" },
            { "pic": "http://localhost:3000/icons/wings/1400001.png", "rewardId": 13, "rewardName": "Angel Wings", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/face/400041.png", "rewardId": 14, "rewardName": "xD Face", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/bcubes.png", "rewardId": 15, "rewardName": "50 Bcubes", "rewardType": "diamond" }
        ],
        "rewardInfoList_2": [
            { "pic": "http://localhost:3000/events/gold_block.png", "rewardId": 0, "rewardName": "Gold Block", "rewardType": "block" },
            { "pic": "http://localhost:3000/icons/top/800028.png", "rewardId": 1, "rewardName": "Shirt", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/pants/900026.png", "rewardId": 2, "rewardName": "Pants", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/face/400035.png", "rewardId": 3, "rewardName": "Face", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/bcubes.png", "rewardId": 4, "rewardName": "1 Bcube", "rewardType": "diamond" },
            { "pic": "http://localhost:3000/icons/background/700005.png", "rewardId": 5, "rewardName": "Summer Background", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/hair/200030.png", "rewardId": 6, "rewardName": "Hair", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/vip.png", "rewardId": 7, "rewardName": "VIP 7 days", "rewardType": "vip" },
            { "pic": "http://localhost:3000/events/mvp.png", "rewardId": 8, "rewardName": "MVP 7 days", "rewardType": "vip" },
            { "pic": "http://localhost:3000/icons/shoes/1000030.png", "rewardId": 9, "rewardName": "Hawaii Shoes", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/pants/900086.png", "rewardId": 10, "rewardName": "Hawaii Pants", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/top/800088.png", "rewardId": 11, "rewardName": "Hawaii Shirt", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/bcubes.png", "rewardId": 12, "rewardName": "3 Bcubes", "rewardType": "diamond" },
            { "pic": "http://localhost:3000/icons/wings/1400001.png", "rewardId": 13, "rewardName": "Angel Wings", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/face/400041.png", "rewardId": 14, "rewardName": "xD Face", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/bcubes.png", "rewardId": 15, "rewardName": "50 Bcubes", "rewardType": "diamond" }
        ]
    },
    "diamond": {
        "rewardConfig": [
            { "rewardId": 0, "weight": 1 },
            { "rewardId": 1, "weight": 15, "rewardDressId_1": 200023, "rewardDressId_2": 200047, "luckValue": 5 },
            { "rewardId": 2, "weight": 15, "rewardDressId_1": 800031, "rewardDressId_2": 800083, "luckValue": 5 },
            { "rewardId": 3, "weight": 15, "rewardDressId_1": 900031, "rewardDressId_2": 900083, "luckValue": 5 },
            { "rewardId": 4, "weight": 15, "rewardDressId_1": 1000008, "rewardDressId_2": 1000028, "luckValue": 5 },
            { "rewardId": 5, "weight": 3, "rewardQty": 100 },
            { "rewardId": 6, "weight": 20, "rewardDressId_1": 500021, "rewardDressId_2": 500021, "luckValue": 5 },
            { "rewardId": 7, "weight": 20, "rewardDressId_1": 400042, "rewardDressId_2": 400042, "luckValue": 5 },
            { "rewardId": 8, "weight": 5, "rewardVipLevel": 2, "rewardVipDays": 15 },
            { "rewardId": 9, "weight": 1, "rewardQty": 10 },
            { "rewardId": 10, "weight": 20, "rewardDressId_1": 500020, "rewardDressId_2": 500020, "luckValue": 5 },
            { "rewardId": 11, "weight": 10, "rewardVipLevel": 1, "rewardVipDays": 30 },
            { "rewardId": 12, "weight": 1, "rewardQty": 20 },
            { "rewardId": 13, "weight": 1, "rewardDressId_1": 1400015, "rewardDressId_2": 1400016, "luckValue": 5 },
            { "rewardId": 14, "weight": 20, "rewardDressId_1": 400043, "rewardDressId_2": 400043, "luckValue": 5 },
            { "rewardId": 15, "weight": 1, "rewardVipLevel": 3, "rewardVipDays": 7 }
        ],
        "rewardInfoList_1": [
            { "pic": "http://localhost:3000/events/colorful_block.png", "rewardId": 0, "rewardName": "Colorful Block", "rewardType": "block" },
            { "pic": "http://localhost:3000/icons/hair/200023.png", "rewardId": 1, "rewardName": "Iron's Headgear", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/top/800031.png", "rewardId": 2, "rewardName": "Iron's Chestplate", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/pants/900031.png", "rewardId": 3, "rewardName": "Iron's Leggings", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/shoes/1000008.png", "rewardId": 4, "rewardName": "Iron's Shoes", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/bcubes.png", "rewardId": 5, "rewardName": "100", "rewardType": "diamond" },
            { "pic": "http://localhost:3000/icons/animation/500021.png", "rewardId": 6, "rewardName": "Dancing the seaweed dance", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/face/400042.png", "rewardId": 7, "rewardName": "Shocked face", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/vipplus.png", "rewardId": 8, "rewardName": "VIP+ 15 days", "rewardType": "vip" },
            { "pic": "http://localhost:3000/events/bcubes.png", "rewardId": 9, "rewardName": "10", "rewardType": "diamond" },
            { "pic": "http://localhost:3000/icons/animation/500020.png", "rewardId": 10, "rewardName": "", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/vip.png", "rewardId": 11, "rewardName": "VIP 30 days", "rewardType": "vip" },
            { "pic": "http://localhost:3000/events/bcubes.png", "rewardId": 12, "rewardName": "20", "rewardType": "diamond" },
            { "pic": "http://localhost:3000/icons/wings/1400015.png", "rewardId": 13, "rewardName": "Iron's Wings", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/face/400043.png", "rewardId": 14, "rewardName": "Crying face", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/mvp.png", "rewardId": 15, "rewardName": "MVP 7 days", "rewardType": "vip" }
        ],
        "rewardInfoList_2": [
            { "pic": "http://localhost:3000/events/colorful_block.png", "rewardId": 0, "rewardName": "Colorful Block", "rewardType": "block" },
            { "pic": "http://localhost:3000/icons/hair/200047.png", "rewardId": 1, "rewardName": "Captain's Hair", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/top/800083.png", "rewardId": 2, "rewardName": "Captain's Shirt", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/pants/900083.png", "rewardId": 3, "rewardName": "Captain's Pants", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/shoes/1000028.png", "rewardId": 4, "rewardName": "Captain's Shoes", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/bcubes.png", "rewardId": 5, "rewardName": "100", "rewardType": "diamond" },
            { "pic": "http://localhost:3000/icons/animation/500021.png", "rewardId": 6, "rewardName": "Dancing the seaweed dance", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/face/400042.png", "rewardId": 7, "rewardName": "Shocked face", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/vipplus.png", "rewardId": 8, "rewardName": "VIP+ 15 days", "rewardType": "vip" },
            { "pic": "http://localhost:3000/events/bcubes.png", "rewardId": 9, "rewardName": "10", "rewardType": "diamond" },
            { "pic": "http://localhost:3000/icons/animation/500020.png", "rewardId": 10, "rewardName": "", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/vip.png", "rewardId": 11, "rewardName": "VIP 30 days", "rewardType": "vip" },
            { "pic": "http://localhost:3000/events/bcubes.png", "rewardId": 12, "rewardName": "20", "rewardType": "diamond" },
            { "pic": "http://localhost:3000/icons/wings/1400016.png", "rewardId": 13, "rewardName": "Captain's Cape", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/icons/face/400043.png", "rewardId": 14, "rewardName": "Crying face", "rewardType": "decoration" },
            { "pic": "http://localhost:3000/events/mvp.png", "rewardId": 15, "rewardName": "MVP 7 days", "rewardType": "vip" }
        ]
    }
}

    for (let i = 0; i < activityListConfig.length; i++) {
        try {
            //require(`@activities/${activityListConfig[i]}/tests`);
            
            const activityConfig = require(`../activities/${activityListConfig[i]}/config.json`);
            const activityHandler = require(`../activities/${activityListConfig[i]}/activity`);
            
            const activity = new Activity();
            activity.setName(activityConfig.name);
            activity.setType(activityConfig.type);
            activity.setStartTime(activityConfig.startTime);
            activity.setEndTime(activityConfig.endTime);
            activity.setHandler(activityHandler);
            
            activities[activityListConfig[i]] = activity;

            logger.info(`Activity Manager: loaded activity '${activity.getName()}'`);
        } catch (err) {
            logger.error(`Activity (config or handler) is likely missing (${activityListConfig[i]})`);
            logger.error(err);
        }
    }

async function getActivityList(userId) {
    logger.warn("GetActivityList: Implementation needed");
    return Responses.success({
        activityTitleList: [
            { "titleName": "Currency Frenzy", "titleType": "weekend", "content": "Weekend Login Gift" },
            { "titleName": "Login Gift", "pic": "http://static.sandboxol.com/sandbox/activity/sign_up_gift/sign_gift.png", "content": "activity:sign" },
            { "titleName": "Prize Wheel", "pic": "http://static.sandboxol.com/sandbox/activity/banner/actwheel.png", "content": "activity:wheel" }
        ]
    });
}

async function getActivityTaskList(userId, activityType) {
    logger.warn("GetActivityTaskList: Implementation needed");
    const actions = [
        {
            "actionId": 7,
            "actionName": "Login on Saturday",
            "quantity": 1,
            "dateType": "day",
            "condition": "6",
            "actionType": "common",
            "actionFlag": "saturday_login",
            "actionRewards": [
                {
                    "rewardName": "1",
                    "rewardType": "diamond",
                    "quantity": 1,
                    "rewardPic": "http://static.sandboxol.com/sandbox/activity/treasurebox/Bcubes.png"
                },
                {
                    "rewardName": "200",
                    "rewardType": "gold",
                    "quantity": 200,
                    "rewardPic": "http://static.sandboxol.com/sandbox/activity/treasurebox/coin.png"
                }
            ]
        },
        {
            "actionId": 8,
            "actionName": "Login on Sunday",
            "quantity": 1,
            "dateType": "day",
            "condition": "7",
            "actionType": "common",
            "actionFlag": "sunday_login",
            "status": 1,
            "actionRewards": [
                {
                    "rewardName": "1",
                    "rewardType": "diamond",
                    "quantity": 1,
                    "rewardPic": "http://static.sandboxol.com/sandbox/activity/treasurebox/Bcubes.png"
                },
                {
                    "rewardName": "200",
                    "rewardType": "gold",
                    "quantity": 200,
                    "rewardPic": "http://static.sandboxol.com/sandbox/activity/treasurebox/coin.png"
                }
            ]
        }
    ];

    return Responses.success(activityType ? actions : []);
}

router.get('/api/v1/activity/title', async (req, res) => {
    logger.warn("GetActivityList: Implementation needed");
    return res.status(200).json({
        code: 1,
        message: "SUCCESS",
        data: {
            activityTitleList: [
                { "titleName": "Currency Frenzy", "titleType": "weekend", "content": "Weekend Login Gift" },
                { "titleName": "Login Gift", "pic": "http://static.sandboxol.com/sandbox/activity/sign_up_gift/sign_gift.png", "content": "activity:sign" },
                { "titleName": "Prize Wheel", "pic": "http://static.sandboxol.com/sandbox/activity/banner/actwheel.png", "content": "activity:wheel" }
            ]
        }
    });
});

router.get('/api/v1/activity/action', async (req, res) => {
    logger.warn("GetActivityTaskList: Implementation needed");
    const userId = String(req.headers.userid || req.headers.userId || req.query.userId || '0').trim();
    const weekKey = getWeekKey();
    const userClaims = readClaims(userId);
    const claimedMap = (userClaims[weekKey] && typeof userClaims[weekKey] === 'object') ? userClaims[weekKey] : {};
    const actions = [
        {
            "actionId": 1,
            "actionName": "Sunday Login Reward",
            "quantity": 1,
            "dateType": "day",
            "condition": "1",
            "actionType": "common",
            "actionFlag": "sunday_login",
            "status": 0,
            "actionRewards": [
                {
                    "rewardName": "Sunday Bonus",
                    "rewardType": "diamond",
                    "quantity": 1000,
                    "rewardPic": "http://static.sandboxol.com/sandbox/activity/treasurebox/Bcubes.png"
                }
            ]
        },
        {
            "actionId": 2,
            "actionName": "Monday Login Reward",
            "quantity": 1,
            "dateType": "day",
            "condition": "1",
            "actionType": "common",
            "actionFlag": "monday_login",
            "status": 0,
            "actionRewards": [
                {
                    "rewardName": "Monday Bonus",
                    "rewardType": "gold",
                    "quantity": 2000,
                    "rewardPic": "http://static.sandboxol.com/sandbox/activity/treasurebox/coin.png"
                }
            ]
        },
        {
            "actionId": 3,
            "actionName": "Tuesday Login Reward",
            "quantity": 1,
            "dateType": "day",
            "condition": "1",
            "actionType": "common",
            "actionFlag": "tuesday_login",
            "status": 0,
            "actionRewards": [
                {
                    "rewardName": "Tuesday Bonus",
                    "rewardType": "diamond",
                    "quantity": 1500,
                    "rewardPic": "http://static.sandboxol.com/sandbox/activity/treasurebox/Bcubes.png"
                }
            ]
        },
        {
            "actionId": 4,
            "actionName": "Wednesday Login Reward",
            "quantity": 1,
            "dateType": "day",
            "condition": "1",
            "actionType": "common",
            "actionFlag": "wednesday_login",
            "status": 0,
            "actionRewards": [
                {
                    "rewardName": "Wednesday Bonus",
                    "rewardType": "gold",
                    "quantity": 2500,
                    "rewardPic": "http://static.sandboxol.com/sandbox/activity/treasurebox/coin.png"
                }
            ]
        },
        {
            "actionId": 5,
            "actionName": "Thursday Login Reward",
            "quantity": 1,
            "dateType": "day",
            "condition": "1",
            "actionType": "common",
            "actionFlag": "thursday_login",
            "status": 0,
            "actionRewards": [
                {
                    "rewardName": "Thursday Bonus",
                    "rewardType": "diamond",
                    "quantity": 2000,
                    "rewardPic": "http://static.sandboxol.com/sandbox/activity/treasurebox/Bcubes.png"
                }
            ]
        },
        {
            "actionId": 6,
            "actionName": "Friday Login Reward",
            "quantity": 1,
            "dateType": "day",
            "condition": "1",
            "actionType": "common",
            "actionFlag": "friday_login",
            "status": 0,
            "actionRewards": [
                {
                    "rewardName": "Friday Bonus",
                    "rewardType": "gold",
                    "quantity": 3000,
                    "rewardPic": "http://static.sandboxol.com/sandbox/activity/treasurebox/coin.png"
                }
            ]
        },
        {
            "actionId": 7,
            "actionName": "Saturday Login Reward",
            "quantity": 1,
            "dateType": "day",
            "condition": "1",
            "actionType": "common",
            "actionFlag": "saturday_login",
            "status": 0,
            "actionRewards": [
                {
                    "rewardName": "Saturday Bonus",
                    "rewardType": "diamond",
                    "quantity": 3000,
                    "rewardPic": "http://static.sandboxol.com/sandbox/activity/treasurebox/Bcubes.png"
                },
                {
                    "rewardName": "Weekend Special",
                    "rewardType": "gold",
                    "quantity": 5000,
                    "rewardPic": "http://static.sandboxol.com/sandbox/activity/treasurebox/coin.png"
                }
            ]
        }
    ];

    let withStatus = actions.map((action) => {
        const key = String(action.actionFlag || action.actionId);
        return { ...action, status: claimedMap[key] ? 2 : 1 };
    });
    if (String(req.query.titleType || '').trim().toLowerCase() === 'weekend') {
        const today = new Date().getDay(); // 0 sunday .. 6 saturday
        withStatus = withStatus
            .filter((x) => x.actionFlag === 'saturday_login' || x.actionFlag === 'sunday_login')
            .map((x) => {
                const canClaim = (x.actionFlag === 'saturday_login' && today === 6) || (x.actionFlag === 'sunday_login' && today === 0);
                if (x.status === 2) return x;
                return { ...x, status: canClaim ? 1 : 0 };
            });
    }

    return res.status(200).json({
        code: 1,
        message: "SUCCESS",
        data: req.query.titleType ? withStatus : [] ?? null
    });
});

router.post('/api/v1/receive/reward', async (req, res) => {
    const userId = String(req.headers.userid || req.headers.userId || req.body?.userId || req.query.userId || '0').trim();
    const actionId = toNumber(req.body?.actionId || req.query.actionId, 0);
    const actionFlag = String(req.body?.actionFlag || req.query.actionFlag || '').trim();
    const claimKey = actionFlag || (actionId > 0 ? String(actionId) : '');
    if (!claimKey) {
        return res.status(200).json({ code: 3, message: 'PARAM ERROR', data: null });
    }
    const weekKey = getWeekKey();
    const userClaims = readClaims(userId);
    userClaims[weekKey] = userClaims[weekKey] || {};
    if (userClaims[weekKey][claimKey]) {
        return res.status(200).json({ code: 3, message: 'Reward already claimed', data: null });
    }
    userClaims[weekKey][claimKey] = Date.now();
    writeClaims(userId, userClaims);
    return res.status(200).json({
        code: 1,
        message: "SUCCESS",
        data: { actionFlag: claimKey, claimedAt: userClaims[weekKey][claimKey] }
    });
});



router.get('/api/v1/signIn', async (req, res) => {
    const rewardsData = {
        signInStatus: ActivityLoginStatuses.CLAIMED,
        userSignInList: rewards
    }
    
    return res.status(200).json({
        code: 1,
        message: "SUCCESS",
        data: rewardsData
    });
});

router.get('/user/api/v2/users/:userid/daily/sign/in', async (req, res) => {
    const rewardsData = {
        signInStatus: ActivityLoginStatuses.CLAIMED,
        userSignInList: rewards
    }
    
    return res.status(200).json({
        code: 1,
        message: "SUCCESS",
        data: rewardsData
    });
});

module.exports = router;