const express = require('express');
const Responses = require("../Responses");
const path = require('path');
const mongoose = require('mongoose');
const { log, startupSequence } = require('../logger');
const logger = require('../logger');
const router = express.Router();
const AssetUtil = require("../AssetUtil");
const axios = require('axios');
const fs = require('fs');
const { issueGameAuth } = require('../lib/gameAuth');
const banService = require('../lib/banService');
const {
    getUserIdFromRequest,
} = require('../lib/userSession');
const { startGameSession, clearGameSession, applyGameReports } = require('../lib/userCareer');
const gamesCatalog = require('../lib/gamesCatalog');
const { pickEngineEntry } = require('../lib/gameResourceConfig');
const hostConfig = require('../config/host');
const GAME_STATS_FILE = path.join(process.cwd(), 'data/game-stats.json');
const crypto = require('crypto');
const CDN_PLUGINS = path.join(__dirname, '../../../bmf-cdn/games/plugins');
const CDN_MAPS = path.join(__dirname, '../../../bmf-cdn/Maps');

function resolveMapDownloadUrl(gameId, engineVersion, mapName) {
    const cdnBase = "https://blockymaszx-server.vercel.app";

    if (String(gameId) === "g1008") {
        return {
            mapName: "m1008_1",
            downloadUrl: `${cdnBase}/maps/m1008_1.zip`,
            mapHash: "",
            mapVersion: 1,
            fileSize: 0,
            resVersion: 1
        };
    }

    const entry = pickEngineEntry(gameId, engineVersion);
    const maps = entry?.maps || [];
    const mapEntry = mapName
        ? maps.find((m) => m.name === mapName) || maps[0]
        : maps[0];

    const resolvedName = mapName || mapEntry?.name || '';
    if (!resolvedName) return null;

    return {
        mapName: resolvedName,
        downloadUrl: mapEntry?.durl || `${cdnBase}/maps/${resolvedName}.zip`,
        mapHash: mapEntry?.mapHash || '',
        mapVersion: 1,
        fileSize: mapEntry?.fileSize || 0,
        resVersion: entry?.resVersion || 1
    };
}


function md5File(filePath) {
    try {
        return crypto.createHash('md5').update(fs.readFileSync(filePath)).digest('hex');
    } catch (_) {
        return '';
    }
}

function fingerprintMapZip(mapPath) {
    try {
        const stat = fs.statSync(mapPath);
        const md5 = md5File(mapPath);
        return {
            md5,
            fileSize: stat.size,
            mtime: Math.floor(stat.mtimeMs),
        };
    } catch (_) {
        return null;
    }
}

function resolveMapDownloadUrl(gameId, engineVersion, mapName) {
    const entry = pickEngineEntry(gameId, engineVersion);
    const maps = entry?.maps || [];
    const mapEntry = mapName
        ? maps.find((m) => m.name === mapName) || maps[0]
        : maps[0];
    const resolvedName = mapName || mapEntry?.name || '';
    if (!resolvedName) return null;
    const cdnBase = (hostConfig.cdnUrl || 'https://cdn.vukz.lol/').replace(/\/$/, '');
    let downloadUrl = mapEntry?.durl || `${cdnBase}/Maps/${resolvedName}.zip`;
    const mapPath = path.join(CDN_MAPS, `${resolvedName}.zip`);
    const fp = fingerprintMapZip(mapPath);
    const mapHash = fp?.md5 || mapEntry?.mapHash || '';
    const mapVersion = fp?.mtime || 0;
    if (mapVersion > 0) {
        const baseUrl = downloadUrl.split('?')[0];
        downloadUrl = `${baseUrl}?v=${mapVersion}&h=${mapHash.slice(0, 12)}`;
    }
    return {
        mapName: resolvedName,
        downloadUrl,
        mapHash,
        mapVersion,
        fileSize: fp?.fileSize || mapEntry?.fileSize || 0,
        resVersion: entry?.resVersion || 1,
    };
}

function toNumber(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
}

function loadGameStats() {
    try {
        if (!fs.existsSync(GAME_STATS_FILE)) return {};
        return JSON.parse(fs.readFileSync(GAME_STATS_FILE, 'utf8')) || {};
    } catch (_) {
        return {};
    }
}

function saveGameStats(data) {
    try {
        fs.mkdirSync(path.dirname(GAME_STATS_FILE), { recursive: true });
        fs.writeFileSync(GAME_STATS_FILE, `${JSON.stringify(data || {}, null, 2)}\n`, 'utf8');
    } catch (_) {}
}

function ensureGameStat(stats, gameId) {
    const gid = String(gameId || '');
    if (!stats[gid]) stats[gid] = { likes: 0, onlineUsers: {} };
    if (!stats[gid].onlineUsers || typeof stats[gid].onlineUsers !== 'object') {
        stats[gid].onlineUsers = {};
    }
    return stats[gid];
}

function getActiveCount(state, now = Date.now()) {
    const ttl = 10 * 60 * 1000;
    const users = (state && state.onlineUsers && typeof state.onlineUsers === 'object') ? state.onlineUsers : {};
    for (const [uid, ts] of Object.entries(users)) {
        if (!Number.isFinite(Number(ts)) || now - Number(ts) > ttl) delete users[uid];
    }
    return Object.keys(users).length;
}

function markUserOfflineEverywhere(userId) {
    if (!userId) return;
    const stats = loadGameStats();
    for (const gameId of Object.keys(stats)) {
        const state = ensureGameStat(stats, gameId);
        delete state.onlineUsers[String(userId)];
        state.active = getActiveCount(state);
    }
    saveGameStats(stats);
}

const gameSchema = new mongoose.Schema({
    gameId: String,
    gameTitle: String,
    gameCoverPic: String,
    visitorEnter: Number,
    praiseNumber: Number,
    gameTypes: Array
});

const configSchema = new mongoose.Schema({
    id: Number,
    content: String,
    title: String,
    isShow: Boolean,
    isShowInGame: Boolean,
    updateTime: Number
});

const Game = mongoose.model('games', gameSchema);
const Config = mongoose.model('config', configSchema);
const app = express();

app.use('/static', express.static(path.join(__dirname, 'static')));

router.get('/api/v1/games/announcement/info', async (req, res) => {
        const announcementPath = path.join(__dirname, '..', 'static', 'files', 'announcement.json');
        const fileData = fs.readFileSync(announcementPath, 'utf-8');
        const announcement = JSON.parse(fileData);
    
        res.status(200).json({ code: 1, message: 'SUCCESS', data: announcement });
});

router.get('/api/v1/games/stop/announcement/info', async (req, res) => {
    const announcementPath = path.join(__dirname, '..', 'static', 'files', 'stop-announcement.json');
        const fileData = fs.readFileSync(announcementPath, 'utf-8');
        const announcement = JSON.parse(fileData);
    
        res.status(200).json({ code: 1, message: 'SUCCESS', data: announcement });
});

router.get('/api/:version/games/recommendation/type', async (req, res) => {
    const pageNo = parseInt(req.query.pageNo) || 0;
    const pageSize = parseInt(req.query.pageSize) || 10;
    const language = "en";
    
    

    const randomGames = gamesCatalog.sampleGames(5);
    return res.status(200).json(gamesCatalog.pagedResponse(randomGames, pageNo, pageSize));
});

router.get('/api/v1/games/playlist/recently', async (req, res) => {
    const pageNo = parseInt(req.query.pageNo) || 0;
    const pageSize = parseInt(req.query.pageSize) || 10;
    const language = "en";
    
    

    const randomGames = gamesCatalog.sampleGames(5);
    return res.status(200).json(gamesCatalog.pagedResponse(randomGames, pageNo, pageSize));
});

router.get('/api/:version/games', async (req, res) => {
    const gamesJson = gamesCatalog.listGames();
    const pageNo = parseInt(req.query.pageNo, 10) || 0;
    const pageSize = parseInt(req.query.pageSize, 10) || 10;
    try {
        if (pageNo !== 0) {
            return res.status(200).json({
                code: 1,
                message: 'SUCCESS',
                data: {
                    pageNo,
                    pageSize,
                    totalPage: 0,
                    totalSize: 0,
                    data: []
                }
            });
        }

        res.status(200).json({
            code: 1,
            message: 'SUCCESS',
            data: {
                pageNo,
                pageSize,
                totalPage: pageSize > 0 ? Math.ceil(gamesJson.length / pageSize) : 0,
                totalSize: gamesJson.length,
                data: gamesJson,
                other: null
            }
        });
    } catch (error) {
        console.error('Error searching for recommended games:', error);
        res.status(500).json({ message: 'Error searching for recommended games.' });
    }
});

function getGameUpdateCount(gameId, engineVersion = 10039) {
    const entry = pickEngineEntry(gameId, engineVersion);
    return Number(entry?.resVersion) || 0;
}

function buildUpdateChangelog(gameId, resVersion) {
    const titles = {
        g11005: 'Builders',
        g1098: 'Builders',
        g1008: 'Bed Wars',
        g1014: 'Jail Break',
        g1048: 'Sky Block',
    };
    const name = titles[gameId] || gameId;
    return `<p><b>${name} v${resVersion}</b></p><p>Обновление ресурсов игры. Перезапустите игру для загрузки.</p>`;
}

router.get('/api/v1/games/update/list/:userId', async (req, res) => {
    const engineVersion = Number(req.query.oldEngineVersion) || 10039;
    const data = {};
    for (const game of gamesCatalog.listGames()) {
        const count = getGameUpdateCount(game.gameId, engineVersion);
        if (count > 0) {
            data[game.gameId] = count;
        }
    }
    // g1098 — legacy id Builders (может остаться в кэше клиента)
    const g1098Count = getGameUpdateCount('g1098', engineVersion);
    if (g1098Count > 0 && !data.g1098) {
        data.g1098 = g1098Count;
    }
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data,
    });
});

router.get('/api/v1/games/ugc', async (req, res) => {
    const pageNo = parseInt(req.query.pageNo) || 0;
    const pageSize = parseInt(req.query.pageSize) || 10;
    const randomGames = gamesCatalog.sampleGames(5);
    return res.status(200).json(gamesCatalog.pagedResponse(randomGames, pageNo, pageSize));
});

router.get('/api/v1/games/ugc/status', async (req, res) => {
    logger.warn("Community games status needs implementing!");
    const pageNo = parseInt(req.query.pageNo) || 0;
    const pageSize = parseInt(req.query.pageSize) || 10;
        if (pageNo !== 0) {
            return res.status(200).json({
                code: 1,
                message: 'SUCCESS',
                data: {
                    pageNo,
                    pageSize,
                    totalPage: 0,
                    totalSize: 0,
                    data: []
                }
            });
        }

        res.status(200).json({
            code: 1,
            message: 'SUCCESS',
            data: {
                pageNo,
                pageSize,
                totalPage: 0,
                totalSize: 0,
                data: null,
                other: null
            }
        });
});

router.get('/api/v2/games/:gameId', async (req, res) => {
    const gameId = req.params.gameId;
    const games = gamesCatalog.listGames();
    const game = games.find((g) => g.gameId === gameId) || games[0];
    return res.status(200).json({
        code: 1,
        message: "SUCCESS",
        data: game || null,
    });
});

function buildPluginUpgradePayload(gameId, engineVersion, clientVer, clientHash) {
    const entry = pickEngineEntry(gameId, engineVersion);
    const downloadUrl = entry?.plugin || AssetUtil.getGameResUrl(gameId);
    const pluginPath = path.join(CDN_PLUGINS, `${gameId}.zip`);
    const hash = md5File(pluginPath) || entry?.pluginHash || '';
    const resVersion = entry?.resVersion || 1;
    const ver = Number(clientVer) || 0;
    const md5Client = String(clientHash || '').trim().toLowerCase();
    const needUpgrade = ver === 0
        || ver < resVersion
        || (md5Client && hash && md5Client !== hash.toLowerCase());
    return { downloadUrl, needUpgrade, hash, md5: hash, resVersion, needUpdate: needUpgrade, update: needUpgrade };
}

router.get('/api/v1/games/app-engine/upgrade', async (req, res) => {
    const gameId = req.query.gameType || 'g1008';
    const engineVersion = Number(req.query.engineVersion) || 10048;
    const clientVer = req.query.resVersion ?? req.query.ver;
    const clientHash = req.query.hash ?? req.query.md5;
    const data = buildPluginUpgradePayload(gameId, engineVersion, clientVer, clientHash);
    return res.status(200).json({ code: 1, message: 'SUCCESS', data });
});

router.get('/api/v1/games/app-engine/check-update', async (req, res) => {
    const gameId = req.query.gameType || 'g1008';
    const engineVersion = Number(req.query.engineVersion) || 10048;
    const clientVer = req.query.gameResVersion ?? req.query.resVersion ?? req.query.ver;
    const clientHash = req.query.hash ?? req.query.md5;
    const payload = buildPluginUpgradePayload(gameId, engineVersion, clientVer, clientHash);
    const updates = payload.needUpgrade
        ? [{ url: payload.downloadUrl, hash: payload.hash, md5: payload.hash, type: 'game' }]
        : [];
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: [{ resVersion: payload.resVersion, updates }],
    });
});

router.get('/api/v1/inner/games/app-engine/check-update', async (req, res) => {
    const gameId = req.query.gameType || 'g1008';
    const engineVersion = Number(req.query.engineVersion) || 10048;
    const clientVer = req.query.gameResVersion ?? req.query.resVersion ?? req.query.ver;
    const clientHash = req.query.hash ?? req.query.md5;
    const payload = buildPluginUpgradePayload(gameId, engineVersion, clientVer, clientHash);
    const updates = payload.needUpgrade
        ? [{ url: payload.downloadUrl, hash: payload.hash, md5: payload.hash, type: 'game' }]
        : [];
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: [{ resVersion: payload.resVersion, updates }],
    });
});

router.get('/api/v1/games/config/app/:gameId', async (req, res) => {
    const gameId = req.params.gameId || 'g1008';
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: {
            gameId,
            gameCategory: 'mini',
            memberMax: 16,
            teamNum: 4,
            teamMem: 4,
            commonMem: 4,
            vipMem: 8,
            partyStatus: 1,
        },
    });
});

router.get('/api/v1/games/resource/version', async (req, res) => {
    const gameId = req.query.gameType || 'g1008';
    const engineVersion = Number(req.query.engineVersion) || 10048;
    const clientVer = req.query.resVersion ?? req.query.ver;
    const clientHash = req.query.hash ?? req.query.md5;
    const payload = buildPluginUpgradePayload(gameId, engineVersion, clientVer, clientHash);
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: {
            update: payload.needUpgrade,
            needUpdate: payload.needUpgrade,
            needUpgrade: payload.needUpgrade,
            url: payload.downloadUrl,
            downloadUrl: payload.downloadUrl,
            hash: payload.hash,
            md5: payload.hash,
            resVersion: payload.resVersion,
        },
    });
});

router.get('/api/v1/games/map/version', async (req, res) => {
    const gameId = req.query.gameType || req.query.gameId || 'g11005';
    const mapName = String(req.query.mapName || req.query.mapId || '').trim();
    const engineVersion = Number(req.query.engineVersion) || 10039;
    const clientHash = String(req.query.mapHash || req.query.hash || req.query.md5 || '').trim().toLowerCase();
    const clientResVer = Number(req.query.resVersion ?? req.query.ver ?? req.query.gameResVersion) || 0;
    const resolved = resolveMapDownloadUrl(gameId, engineVersion, mapName);
    if (!resolved) {
        return res.status(200).json({ code: 6, message: 'map not found', data: null });
    }
    const needUpdate = clientResVer < resolved.resVersion
        || !clientHash
        || (resolved.mapHash && clientHash !== resolved.mapHash.toLowerCase());
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: {
            mapName: resolved.mapName,
            durl: resolved.downloadUrl,
            downloadUrl: resolved.downloadUrl,
            mapHash: resolved.mapHash,
            mapVersion: resolved.mapVersion,
            fileSize: resolved.fileSize,
            needUpdate,
            update: needUpdate,
            needUpgrade: needUpdate,
            resVersion: resolved.resVersion,
        },
    });
});

router.get('/api/v1/games/update/tip/info/app/:gameId', async (req, res) => {
    const gameId = req.params.gameId || '';
    const engineVersion = Number(req.query.engineVersion) || 10039;
    const count = getGameUpdateCount(gameId, engineVersion);
    if (count <= 0) {
        return res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
    }
    return res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: {
            count,
            content: buildUpdateChangelog(gameId, count),
        },
    });
});

router.get('/api/v2/game/auth', async (req, res) => {
    const userId = getUserIdFromRequest(req);
    const typeId = req.query.typeId || req.query.gameId || 'g1014';
    const targetId = req.query.targetId;
    if (!userId) {
        return res.status(200).json({ code: 6, message: 'userId required', data: null });
    }
    try {
        const userCol = require('mongoose').connection?.db?.collection('users');
        let nickname = '';
        if (userCol) {
            const u = await userCol.findOne({ userId: String(userId) });
            nickname = u?.nickname || '';
        }
        const data = await issueGameAuth(userId, typeId, { targetId, nickname, devicePayload: req.body });
        const stats = loadGameStats();
        const state = ensureGameStat(stats, typeId);
        state.onlineUsers[String(userId)] = Date.now();
        state.active = getActiveCount(state);
        saveGameStats(stats);
        startGameSession(userId, typeId);
        return res.status(200).json({ code: 1, message: 'SUCCESS', data });
    } catch (error) {
        if (banService.isBanApiCode(error.code)) {
            return banService.sendBanResponse(res, error.message);
        }
        logger.error('v2 game auth: ' + error.message);
        return res.status(200).json({ code: 4, message: 'INNER ERROR', data: null });
    }
});

router.post('/api/v2/inner/users/games/reporting/list', (req, res) => {
    try {
        const reports = Array.isArray(req.body) ? req.body : (req.body?.data || req.body?.list || []);
        applyGameReports(reports);
        return res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
    } catch (error) {
        logger.error('game reporting list: ' + error.message);
        return res.status(200).json({ code: 4, message: 'INNER ERROR', data: null });
    }
});

router.all('/api/v2/game/auth/logout', async (req, res) => {
    const userId = getUserIdFromRequest(req);
    const typeId = req.query.typeId || req.query.gameId || req.body?.typeId || req.body?.gameId;
    if (!userId) {
        return res.status(200).json({ code: 6, message: 'userId required', data: null });
    }
    // logout без валидного токена — не блокируем
    if (typeId) {
        const stats = loadGameStats();
        const state = ensureGameStat(stats, typeId);
        delete state.onlineUsers[String(userId)];
        state.active = getActiveCount(state);
        saveGameStats(stats);
        clearGameSession(userId);
    } else {
        markUserOfflineEverywhere(userId);
        clearGameSession(userId);
    }
    return res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
});

module.exports = router;