const express = require('express');
const fs = require('fs');
const store = require('../lib/charmingtownStore');

const router = express.Router();
router.use(express.text({ type: '*/*', limit: '2mb' }));

const ok = (data) => ({ code: 1, message: 'SUCCESS', data });
const fail = (code = 2, message = 'FAIL') => ({ code, message, data: null });
const TRACE_FILE = '/tmp/charmingtown-access.log';

function trace(event, payload = {}) {
  try {
    fs.appendFileSync(
      TRACE_FILE,
      `${new Date().toISOString()} ${event} ${JSON.stringify(payload)}\n`,
      'utf8',
    );
  } catch (_e) {}
}

function toNum(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function resolveUserId(req, fallback = null) {
  const value = req.params?.userId
    ?? normalizeBody(req)?.userId
    ?? req.query?.userId
    ?? req.headers.userid
    ?? req.headers.userId
    ?? req.headers['x-shahe-uid']
    ?? fallback;
  return value == null ? null : String(value);
}

function normalizeBody(req) {
  if (req.__normalizedBody) return req.__normalizedBody;
  let body = req.body;
  if (typeof body === 'string') {
    const raw = body.trim();
    if (!raw) {
      body = {};
    } else {
      try {
        body = JSON.parse(raw);
      } catch (_e) {
        body = {};
      }
    }
  }
  if (!body || typeof body !== 'object') {
    body = {};
  }
  req.__normalizedBody = body;
  return body;
}

router.get('/charmingtown/api/v1/inner/user/money/:userId', (req, res) => {
  const wallet = store.getWallet(req.params.userId);
  res.status(200).json(ok({ amount: wallet.amount }));
});

router.post('/charmingtown/api/v1/inner/user/money/trade', (req, res) => {
  const body = normalizeBody(req);
  const userId = resolveUserId(req);
  if (!userId) {
    return res.status(200).json(fail(3, 'PARAM ERROR'));
  }
  const amount = store.addWallet(userId, body?.amount || 0);
  return res.status(200).json(ok({ amount }));
});

router.get('/charmingtown/api/v1/inner/manor/level/config', (_req, res) => {
  res.status(200).json(ok(store.YARD_LEVEL_CONFIG));
});

router.get('/charmingtown/api/v1/inner/manor/find/:userId', (req, res) => {
  const userId = resolveUserId(req);
  return res.status(200).json(ok(store.findPayload(userId)));
});

router.get('/charmingtown/api/v1/inner/manor/receive/:userId', (req, res) => {
  const userId = resolveUserId(req);
  const manor = store.getManorForUser(userId);
  if (!manor) {
    return res.status(200).json(fail(2, 'NO_MANOR'));
  }
  return res.status(200).json(ok({ manor }));
});

router.post('/charmingtown/api/v1/inner/manor/receive', (req, res) => {
  const body = normalizeBody(req);
  const userId = resolveUserId(req);
  trace('manor.receive.request', { userId, body });
  if (!userId) {
    trace('manor.receive.param_error', { headers: req.headers });
    return res.status(200).json(fail(3, 'PARAM ERROR'));
  }
  const name = body?.name;
  const manor = store.receiveManor(userId, name);
  trace('manor.receive.success', { userId, manorId: manor?.id, plotIndex: manor?.plotIndex, state: manor?.state });
  return res.status(200).json(ok({ manor, backpacks: store.findPayload(userId).backpacks }));
});

router.get('/charmingtown/api/v1/inner/manor/sale/:userId', (req, res) => {
  const userId = resolveUserId(req);
  const data = store.releaseManor(userId);
  return res.status(200).json(ok(data));
});

router.get('/charmingtown/api/v1/inner/message/:userId', (req, res) => {
  const userId = resolveUserId(req);
  const content = store.getMessages(userId);
  return res.status(200).json(ok({ content, number: content.length }));
});

router.post('/charmingtown/api/v1/inner/message/remove/:id', (req, res) => {
  store.removeMessageById(req.params.id);
  return res.status(200).json(ok(null));
});

router.get('/charmingtown/api/v1/inner/manor/ranking/:userId', (req, res) => {
  const userId = resolveUserId(req);
  return res.status(200).json(ok(store.getPersonalRanking(userId)));
});

router.get('/charmingtown/api/v1/inner/manor/charm', (_req, res) => {
  return res.status(200).json(ok({ content: store.getRankContent('charm') }));
});

router.get('/charmingtown/api/v1/inner/manor/potential', (_req, res) => {
  return res.status(200).json(ok({ content: store.getRankContent('potential') }));
});

router.post('/charmingtown/api/v1/inner/manor/upgrade/:userId', (req, res) => {
  const userId = resolveUserId(req);
  const manor = store.upgradeManor(userId);
  if (!manor) {
    return res.status(200).json(fail());
  }
  return res.status(200).json(ok({ manor }));
});

router.post('/charmingtown/api/v1/inner/manor/praise', (req, res) => {
  const body = normalizeBody(req);
  const userId = resolveUserId(req);
  const targetUserId = String(body?.targetUserId ?? '');
  const nickName = String(body?.nickName || '');
  if (!userId || !targetUserId) {
    return res.status(200).json(fail(3, 'PARAM ERROR'));
  }
  const result = store.praiseManor(userId, targetUserId, nickName);
  if (result.code !== 1) {
    return res.status(200).json(fail(result.code, 'FAIL'));
  }
  return res.status(200).json(ok(result.data));
});

router.post('/charmingtown/api/v1/inner/manor/visit', (req, res) => {
  const body = normalizeBody(req);
  const userId = resolveUserId(req);
  const targetUserId = String(body?.targetUserId ?? '');
  const nickName = String(body?.nickName || '');
  if (!userId || !targetUserId) {
    return res.status(200).json(fail(3, 'PARAM ERROR'));
  }
  const result = store.visitManor(userId, targetUserId, nickName);
  if (result.code !== 1) {
    return res.status(200).json(fail(result.code, 'FAIL'));
  }
  return res.status(200).json(ok(result.data));
});

router.get('/charmingtown/api/v1/inner/manor/cost/:userId', (req, res) => {
  const userId = resolveUserId(req);
  const manor = store.getManorForUser(userId);
  return res.status(200).json(ok({ cost: toNum(manor?.potentialTotal ?? manor?.potential, 0) }));
});

router.post('/charmingtown/api/v1/inner/furniture/buy', (req, res) => {
  const body = normalizeBody(req);
  const manorId = String(body?.manorId || '');
  if (!manorId) {
    return res.status(200).json(fail(3, 'PARAM ERROR'));
  }
  store.upsertFurniture(manorId, {
    tempId: body?.tempId,
    price: body?.price,
    state: 0,
    offset: 0,
    positionX: 0,
    positionY: 0,
    positionZ: 0,
    charm: body?.charm,
  });
  return res.status(200).json(ok(null));
});

router.post('/charmingtown/api/v1/inner/furniture/put', (req, res) => {
  const body = normalizeBody(req);
  const manorId = String(body?.manorId || '');
  if (!manorId) {
    return res.status(200).json(fail(3, 'PARAM ERROR'));
  }
  store.upsertFurniture(manorId, body);
  return res.status(200).json(ok(null));
});

router.get('/charmingtown/api/v1/inner/furniture/:manorId', (req, res) => {
  return res.status(200).json(ok(store.getFurnituresByManorId(req.params.manorId)));
});

router.post('/charmingtown/api/v1/inner/house/unlock', (req, res) => {
  const body = normalizeBody(req);
  const manorId = String(body?.manorId || '');
  if (!manorId) {
    return res.status(200).json(fail(3, 'PARAM ERROR'));
  }
  store.upsertHouse(manorId, {
    tempId: body?.tempId,
    charm: body?.charm,
    price: body?.price,
    state: 0,
  });
  return res.status(200).json(ok(null));
});

router.post('/charmingtown/api/v1/inner/house/build', (req, res) => {
  const body = normalizeBody(req);
  const manorId = String(body?.manorId || '');
  const tempId = toNum(body?.tempId, 0);
  if (!manorId || tempId <= 0) {
    return res.status(200).json(fail(3, 'PARAM ERROR'));
  }
  store.setBuiltHouse(manorId, tempId);
  return res.status(200).json(ok(null));
});

router.get('/charmingtown/api/v1/inner/house/:manorId', (req, res) => {
  return res.status(200).json(ok(store.getHousesByManorId(req.params.manorId)));
});

router.post('/charmingtown/api/v1/inner/plough/crop', (req, res) => {
  const body = normalizeBody(req);
  const manorId = String(body?.manorId || '');
  if (!manorId) {
    return res.status(200).json(fail(3, 'PARAM ERROR'));
  }
  store.upsertPlough(manorId, body);
  return res.status(200).json(ok(null));
});

router.post('/charmingtown/api/v1/inner/plough/plucking', (req, res) => {
  const body = normalizeBody(req);
  const manorId = String(body?.manorId || '');
  if (!manorId) {
    return res.status(200).json(fail(3, 'PARAM ERROR'));
  }
  store.pluckPlough(manorId, body?.ploughRow, body?.ploughColumn);
  return res.status(200).json(ok(null));
});

router.get('/charmingtown/api/v1/inner/plough/:manorId', (req, res) => {
  return res.status(200).json(ok(store.getPloughsByManorId(req.params.manorId)));
});

router.get('/charmingtown/api/v1/inner/manor/backpack/:manorId', (req, res) => {
  res.status(200).json(ok(store.getBackpackByManorId(req.params.manorId)));
});

router.put('/charmingtown/api/v1/inner/manor/backpack/:manorId', (req, res) => {
  let items = normalizeBody(req);
  if (typeof items === 'string') {
    try {
      items = JSON.parse(items);
    } catch (_e) {
      items = [];
    }
  }
  store.saveBackpack(req.params.manorId, items);
  return res.status(200).json(ok(null));
});

router.post('/charmingtown/api/v1/inner/manor/backpack/:manorId', (req, res) => {
  let items = normalizeBody(req);
  if (typeof items === 'string') {
    try {
      items = JSON.parse(items);
    } catch (_e) {
      items = [];
    }
  }
  store.saveBackpack(req.params.manorId, items);
  return res.status(200).json(ok(null));
});

router.get('/charmingtown/api/v1/inner/block/:manorId', (req, res) => {
  return res.status(200).json(ok(store.getBlocksByManorId(req.params.manorId)));
});

router.put('/charmingtown/api/v1/inner/block/:manorId', (req, res) => {
  let blocks = normalizeBody(req);
  if (typeof blocks === 'string') {
    try {
      blocks = JSON.parse(blocks);
    } catch (_e) {
      blocks = [];
    }
  }
  store.saveBlocks(req.params.manorId, blocks);
  return res.status(200).json(ok(null));
});

router.post('/charmingtown/api/v1/inner/block/:manorId', (req, res) => {
  let blocks = normalizeBody(req);
  if (typeof blocks === 'string') {
    try {
      blocks = JSON.parse(blocks);
    } catch (_e) {
      blocks = [];
    }
  }
  store.saveBlocks(req.params.manorId, blocks);
  return res.status(200).json(ok(null));
});

module.exports = router;
