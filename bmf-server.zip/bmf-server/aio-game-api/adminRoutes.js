const fs = require('fs');
const path = require('path');
const express = require('express');
const mongoose = require('mongoose');

const PANGU_ADMINS_FILE = process.env.PANGU_ADMINS_FILE
  || '/root/bg/bmf-server/data/pangu-admins.txt';
const ADMIN_TAGS_FILE = process.env.ADMIN_TAGS_FILE
  || '/root/bg/bmf-server/data/admin-tags.json';
const PENDING_GIVE_DIR = process.env.PENDING_GIVE_DIR
  || '/root/bg/bmf-server/data/pending-give';
const WALLET_DIR = process.env.WALLET_DIR
  || '/root/bg/bmf-server/data/user-wallets';
const ADMIN_API_SECRET = process.env.ADMIN_API_SECRET || 'change-me-bmf-admin';

function readJsonFile(filePath, fallback = null) {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    const raw = fs.readFileSync(filePath, 'utf8');
    if (!raw || raw.trim() === '') return fallback;
    return JSON.parse(raw);
  } catch (_) {
    return fallback;
  }
}

function writeJsonFile(filePath, data) {
  ensureDataDir();
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(data, null, 2)}\n`);
}

function walletPath(userId) {
  return path.join(WALLET_DIR, `${userId}.json`);
}

function pendingPath(userId) {
  return path.join(PENDING_GIVE_DIR, `${userId}.json`);
}

function getWallet(userId) {
  return readJsonFile(walletPath(userId), { gold: 0, diamonds: 0, gcubes: 0 });
}

function saveWallet(userId, wallet) {
  writeJsonFile(walletPath(userId), wallet);
}

function addWalletFields(userId, fields) {
  const wallet = getWallet(userId);
  if (typeof fields.gold === 'number' && fields.gold !== 0) {
    wallet.gold = Math.max(0, (wallet.gold || 0) + fields.gold);
  }
  if (typeof fields.diamonds === 'number' && fields.diamonds !== 0) {
    wallet.diamonds = Math.max(0, (wallet.diamonds || 0) + fields.diamonds);
  }
  if (typeof fields.gcubes === 'number' && fields.gcubes !== 0) {
    wallet.gcubes = Math.max(0, (wallet.gcubes || 0) + fields.gcubes);
  }
  saveWallet(userId, wallet);
  return wallet;
}

function queuePendingGive(userId, payload) {
  fs.mkdirSync(PENDING_GIVE_DIR, { recursive: true });
  const pending = readJsonFile(pendingPath(userId), {}) || {};
  if (typeof payload.gold === 'number' && payload.gold !== 0) {
    pending.gold = (pending.gold || 0) + payload.gold;
  }
  if (typeof payload.diamonds === 'number' && payload.diamonds !== 0) {
    pending.diamonds = (pending.diamonds || 0) + payload.diamonds;
  }
  if (typeof payload.gcubes === 'number' && payload.gcubes !== 0) {
    pending.gcubes = (pending.gcubes || 0) + payload.gcubes;
  }
  if (typeof payload.gameMoney === 'number' && payload.gameMoney !== 0 && payload.gameType) {
    pending.gameMoney = pending.gameMoney || {};
    pending.gameMoney[payload.gameType] = (pending.gameMoney[payload.gameType] || 0) + payload.gameMoney;
  }
  if (payload.itemId && payload.itemAmount) {
    pending.items = pending.items || [];
    pending.items.push({ id: payload.itemId, num: payload.itemAmount });
  }
  writeJsonFile(pendingPath(userId), pending);
  return pending;
}

function fallbackUserExists(userId) {
  const uid = String(userId);
  if (fs.existsSync(walletPath(uid))) return true;
  if (fs.existsSync(pendingPath(uid))) return true;
  const tags = readAdminTagsFile();
  if (tags && tags[uid]) return true;
  if (fs.existsSync(PANGU_ADMINS_FILE)) {
    const lines = fs.readFileSync(PANGU_ADMINS_FILE, 'utf8')
      .split('\n')
      .map((line) => line.trim());
    if (lines.includes(uid)) return true;
  }
  return false;
}

function apiResponse(code, message, data = null) {
  return { code, message, data };
}

function ensureDataDir() {
  const dir = path.dirname(PANGU_ADMINS_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function readAdminTagsFile() {
  ensureDataDir();
  if (!fs.existsSync(ADMIN_TAGS_FILE)) {
    return {};
  }
  try {
    return JSON.parse(fs.readFileSync(ADMIN_TAGS_FILE, 'utf8'));
  } catch (_) {
    return {};
  }
}

function writeAdminTagsFile(tags) {
  ensureDataDir();
  fs.writeFileSync(ADMIN_TAGS_FILE, `${JSON.stringify(tags, null, 2)}\n`);
}

function normalizeTag(tag) {
  const raw = String(tag || '').trim();
  if (!raw) return '[Admin]';
  if (raw.startsWith('[') && raw.endsWith(']')) return raw;
  return `[${raw}]`;
}

function getUserModel() {
  const path = require('path');
  const BG = path.join(__dirname, '../BlockManGo');
  const mongoose = require(path.join(BG, 'node_modules/mongoose'));
  if (mongoose.models.User) {
    return mongoose.models.User;
  }
  if (mongoose.models.AdminUser) {
    return mongoose.models.AdminUser;
  }
  const schema = new mongoose.Schema({
    userId: String,
    nickname: String,
    gold: Number,
    diamonds: Number,
    gDiamonds: Number,
    isAdmin: { type: Boolean, default: false },
    adminTag: String,
  }, { strict: false });
  return mongoose.model('User', schema, 'users');
}

function appendPanguAdmin(userId) {
  ensureDataDir();
  const uid = String(userId);
  let lines = [];
  if (fs.existsSync(PANGU_ADMINS_FILE)) {
    lines = fs.readFileSync(PANGU_ADMINS_FILE, 'utf8')
      .split('\n')
      .map((line) => line.trim())
      .filter(Boolean);
  }
  if (!lines.includes(uid)) {
    lines.push(uid);
  }
  fs.writeFileSync(PANGU_ADMINS_FILE, `${lines.join('\n')}\n`);
  return lines;
}

function removePanguAdmin(userId) {
  ensureDataDir();
  const uid = String(userId);
  if (!fs.existsSync(PANGU_ADMINS_FILE)) {
    return [];
  }
  const lines = fs.readFileSync(PANGU_ADMINS_FILE, 'utf8')
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line && line !== uid);
  fs.writeFileSync(PANGU_ADMINS_FILE, lines.length ? `${lines.join('\n')}\n` : '');
  return lines;
}

async function syncPanguAdminsFile(User) {
  ensureDataDir();
  try {
    const admins = await User.find({ isAdmin: true }).select('userId').lean();
    const lines = admins
      .map((row) => String(row.userId || '').trim())
      .filter((id) => /^[0-9]+$/.test(id));
    fs.writeFileSync(PANGU_ADMINS_FILE, lines.length ? `${lines.join('\n')}\n` : '');
    console.log(`[Admin] synced ${lines.length} pangu admin(s) -> ${PANGU_ADMINS_FILE}`);
    return lines;
  } catch (err) {
    console.error('[Admin] sync pangu file failed:', err.message);
    return [];
  }
}

function checkSecret(req) {
  const secret = req.headers['x-admin-secret']
    || req.body?.secret
    || req.query?.secret;
  return secret && secret === ADMIN_API_SECRET;
}

function validateUserId(id) {
  return /^[0-9]+$/.test(String(id || ''));
}

function mountAdminRoutes(app, pool) {
  const router = express.Router();
  const User = getUserModel();

  router.get('/api/v1/admin/status', async (req, res) => {
    const userId = req.query.userId;
    if (!validateUserId(userId)) {
      return res.json(apiResponse(3, 'Invalid userId'));
    }
    try {
      const user = await User.findOne({ userId: String(userId) }).lean();
      const isAdmin = !!(user && user.isAdmin);
      const tags = readAdminTagsFile();
      const adminTag = user?.adminTag || tags[String(userId)] || '[Admin]';
      return res.json(apiResponse(1, 'Success', { userId: Number(userId), isAdmin, adminTag }));
    } catch (err) {
      ensureDataDir();
      let isAdmin = false;
      if (fs.existsSync(PANGU_ADMINS_FILE)) {
        const text = fs.readFileSync(PANGU_ADMINS_FILE, 'utf8');
        isAdmin = text.split('\n').some((line) => line.trim() === String(userId));
      }
      return res.json(apiResponse(1, 'Success', { userId: Number(userId), isAdmin }));
    }
  });

  router.get('/api/v1/admin/list', async (req, res) => {
    if (!checkSecret(req)) {
      return res.status(403).json(apiResponse(403, 'Forbidden'));
    }
    try {
      const admins = await User.find({ isAdmin: true }).select('userId nickname').lean();
      return res.json(apiResponse(1, 'Success', {
        admins: admins.map((row) => ({
          userId: Number(row.userId),
          nickname: row.nickname || '',
        })),
      }));
    } catch (err) {
      // Mongo can be unavailable; fallback to pangu admins file.
      ensureDataDir();
      const tags = readAdminTagsFile();
      let ids = [];
      if (fs.existsSync(PANGU_ADMINS_FILE)) {
        ids = fs.readFileSync(PANGU_ADMINS_FILE, 'utf8')
          .split('\n')
          .map((line) => line.trim())
          .filter((id) => /^[0-9]+$/.test(id));
      }
      return res.json(apiResponse(1, 'Success', {
        admins: ids.map((id) => ({
          userId: Number(id),
          nickname: '',
          adminTag: tags[id] || '[Admin]',
        })),
        mongoSkipped: true,
      }));
    }
  });

  router.post('/api/v1/admin/set', async (req, res) => {
    if (!checkSecret(req)) {
      return res.status(403).json(apiResponse(403, 'Forbidden'));
    }
    const { userId, isAdmin } = req.body || {};
    if (!validateUserId(userId) || typeof isAdmin !== 'boolean') {
      return res.json(apiResponse(3, 'Invalid parameters'));
    }
    try {
      const user = await User.findOneAndUpdate(
        { userId: String(userId) },
        { $set: { isAdmin } },
        { new: true, upsert: true, strict: false }
      ).lean();
      let lines = [];
      try {
        lines = await syncPanguAdminsFile(User);
      } catch (_) { /* mongo list optional */ }
      if (isAdmin) {
        lines = appendPanguAdmin(userId);
      } else {
        lines = removePanguAdmin(userId);
      }
      return res.json(apiResponse(1, 'Success', {
        userId: Number(userId),
        isAdmin: isAdmin || lines.includes(String(userId)),
        panguAdmins: lines.length,
      }));
    } catch (err) {
      const lines = isAdmin ? appendPanguAdmin(userId) : removePanguAdmin(userId);
      return res.json(apiResponse(1, 'Success', {
        userId: Number(userId),
        isAdmin,
        panguAdmins: lines.length,
        mongoSkipped: true,
      }));
    }
  });

  router.post('/api/v1/admin/tag', async (req, res) => {
    if (!checkSecret(req)) {
      return res.status(403).json(apiResponse(403, 'Forbidden'));
    }
    const { userId, tag } = req.body || {};
    if (!validateUserId(userId)) {
      return res.json(apiResponse(3, 'Invalid userId'));
    }
    const adminTag = normalizeTag(tag);
    try {
      await User.findOneAndUpdate(
        { userId: String(userId) },
        { $set: { adminTag, isAdmin: true } },
        { upsert: true, new: true }
      );
      const tags = readAdminTagsFile();
      tags[String(userId)] = adminTag;
      writeAdminTagsFile(tags);
      appendPanguAdmin(userId);
      try {
        await syncPanguAdminsFile(User);
      } catch (_) { /* optional */ }
      return res.json(apiResponse(1, 'Success', { userId: Number(userId), adminTag, isAdmin: true }));
    } catch (err) {
      const tags = readAdminTagsFile();
      tags[String(userId)] = adminTag;
      writeAdminTagsFile(tags);
      appendPanguAdmin(userId);
      return res.json(apiResponse(1, 'Success', { userId: Number(userId), adminTag, isAdmin: true, mongoSkipped: true }));
    }
  });

  router.post('/api/v1/admin/give', async (req, res) => {
    if (!checkSecret(req)) {
      return res.status(403).json(apiResponse(403, 'Forbidden'));
    }
    const {
      userId,
      gold,
      diamonds,
      gcubes,
      gameMoney,
      gameType,
      itemId,
      itemAmount,
    } = req.body || {};
    if (!validateUserId(userId)) {
      return res.json(apiResponse(3, 'Invalid userId'));
    }

    const result = { userId: Number(userId), pendingInGame: {} };
    let mongoSkipped = false;

    try {
      if (typeof gold === 'number' && gold !== 0) {
        try {
          const user = await User.findOne({ userId: String(userId) });
          if (user) {
            user.gold = Math.max(0, (user.gold || 0) + gold);
            await user.save();
            result.gold = user.gold;
          } else {
            await User.create({
              userId: String(userId),
              gold: Math.max(0, gold),
              diamonds: 0,
              gDiamonds: 0,
              isAdmin: false,
            });
            result.gold = Math.max(0, gold);
          }
        } catch (err) {
          mongoSkipped = true;
          const wallet = addWalletFields(userId, { gold });
          result.gold = wallet.gold;
          result.goldFile = true;
        }
      }

      if (typeof diamonds === 'number' && diamonds !== 0) {
        try {
          const user = await User.findOne({ userId: String(userId) });
          if (user) {
            user.diamonds = Math.max(0, (user.diamonds || 0) + diamonds);
            user.gDiamonds = Math.max(0, (user.gDiamonds || user.diamonds || 0) + diamonds);
            await user.save();
            result.diamonds = user.diamonds;
          } else {
            await User.create({
              userId: String(userId),
              gold: 0,
              diamonds: Math.max(0, diamonds),
              gDiamonds: Math.max(0, diamonds),
              isAdmin: false,
            });
            result.diamonds = Math.max(0, diamonds);
          }
        } catch (err) {
          mongoSkipped = true;
          const wallet = addWalletFields(userId, { diamonds });
          result.diamonds = wallet.diamonds;
          result.bcubesFile = true;
        }
      }

      if (typeof gcubes === 'number' && gcubes !== 0) {
        let gcubesSaved = false;
        if (pool) {
          try {
            const connection = await pool.getConnection();
            try {
              await connection.beginTransaction();
              const [rows] = await connection.query(
                'SELECT gcubes FROM gcubes_balance WHERE userId = ? FOR UPDATE',
                [userId]
              );
              const current = rows.length > 0 ? rows[0].gcubes : 0;
              const newBalance = Math.max(0, current + gcubes);
              if (rows.length > 0) {
                await connection.query(
                  'UPDATE gcubes_balance SET gcubes = ? WHERE userId = ?',
                  [newBalance, userId]
                );
              } else {
                await connection.query(
                  'INSERT INTO gcubes_balance (userId, gcubes) VALUES (?, ?)',
                  [userId, newBalance]
                );
              }
              await connection.commit();
              result.gcubes = newBalance;
              gcubesSaved = true;
            } catch (err) {
              await connection.rollback();
              throw err;
            } finally {
              connection.release();
            }
          } catch (_) {
            /* fallback to file wallet */
          }
        }
        if (!gcubesSaved) {
          const wallet = addWalletFields(userId, { gcubes });
          result.gcubes = wallet.gcubes;
          result.gcubesFile = true;
        }
      }

      if (typeof gameMoney === 'number' && gameMoney !== 0) {
        const gt = String(gameType || 'g1014');
        queuePendingGive(userId, { gameMoney, gameType: gt });
        result.queuedGameMoney = gameMoney;
        result.gameType = gt;
        result.pendingInGame.gameMoney = { [gt]: gameMoney };
      }

      if (typeof itemId === 'number' && itemId > 0) {
        const num = typeof itemAmount === 'number' ? itemAmount : 1;
        queuePendingGive(userId, { itemId, itemAmount: num });
        result.queuedItem = { id: itemId, num };
        result.pendingInGame.items = [{ id: itemId, num }];
      }

      if (mongoSkipped) {
        result.mongoSkipped = true;
        result.note = 'bcubes/gold сохранены в JSON; в игре выдаётся моментально если онлайн';
      } else {
        result.note = 'В игре выдаётся моментально если игрок онлайн (pending-give)';
      }

      return res.json(apiResponse(1, 'Success', result));
    } catch (err) {
      console.error('[Admin] give failed:', err.message);
      return res.json(apiResponse(4, err.message));
    }
  });

  router.get('/api/v1/admin/user/exists', async (req, res) => {
    if (!checkSecret(req)) {
      return res.status(403).json(apiResponse(403, 'Forbidden'));
    }
    const userId = String(req.query.userId || '').trim();
    if (!validateUserId(userId)) {
      return res.json(apiResponse(3, 'Invalid userId'));
    }
    try {
      const user = await User.findOne({ userId }).select('userId nickname').lean();
      return res.json(apiResponse(1, 'Success', {
        exists: !!user,
        userId: Number(userId),
        nickname: user?.nickname || '',
        source: 'mongo',
      }));
    } catch (err) {
      return res.json(apiResponse(1, 'Success', {
        exists: fallbackUserExists(userId),
        userId: Number(userId),
        nickname: '',
        source: 'fallback',
      }));
    }
  });

  app.use(router);

  mongoose.connection.once('open', () => {
    syncPanguAdminsFile(User);
  });
  if (mongoose.connection.readyState === 1) {
    syncPanguAdminsFile(User);
  }

  return { syncPanguAdminsFile, User };
}

module.exports = { mountAdminRoutes, syncPanguAdminsFile, PANGU_ADMINS_FILE };
