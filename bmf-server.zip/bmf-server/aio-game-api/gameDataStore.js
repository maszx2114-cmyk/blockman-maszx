const games = [
    {
        gameId: "g1008",
        gameTitle: "Bed Wars",
        gameType: "pvp"
    },
    {
        gameId: "g1014",
        gameTitle: "Jail Break",
        gameType: "adventure"
    },
    {
        gameId: "g1048",
        gameTitle: "Sky Block",
        gameType: "adventure"
    }
];

function getGames() {
    return games;
}

function getGameById(gameId) {
    return games.find(g => g.gameId === gameId) || null;
}

function saveGame(game) {
    games.push(game);
    return game;
}

function deleteGame(gameId) {
    const index = games.findIndex(g => g.gameId === gameId);

    if (index !== -1) {
        games.splice(index, 1);
    }
}

module.exports = {
    getGames,
    getGameById,
    saveGame,
    deleteGame
};