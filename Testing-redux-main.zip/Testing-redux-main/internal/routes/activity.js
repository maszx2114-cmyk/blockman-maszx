const express = require('express');
const router = express.Router();
const User = require('../models/user-model');
const Activity = require('../models/activity-model');
const ActivityManager = require('../common/helpers/activityHelper');

const WheelTypes = require("../common/constants/WheelTypes");

const allWheelConfig = require("../config/activity/wheel/config.json");
const allWheelRewardsConfig = require("../config/activity/wheel/rewards.json");
const allWheelShopConfig = require("../config/activity/wheel/shop.json");
const rewardsConfig = require("../config/activity/signin/rewards.json");
const ActivityLoginStatuses = require("../common/constants/ActivityLoginStatuses");
const Genders = require("../common/constants/Genders");


router.get('/api/v1/lucky/turntable/gold/status', async (req, res) => {
    const userId = req.headers.userid;
    let activity = await Activity.findOne({ userId });
    if (!activity) activity = await ActivityManager.createActivitySession(userId);

    res.status(200).json({ 
        code: 1,
        message: "SUCCESS",
        data: { 
            isFree: activity.freeWheel
        }
    });
});

const { getConfig } = require('../common/helpers/configHelper');
router.get('/api/v1/activity/title', async (req, res) => {
    try {
        // Get config by name
        const config = await getConfig('activityTitles');
        // Send stored data
        res.status(200).json({
            code: 1,
            message: "SUCCESS",
            data: config.configData
        });
    } catch (err) {
        console.error("Error fetching activityTitles:", err);
        res.status(500).json({
            code: 0,
            message: "Failed to load activity titles"
        });
    }
});

router.get('/api/v1/activity/action', async (req, res) => {
    try {
        // Fetch from MongoDB config
        const config = await getConfig('activityActions');

        // If config not found, send empty array
        if (!config || !config.configData || !config.configData.activityTitleList) {
            return res.status(200).json({
                code: 1,
                message: "SUCCESS",
                data: []
            });
        }

        // If ?titleType is provided, return actions; otherwise, empty array (same behavior as original)
        res.status(200).json({
            code: 1,
            message: "SUCCESS",
            data: req.query.titleType ? config.configData.activityTitleList : []
        });

    } catch (err) {
        console.error('Error loading activityActions:', err);
        res.status(500).json({
            code: 0,
            message: 'Failed to load activity actions'
        });
    }
});

router.get('/api/v1/signIn', async (req, res) => {
    // Algorithm for current day: 0 = day 1, 1 = day 2 (n+1=d)
    // Has claimed will be the value if the current day is claimed or not, (if it's 1 and current day is 3 then there will be no prizes to get and you'll have to wait another day
    const userId = req.headers.userid;
    const user = await User.findOne({ userId });
    const activity = await Activity.findOne({ userId });
    
    const currentDay = activity.currentSignInDay;
    const hasClaimed = activity.signInDay;

    const rewardList = structuredClone(rewardsConfig);
    for (let i = 0; i < rewardList.length; i++) {
        if (!rewardList[i].rewards) {
            rewardList[i].rewards = rewardList[i][`rewardList_${user.sex}`]; 

            delete rewardList[i][`rewardList_${Genders.BOY}`];
            delete rewardList[i][`rewardList_${Genders.GIRL}`];
        }
    }
    
    for (let i = 0; i < rewardList.length; i++) {
        if (currentDay > i) {
            rewardList[i].status = ActivityLoginStatuses.CLAIMED;
        }
    }
    
    res.status(200).json({
        code: 1,
        message: "SUCCESS",
        data: {
            signInStatus: currentDay >= rewardsConfig.length ? ActivityLoginStatuses.FINISHED : (hasClaimed ? ActivityLoginStatuses.CLAIMED : ActivityLoginStatuses.NOT_CLAIMED),
            userSignInList: rewardList
        }
    });
});

module.exports = router;