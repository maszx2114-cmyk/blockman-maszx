const express = require('express');
const router = express.Router();
const path = require("path");
const fs = require("fs");
const axios = require("axios");

const { getConfig } = require('../common/helpers/configHelper');

function readJSON(filename) {
    const rootPath = process.cwd();
    const filePath = path.join(rootPath, filename);
    try { return JSON.parse(fs.readFileSync(filePath,'utf-8')); } catch(e){ console.error(e); return {code:0,message:'SUCCESS',data:{}} }
}

router.post('/v1/dispatch', async (req, res) => {
    const data = readJSON('dispatchconfig.json');

    data.data.timestamp = Math.floor(Date.now() / 1000);

    res.json(data);
});

module.exports = router;