module.exports = {
    ANY: "any"
}