 how termux & cmd 
 use phone & pc

# ls -l ~
# cd /storage/emulated/0/Download
# ls -l
# cp -r Testing-redux-main ~/ 
# cd ~
# cd Testing-redux-main
npm install mongodb & npm install express

