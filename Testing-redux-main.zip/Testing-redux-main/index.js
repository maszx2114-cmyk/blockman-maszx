// =====================================================
// Imports
// =====================================================
const express = require('express');
const mongoose = require('mongoose');
const chalk = require('chalk');
const figlet = require('figlet');
const path = require('path');
const fs = require('fs');

// Internal modules
const requestLogger = require('./internal/common/httpLogger');
const printStartupBanner = require('./internal/common/printStartupBanner');
const database = require('./internal/common/database');
const logger = require('./internal/common/logger');
const responser = require('./internal/common/response');

// Protection
const { generalLimiter, authLimiter } = require('./internal/common/protection/rateLimiters');
const requireAuth = require('./internal/common/protection/requireAuth');

// =====================================================
// App Initialization
// =====================================================
const app = express();
const port = 8080;

// =====================================================
// Routers
// =====================================================
const configRouter = require('./internal/routes/config');
const userRouter = require('./internal/routes/user');
const accountRouter = require('./internal/routes/account');
const emailRouter = require('./internal/routes/email');
const activityRouter = require('./internal/routes/activity');
const clanRouter = require('./internal/routes/clan');
const decorRouter = require('./internal/routes/decor');
const friendRouter = require('./internal/routes/friend');
const gameRouter = require('./internal/routes/game');
const msgRouter = require('./internal/routes/msg');
const mailRouter = require('./internal/routes/mail');
const payRouter = require('./internal/routes/pay');
const shopRouter = require('./internal/routes/shop');
const dispatchRouter = require('./internal/routes/dispatch');

// =====================================================
// Database Connection
// =====================================================
database.connect();

// =====================================================
// Middleware
// =====================================================
app.use(requestLogger);
app.use(requireAuth);
app.use(responser);
app.use(express.json());

// =====================================================
// Routes
// =====================================================
app.use('/config', configRouter);
app.use('/user', userRouter);
app.use('/user', accountRouter);
app.use('/user', emailRouter);
app.use('/activity', activityRouter);
app.use('/clan', clanRouter);
app.use('/decoration', decorRouter);
app.use('/friend', friendRouter);
app.use('/game', gameRouter);
app.use('/msg', msgRouter);
app.use('/mailbox', mailRouter);
app.use('/pay', payRouter);
app.use('/shop', shopRouter);
app.use('/', dispatchRouter);

// =====================================================
// Rate Limiters
// =====================================================
app.use('/user', authLimiter);
app.use(generalLimiter);

// =====================================================
// Static Files
// =====================================================
app.use('/static', express.static(path.join(__dirname, 'static', 'files')));

app.use('/static', (req, res) => {
    return res.status(404).json({
        error: 'Static file not found',
        path: req.path,
    });
});

// =====================================================
// Health Check
// =====================================================
app.get('/ping', (req, res) => res.send('pong'));
app.get('/', (req, res) => res.send('OK'));

// =====================================================
// Server Startup
// =====================================================
app.listen(port, () => {
    printStartupBanner(port);
    logger.info(`Server started at port ${port}`);
});